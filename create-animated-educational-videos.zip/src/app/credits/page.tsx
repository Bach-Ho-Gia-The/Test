import fs from "node:fs";
import path from "node:path";
import { TOPICS } from "../../../content";

export const dynamic = "force-static";
export const metadata = { title: "Nguồn ảnh & ghi công – MLN122" };

export default function Credits() {
  const credits = JSON.parse(fs.readFileSync(path.join(/*turbopackIgnore: true*/ process.cwd(), "public/photos/credits.json"), "utf8")) as Record<string, { title: string; author: string; url: string }>;
  return (
    <main className="mx-auto max-w-3xl px-5 py-10 text-slate-100">
      <a href="/" className="text-sky-300 underline">← Về trang video</a>
      <h1 className="mb-6 mt-4 text-3xl font-extrabold">Nguồn ảnh, âm thanh & ghi công</h1>

      <h2 className="mt-6 text-xl font-bold">Đề bài</h2>
      <p className="mt-2 text-slate-300">100 câu đầu của bộ “MLN122 Flashcards (Quizlet)” do bạn cung cấp. Đáp án lấy theo bộ đề; phần giải thích do mình soạn dựa trên kiến thức giáo trình Kinh tế chính trị Mác-Lênin.</p>

      <h2 className="mt-6 text-xl font-bold">Ảnh nền (Pexels, dùng theo Giấy phép Pexels)</h2>
      <ul className="mt-2 list-disc space-y-2 pl-6 text-slate-300">
        {Object.entries(credits).map(([k, c]) => (
          <li key={k}>
            <b className="text-slate-100">{TOPICS[k as keyof typeof TOPICS]?.name ?? k}</b>: “{c.title}” – {c.author}.{" "}
            <a href={c.url} className="text-sky-300 underline" target="_blank" rel="noreferrer">Nguồn ảnh</a>
          </li>
        ))}
      </ul>

      <h2 className="mt-6 text-xl font-bold">Biểu tượng minh họa</h2>
      <p className="mt-2 text-slate-300">
        Twemoji © Twitter/X, Inc. và các cộng tác viên, giấy phép CC-BY 4.0 –{" "}
        <a className="text-sky-300 underline" href="https://github.com/jdecked/twemoji" target="_blank" rel="noreferrer">github.com/jdecked/twemoji</a>.
      </p>

      <h2 className="mt-6 text-xl font-bold">Phông chữ</h2>
      <p className="mt-2 text-slate-300">Be Vietnam Pro (SIL Open Font License 1.1), đóng gói qua @fontsource để luôn hiển thị đúng tiếng Việt.</p>

      <h2 className="mt-6 text-xl font-bold">Giọng đọc & âm thanh</h2>
      <p className="mt-2 text-slate-300">Giọng nam tiếng Việt “vi-VN-NamMinhNeural” (Microsoft Edge neural TTS). Hiệu ứng và nhạc nền được tổng hợp trực tiếp bằng WebAudio, không dùng mẫu âm thanh bên ngoài.</p>
    </main>
  );
}
