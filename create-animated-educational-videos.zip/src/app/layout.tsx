import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource/be-vietnam-pro/500.css";
import "@fontsource/be-vietnam-pro/700.css";
import "@fontsource/be-vietnam-pro/800.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "MLN122 – 100 câu trắc nghiệm, học bằng video hoạt hình",
  description: "Video giải thích 100 câu trắc nghiệm Kinh tế chính trị Mác-Lênin: đọc đề, chọn đáp án, vì sao, ví dụ hoạt hình, giọng nam tiếng Việt.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="vi">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
