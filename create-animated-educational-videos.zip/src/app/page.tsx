import fs from "node:fs";
import path from "node:path";
import Player from "@/components/Player";
import { CARDS, CONTENT, TOPICS } from "../../content";
import type { QItem } from "@/lib/types";

export const dynamic = "force-static";

function readJson<T>(rel: string, fallback: T): T {
  try {
    return JSON.parse(fs.readFileSync(path.join(/*turbopackIgnore: true*/ process.cwd(), rel), "utf8")) as T;
  } catch {
    return fallback;
  }
}

export default function Page() {
  const idx = readJson<Record<string, { dur: number }>>("public/audio/index.json", {});
  const credits = readJson<Record<string, { title: string; author: string; url: string }>>("public/photos/credits.json", {});
  const items: QItem[] = CARDS.map((c) => ({ n: c.n, t: CONTENT[c.n].t, q: c.q, opts: c.opts, ans: c.ans, dur: idx[c.n]?.dur ?? 0 }));
  return <Player items={items} topics={TOPICS} credits={credits} />;
}
