"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Em } from "./Em";
import { BannerScene, Confetti, KeywordScene, QuestionScene, ReviewScene, StageScene, TitleScene } from "./scenes";
import { initAudio, setMusic, setSfx, sfx, startMusic } from "@/lib/sfx";
import type { Beat, Manifest, QItem, TopicInfo } from "@/lib/types";

const pad = (n: number) => String(n).padStart(3, "0");
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
type Credit = { title: string; author: string; url: string };

export default function Player({ items, topics, credits }: { items: QItem[]; topics: Record<string, TopicInfo>; credits: Record<string, Credit> }) {
  const [q, setQ] = useState(1);
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [beatIdx, setBeatIdx] = useState(0);
  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [auto, setAuto] = useState(true);
  const [rate, setRate] = useState(1);
  const [music, setMusicState] = useState(true);
  const [sound, setSound] = useState(true);
  const [fs, setFs] = useState(false);
  const [scale, setScale] = useState(0.5);

  const audioRef = useRef<HTMLAudioElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const progRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const idxRef = useRef(-1);
  const wantPlay = useRef(false);
  const qRef = useRef(1);
  qRef.current = q;

  const item = items[q - 1];
  const topic = topics[item.t];
  const beat: Beat | null = manifest ? manifest.beats[Math.min(beatIdx, manifest.beats.length - 1)] : null;
  const totalDur = useMemo(() => items.reduce((s, x) => s + x.dur, 0), [items]);

  const getTime = useCallback(() => audioRef.current?.currentTime ?? 0, []);

  /* co giãn canvas 1920×1080 theo khung */
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    setScale(el.clientWidth / 1920);
    return () => ro.disconnect();
  }, []);
  useEffect(() => {
    const h = () => setFs(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", h);
    return () => document.removeEventListener("fullscreenchange", h);
  }, []);

  /* nạp câu */
  useEffect(() => {
    let cancel = false;
    setManifest(null);
    idxRef.current = -1;
    setBeatIdx(0);
    fetch(`/audio/q${pad(q)}.json`)
      .then((r) => r.json())
      .then((m: Manifest) => {
        if (!cancel) setManifest(m);
      })
      .catch(() => {});
    const a = audioRef.current;
    if (a) {
      a.src = `/audio/q${pad(q)}.mp3`;
      a.load();
      a.playbackRate = rate;
      if (wantPlay.current) a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
    return () => {
      cancel = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.playbackRate = rate;
  }, [rate]);

  const fire = useCallback((b: Beat) => {
    if (b.first === false) return;
    switch (b.k) {
      case "title": sfx.whoosh(); sfx.sparkle(); break;
      case "ask": sfx.blip(); break;
      case "opt": sfx.pop(); break;
      case "think": sfx.blip(); break;
      case "kwq": sfx.blip(); break;
      case "kwa": sfx.pop(); break;
      case "exintro": sfx.whoosh(); break;
      case "ex": sfx.pop(); break;
      case "whyintro": sfx.whoosh(); break;
      case "why": if (b.good) sfx.good(); else sfx.bad(); break;
      case "ans": sfx.fanfare(); break;
      case "tip": sfx.sparkle(); break;
    }
  }, []);

  /* đồng hồ: lấy audio.currentTime làm chuẩn cho phụ đề + hình ảnh */
  useEffect(() => {
    if (!manifest) return;
    let raf = 0;
    const bs = manifest.beats;
    const loop = () => {
      const a = audioRef.current;
      if (a) {
        const t = a.currentTime;
        let idx = bs.length - 1;
        for (let i = 0; i < bs.length; i++) {
          if (t < bs[i].t1) { idx = i; break; }
        }
        if (idx !== idxRef.current) {
          const prev = idxRef.current;
          idxRef.current = idx;
          setBeatIdx(idx);
          if (!a.paused && (idx === prev + 1 || (prev === -1 && idx === 0))) fire(bs[idx]);
        }
        if (progRef.current) progRef.current.style.width = `${Math.min(100, (t / manifest.dur) * 100)}%`;
        if (timeRef.current) timeRef.current.textContent = `${fmt(t)} / ${fmt(manifest.dur)}`;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [manifest, fire]);

  /* tải trước câu kế tiếp */
  useEffect(() => {
    if (!manifest || !beat || q >= items.length) return;
    if (beatIdx === Math.floor(manifest.beats.length * 0.6)) {
      fetch(`/audio/q${pad(q + 1)}.json`).catch(() => {});
      fetch(`/audio/q${pad(q + 1)}.mp3`).catch(() => {});
    }
  }, [beatIdx, manifest, beat, q, items.length]);

  const onEnded = () => {
    if (auto && qRef.current < items.length) {
      wantPlay.current = true;
      setQ(qRef.current + 1);
    } else {
      setPlaying(false);
      wantPlay.current = false;
    }
  };

  const start = () => {
    initAudio();
    startMusic();
    wantPlay.current = true;
    setStarted(true);
    audioRef.current?.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  };
  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (!started) return start();
    if (a.paused) {
      initAudio();
      wantPlay.current = true;
      void a.play();
      setPlaying(true);
    } else {
      wantPlay.current = false;
      a.pause();
      setPlaying(false);
    }
  };
  const go = (n: number) => {
    const t = Math.max(1, Math.min(items.length, n));
    if (t === q) {
      if (audioRef.current) audioRef.current.currentTime = 0;
    } else setQ(t);
  };
  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!manifest || !audioRef.current) return;
    const r = e.currentTarget.getBoundingClientRect();
    audioRef.current.currentTime = ((e.clientX - r.left) / r.width) * manifest.dur;
  };
  const jumpBeat = (d: number) => {
    if (!manifest || !audioRef.current) return;
    const i = Math.max(0, Math.min(manifest.beats.length - 1, beatIdx + d));
    audioRef.current.currentTime = manifest.beats[i].t0 + 0.01;
  };
  const toggleFs = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void boxRef.current?.requestFullscreen();
  };

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT") return;
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      if (e.code === "ArrowRight") jumpBeat(1);
      if (e.code === "ArrowLeft") jumpBeat(-1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  /* chọn cảnh */
  const sceneKey = !beat ? "load" : ["title", "hook"].includes(beat.k) ? "title" : ["ask", "opt", "think", "count"].includes(beat.k) ? "q" : ["kwq", "kwa"].includes(beat.k) ? `kw${beat.j}` : beat.k === "ex" ? `ex${beat.idx}` : ["whyintro", "why", "ans"].includes(beat.k) ? "rev" : beat.k;
  let scene: React.ReactNode = null;
  if (beat) {
    switch (beat.k) {
      case "title":
      case "hook": scene = <TitleScene item={item} topic={topic} />; break;
      case "ask":
      case "opt":
      case "think":
      case "count": scene = <QuestionScene item={item} beat={beat} getTime={getTime} />; break;
      case "kwq":
      case "kwa": scene = <KeywordScene beat={beat} topic={topic} />; break;
      case "exintro": scene = <BannerScene emoji="💡" title="VÍ DỤ MINH HỌA" sub="Nhìn một lần là hiểu!" />; break;
      case "ex": scene = <StageScene beat={beat} topic={topic} />; break;
      case "whyintro":
      case "why":
      case "ans": scene = <ReviewScene item={item} beat={beat} />; break;
      case "tip": scene = <BannerScene emoji={beat.emoji ?? "🧠"} title="MẸO NHỚ" sub={`Câu ${item.n} xong rồi!`} />; break;
    }
  }
  const showSub = beat && beat.sub && beat.k !== "count" && beat.k !== "title";
  const subLen = beat?.sub?.length ?? 0;
  const credit = credits[topic.photo];

  const stageW = fs ? "min(100vw, 177.78vh)" : "min(100%, calc((100vh - 220px) * 1.7778))";

  return (
    <div className="mx-auto flex w-full max-w-[1500px] flex-col gap-4 px-3 pb-10 pt-4">
      <audio ref={audioRef} preload="auto" onEnded={onEnded} onPause={() => setPlaying(false)} onPlay={() => setPlaying(true)} />

      <div ref={boxRef} className="w-full" style={fs ? { height: "100vh", display: "grid", placeItems: "center", background: "#000" } : {}}>
        <div ref={stageRef} className="relative mx-auto overflow-hidden rounded-2xl bg-slate-950 shadow-2xl" style={{ width: stageW, aspectRatio: "16 / 9" }}>
          <div style={{ width: 1920, height: 1080, transform: `scale(${scale})`, transformOrigin: "top left", position: "absolute", left: 0, top: 0 }} className="font-sans text-white">
            {/* nền: ảnh thật + lớp phủ */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img key={topic.photo} src={`/photos/${topic.photo}.jpg`} alt="" className="kenburns absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(2,6,23,.62) 0%, rgba(2,6,23,.80) 60%, rgba(2,6,23,.92) 100%)" }} />
            <div className="blob absolute -left-40 top-40 h-[560px] w-[560px] rounded-full opacity-30 blur-3xl" style={{ background: topic.color }} />
            <div className="blob2 absolute -right-40 bottom-10 h-[520px] w-[520px] rounded-full opacity-25 blur-3xl" style={{ background: "#6366f1" }} />

            {/* HUD */}
            <div className="absolute left-[60px] right-[60px] top-[26px] flex items-center justify-between">
              <div className="flex items-center gap-4 rounded-full bg-black/55 px-8 py-3 text-[38px] font-extrabold backdrop-blur">
                <Em text="📝" size={44} /> CÂU {item.n}
                <span className="text-white/60">/ {items.length}</span>
              </div>
              <div className="max-w-[900px] truncate rounded-full px-8 py-3 text-[32px] font-bold text-slate-900" style={{ background: topic.color }}>
                {topic.name}
              </div>
              <div className="rounded-full bg-black/55 px-8 py-3 text-[34px] font-extrabold tracking-widest text-amber-300 backdrop-blur">MLN122</div>
            </div>

            {/* vùng cảnh */}
            <div className="absolute" style={{ left: 110, top: 122, width: 1700, height: 740 }}>
              <motion.div key={`${q}-${sceneKey}`} initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.35 }} className="h-full w-full">
                {scene}
              </motion.div>
              {beat?.k === "ans" && <Confetti key={`c${q}`} />}
              {!beat && <div className="grid h-full w-full place-items-center text-[64px] font-bold text-white/80">Đang tải bài giảng…</div>}
            </div>

            {/* phụ đề */}
            {showSub && (
              <div className="absolute flex items-center justify-center" style={{ left: 110, right: 110, top: 868, height: 164 }}>
                <motion.div
                  key={`${q}-${beatIdx}`}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className="max-w-full rounded-[28px] bg-black/70 px-10 py-4 text-center font-bold leading-snug text-white backdrop-blur"
                  style={{ fontSize: subLen > 80 ? 42 : 48, textShadow: "0 2px 8px rgba(0,0,0,.8)" }}
                >
                  {beat?.sub}
                </motion.div>
              </div>
            )}

            {credit && (
              <div className="absolute bottom-[14px] left-[60px] text-[22px] font-medium text-white/65">
                Ảnh nền: “{credit.title}” – {credit.author} / Pexels · Biểu tượng: Twemoji (CC-BY 4.0)
              </div>
            )}
            

            {!started && (
              <div className="absolute inset-0 z-20 grid place-items-center bg-slate-950/80 backdrop-blur-sm">
                <div className="flex flex-col items-center gap-8 text-center">
                  <div className="flex gap-6">
                    {["🏭", "🪙", "📈", "🧠"].map((e, i) => (
                      <motion.div key={e} animate={{ y: [0, -24, 0] }} transition={{ repeat: Infinity, duration: 2.4, delay: i * 0.25 }}>
                        <Em text={e} size={150} />
                      </motion.div>
                    ))}
                  </div>
                  <div className="text-[96px] font-extrabold leading-tight">100 câu MLN122<br />hiểu tới tận gốc</div>
                  <div className="text-[44px] font-semibold text-white/85">Giọng nam · Hoạt hình minh họa · Giải thích từng đáp án</div>
                  <button onClick={start} className="rounded-full bg-gradient-to-r from-amber-400 to-rose-500 px-20 py-6 text-[64px] font-extrabold text-slate-900 shadow-2xl transition hover:scale-105">
                    ▶ BẮT ĐẦU HỌC
                  </button>
                  <div className="text-[34px] text-white/70">Bật loa để nghe giảng nhé!</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* điều khiển */}
      <div className="rounded-2xl bg-slate-900 p-4 text-white shadow-xl">
        <div className="mb-3 h-3 w-full cursor-pointer rounded-full bg-white/15" onClick={seek}>
          <div ref={progRef} className="h-full rounded-full bg-gradient-to-r from-amber-400 to-rose-500" style={{ width: "0%" }} />
        </div>
        <div className="flex flex-wrap items-center gap-3 text-base font-semibold">
          <button onClick={() => go(q - 1)} className="rounded-lg bg-white/10 px-4 py-2 hover:bg-white/20">⏮ Câu trước</button>
          <button onClick={() => jumpBeat(-1)} className="rounded-lg bg-white/10 px-3 py-2 hover:bg-white/20" title="Lùi một đoạn (←)">⏪</button>
          <button onClick={toggle} className="rounded-lg bg-amber-400 px-6 py-2 font-extrabold text-slate-900 hover:bg-amber-300">{playing ? "⏸ Tạm dừng" : "▶ Phát"}</button>
          <button onClick={() => jumpBeat(1)} className="rounded-lg bg-white/10 px-3 py-2 hover:bg-white/20" title="Tới một đoạn (→)">⏩</button>
          <button onClick={() => go(q + 1)} className="rounded-lg bg-white/10 px-4 py-2 hover:bg-white/20">Câu sau ⏭</button>
          <span ref={timeRef} className="ml-2 tabular-nums text-white/80">0:00 / 0:00</span>
          <div className="ml-auto flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2">
              Tốc độ
              <select value={rate} onChange={(e) => setRate(Number(e.target.value))} className="rounded-md bg-white/10 px-2 py-1">
                {[0.85, 1, 1.1, 1.25].map((r) => (<option key={r} value={r} className="text-slate-900">{r}x</option>))}
              </select>
            </label>
            <button onClick={() => setAuto(!auto)} className={`rounded-lg px-3 py-2 ${auto ? "bg-emerald-500 text-slate-900" : "bg-white/10"}`}>Tự chuyển câu: {auto ? "Bật" : "Tắt"}</button>
            <button onClick={() => { const v = !music; setMusicState(v); setMusic(v); }} className={`rounded-lg px-3 py-2 ${music ? "bg-sky-400 text-slate-900" : "bg-white/10"}`}>🎵 Nhạc nền</button>
            <button onClick={() => { const v = !sound; setSound(v); setSfx(v); }} className={`rounded-lg px-3 py-2 ${sound ? "bg-sky-400 text-slate-900" : "bg-white/10"}`}>🔊 Hiệu ứng</button>
            <button onClick={toggleFs} className="rounded-lg bg-white/10 px-3 py-2 hover:bg-white/20">⛶ Toàn màn hình</button>
          </div>
        </div>
      </div>

      {/* mục lục */}
      <div className="rounded-2xl bg-slate-900 p-5 text-white shadow-xl">
        <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-xl font-extrabold">Chọn câu để xem ({items.length} câu · khoảng {Math.round(totalDur / 60)} phút)</h2>
          <a href="/credits" className="text-sm text-sky-300 underline">Nguồn ảnh, âm thanh & ghi công</a>
        </div>
        <div className="mb-3 flex flex-wrap gap-3 text-sm">
          {Object.entries(topics).map(([k, t]) => (
            <span key={k} className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-1">
              <i className="inline-block h-3 w-3 rounded-full" style={{ background: t.color }} />
              {t.name}
            </span>
          ))}
        </div>
        <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
          {items.map((it) => (
            <button
              key={it.n}
              onClick={() => { wantPlay.current = started; go(it.n); }}
              title={it.q}
              className="rounded-lg py-2 text-base font-extrabold text-slate-900 transition hover:scale-105"
              style={{ background: topics[it.t].color, outline: it.n === q ? "4px solid #fff" : "none", opacity: it.n === q ? 1 : 0.8 }}
            >
              {it.n}
            </button>
          ))}
        </div>
        <p className="mt-4 line-clamp-2 text-sm text-white/70">Đang xem câu {item.n}: {item.q}</p>
      </div>
    </div>
  );
}
