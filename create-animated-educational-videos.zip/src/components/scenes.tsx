"use client";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Em } from "./Em";
import { sfx } from "@/lib/sfx";
import type { Beat, QItem, TopicInfo } from "@/lib/types";

const LETTERS = ["A", "B", "C", "D"];
const LCOLOR = ["#38bdf8", "#fbbf24", "#34d399", "#f472b6"];
const spring = { type: "spring" as const, stiffness: 240, damping: 18 };

/* ---------------- Tiêu đề ---------------- */
const DECO: Record<string, string[]> = {
  cnh: ["🏭", "⚙️", "🤖", "🚀"],
  hh: ["🪙", "🛒", "📦", "💵"],
  tb: ["💰", "📈", "🏭", "👷"],
  dq: ["🏦", "👑", "🌍", "🤝"],
  vn: ["🇻🇳", "🏛️", "🧭", "🌱"],
  lt: ["📚", "🔍", "💡", "🎓"],
};
export function TitleScene({ item, topic }: { item: QItem; topic: TopicInfo }) {
  const deco = DECO[item.t];
  return (
    <div className="relative flex h-full w-full items-center justify-center">
      {deco.map((e, i) => (
        <motion.div
          key={i}
          className="absolute"
          style={{ left: i < 2 ? "1%" : "85%", top: i % 2 ? "58%" : "6%" }}
          initial={{ opacity: 0, y: 80, scale: 0.4 }}
          animate={{ opacity: 0.95, y: [0, -24, 0], scale: 1 }}
          transition={{ opacity: { delay: 0.2 + i * 0.15 }, scale: { ...spring, delay: 0.2 + i * 0.15 }, y: { repeat: Infinity, duration: 3 + i * 0.4, delay: i * 0.3 } }}
        >
          <Em text={e} size={150} />
        </motion.div>
      ))}
      <motion.div
        className="relative z-10 flex flex-col items-center"
        initial={{ scale: 0.4, opacity: 0, rotate: -8 }}
        animate={{ scale: 1, opacity: 1, rotate: 0 }}
        transition={spring}
      >
        <div className="text-[64px] font-extrabold tracking-[0.35em] text-white/90">CÂU SỐ</div>
        <div
          className="grid place-items-center rounded-[64px] px-24 py-4 font-extrabold leading-none text-white shadow-2xl"
          style={{ fontSize: 330, background: `linear-gradient(135deg, ${topic.color}, #6366f1)`, boxShadow: `0 30px 90px ${topic.color}88` }}
        >
          {item.n}
        </div>
        <div className="mt-8 rounded-full bg-black/45 px-12 py-4 text-[46px] font-bold text-white backdrop-blur" style={{ border: `3px solid ${topic.color}` }}>
          {topic.name}
        </div>
      </motion.div>
    </div>
  );
}

/* ---------------- Danh sách đáp án ---------------- */
export type OptState = "hidden" | "show" | "active" | "good" | "bad" | "dim";
export function OptionList({ opts, state, fontSize, cols, big }: { opts: string[]; state: (i: number) => OptState; fontSize: number; cols: number; big?: boolean }) {
  return (
    <div className="grid w-full gap-4" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
      {opts.map((o, i) => {
        const s = state(i);
        const good = s === "good";
        const bad = s === "bad";
        return (
          <motion.div
            key={i}
            initial={false}
            animate={{ opacity: s === "hidden" ? 0 : s === "dim" ? 0.4 : 1, y: s === "hidden" ? 40 : 0, scale: s === "active" || good ? 1.025 : 1 }}
            transition={spring}
            className="relative flex items-center gap-6 rounded-[26px] border-4 px-7 py-3"
            style={{
              background: good ? "linear-gradient(90deg,#065f46,#10b981)" : bad ? "linear-gradient(90deg,#7f1d1d,#b91c1c)" : s === "active" ? "rgba(255,255,255,0.26)" : "rgba(15,23,42,0.72)",
              borderColor: good ? "#6ee7b7" : bad ? "#fca5a5" : s === "active" ? "#fde047" : "rgba(255,255,255,0.18)",
              boxShadow: s === "active" ? "0 0 50px rgba(253,224,71,.5)" : good ? "0 0 60px rgba(52,211,153,.6)" : "none",
            }}
          >
            <div className="grid shrink-0 place-items-center rounded-full font-extrabold text-slate-900" style={{ width: 72, height: 72, fontSize: 42, background: LCOLOR[i] }}>
              {LETTERS[i]}
            </div>
            <div className="flex-1 font-bold leading-snug text-white" style={{ fontSize }}>
              {o}
            </div>
            {(good || bad) && (
              <motion.div initial={{ scale: 0, rotate: -60 }} animate={{ scale: 1, rotate: 0 }} transition={spring} className="shrink-0">
                <Em text={good ? "✅" : "❌"} size={72} />
              </motion.div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}

export function optLayout(item: QItem) {
  const maxLen = Math.max(...item.opts.map((o) => o.length));
  const cols = maxLen <= 58 ? 2 : 1;
  const fontSize = cols === 2 ? 44 : maxLen <= 100 ? 40 : maxLen <= 170 ? 32 : 28;
  return { cols, fontSize };
}

/* ---------------- Đếm ngược ---------------- */
export function Countdown({ beat, getTime }: { beat: Beat; getTime: () => number }) {
  const [n, setN] = useState(3);
  const last = useRef(4);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const left = Math.max(1, Math.min(3, Math.ceil(beat.t1 - getTime() - 0.02)));
      if (left !== last.current) {
        last.current = left;
        setN(left);
        sfx.tick();
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [beat, getTime]);
  return (
    <div className="pointer-events-none absolute inset-0 grid place-items-center rounded-[32px] bg-slate-950/80">
      <motion.div key={n} initial={{ scale: 2.2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={spring} className="relative grid place-items-center">
        <svg width="420" height="420" viewBox="0 0 420 420" className="absolute">
          <circle cx="210" cy="210" r="190" fill="rgba(15,23,42,.8)" stroke="rgba(255,255,255,.2)" strokeWidth="16" />
          <motion.circle cx="210" cy="210" r="190" fill="none" stroke="#fde047" strokeWidth="16" strokeLinecap="round" strokeDasharray="1194" initial={{ strokeDashoffset: 0 }} animate={{ strokeDashoffset: 1194 }} transition={{ duration: 1, ease: "linear" }} transform="rotate(-90 210 210)" />
        </svg>
        <div className="relative text-[260px] font-extrabold leading-none text-yellow-300">{n}</div>
      </motion.div>
      <div className="absolute bottom-10 text-[54px] font-extrabold text-white">Bạn chọn đáp án nào?</div>
    </div>
  );
}

/* ---------------- Đọc đề ---------------- */
export function QuestionScene({ item, beat, getTime }: { item: QItem; beat: Beat; getTime: () => number }) {
  const len = item.q.length;
  const qSize = len > 230 ? 40 : len > 160 ? 44 : len > 95 ? 48 : len > 55 ? 52 : 62;
  const { cols, fontSize } = optLayout(item);
  const reveal = beat.k === "ask" ? -1 : beat.k === "opt" ? (beat.i ?? 0) : 3;
  const st = (i: number): OptState => (i > reveal ? "hidden" : beat.k === "opt" && beat.i === i ? "active" : "show");
  return (
    <div className="relative flex h-full w-full flex-col justify-center gap-5">
      <motion.div initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} transition={spring} className="rounded-[30px] border-4 border-white/25 bg-slate-900/85 px-10 py-5">
        <div className="mb-1 flex items-center gap-3 text-[30px] font-extrabold tracking-wider text-amber-300">
          <Em text="📝" size={44} /> ĐỀ BÀI
        </div>
        <div className="font-extrabold leading-snug text-white" style={{ fontSize: qSize }}>
          {item.q}
        </div>
      </motion.div>
      <OptionList opts={item.opts} state={st} fontSize={fontSize} cols={cols} />
      {beat.k === "count" && <Countdown beat={beat} getTime={getTime} />}
    </div>
  );
}

/* ---------------- Từ khóa ---------------- */
export function KeywordScene({ beat, topic }: { beat: Beat; topic: TopicInfo }) {
  const term = beat.term ?? "";
  const size = term.length <= 10 ? 150 : term.length <= 18 ? 118 : term.length <= 28 ? 90 : 70;
  const deep = beat.k === "kwa" && beat.step === 2;
  return (
    <div className="flex h-full w-full items-center justify-center gap-16" key={`kw-${beat.j}`}>
      <motion.div initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={spring} className="relative shrink-0">
        <motion.div animate={{ y: [0, -22, 0] }} transition={{ repeat: Infinity, duration: 2.4 }}>
          <Em text={beat.emoji ?? "💡"} size={340} />
        </motion.div>
        {[0, 1, 2].map((i) => (
          <motion.div key={i} className="absolute" style={{ left: i * 120 - 20, top: -30 }} animate={{ opacity: [0, 1, 0], y: [0, -60] }} transition={{ repeat: Infinity, duration: 2.2, delay: i * 0.5 }}>
            <Em text={beat.k === "kwq" ? "❓" : "✨"} size={70} />
          </motion.div>
        ))}
      </motion.div>
      <div className="flex max-w-[1050px] flex-col items-start gap-6">
        <motion.div initial={{ x: -60, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={spring} className="rounded-full px-9 py-3 text-[40px] font-extrabold text-slate-900" style={{ background: topic.color }}>
          {beat.k === "kwq" ? "TỪ KHÓA – ĐẶT CÂU HỎI" : deep ? "ĐÀO SÂU HƠN" : "GIẢI NGHĨA"}
        </motion.div>
        <motion.div
          key={term}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={spring}
          className="font-extrabold leading-tight text-white"
          style={{ fontSize: size, textShadow: "0 6px 40px rgba(0,0,0,.6)" }}
        >
          “{term}”
        </motion.div>
        <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 0.7 }} className="h-3 w-full origin-left rounded-full" style={{ background: `linear-gradient(90deg, ${topic.color}, transparent)` }} />
      </div>
    </div>
  );
}

/* ---------------- Cảnh chuyển ---------------- */
export function BannerScene({ emoji, title, sub }: { emoji: string; title: string; sub?: string }) {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-6">
      <motion.div initial={{ scale: 0, rotate: -40 }} animate={{ scale: 1, rotate: 0 }} transition={spring}>
        <motion.div animate={{ rotate: [0, 8, -8, 0] }} transition={{ repeat: Infinity, duration: 3 }}>
          <Em text={emoji} size={300} />
        </motion.div>
      </motion.div>
      <motion.div initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...spring, delay: 0.15 }} className="text-[110px] font-extrabold tracking-wide text-white" style={{ textShadow: "0 8px 40px rgba(0,0,0,.6)" }}>
        {title}
      </motion.div>
      {sub && <div className="text-[48px] font-bold text-white/85">{sub}</div>}
    </div>
  );
}

/* ---------------- Sân khấu ví dụ ---------------- */
function Item({ e, label, size, delay = 0, bob = true }: { e: string; label?: string; size: number; delay?: number; bob?: boolean }) {
  return (
    <motion.div initial={{ scale: 0, rotate: -25, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} transition={{ ...spring, delay }} className="flex flex-col items-center gap-3">
      <motion.div animate={bob ? { y: [0, -14, 0] } : {}} transition={{ repeat: Infinity, duration: 2.2, delay: delay + 0.6 }}>
        <Em text={e} size={size} />
      </motion.div>
      {label ? (
        <div className="max-w-[460px] rounded-2xl bg-white/15 px-6 py-2 text-center text-[40px] font-extrabold leading-tight text-white backdrop-blur">{label}</div>
      ) : null}
    </motion.div>
  );
}
function Arrow({ delay = 0, color = "#fde047" }: { delay?: number; color?: string }) {
  return (
    <motion.svg width="150" height="80" viewBox="0 0 150 80" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay }}>
      <motion.path d="M5 40 H125" stroke={color} strokeWidth="14" strokeLinecap="round" fill="none" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay, duration: 0.5 }} />
      <motion.path d="M100 12 L135 40 L100 68" stroke={color} strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" fill="none" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: delay + 0.35, duration: 0.3 }} />
      <motion.circle r="9" cy="40" fill="#fff" animate={{ cx: [5, 130], opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1.4, delay: delay + 0.8 }} />
    </motion.svg>
  );
}

export function StageScene({ beat, topic }: { beat: Beat; topic: TopicInfo }) {
  const es = (beat.e ?? "").split(/\s+/).filter(Boolean);
  const ls = (beat.l ?? "").split("|");
  const n = es.length;
  const size = n <= 2 ? 250 : n === 3 ? 215 : n === 4 ? 175 : 150;
  const v = beat.v ?? "row";
  const gap = 0.42;
  let body: React.ReactNode;

  if (v === "big") {
    body = (
      <div className="relative flex flex-col items-center gap-6">
        <motion.div className="absolute h-[520px] w-[520px] rounded-full" style={{ background: `radial-gradient(${topic.color}77, transparent 70%)` }} animate={{ scale: [1, 1.15, 1] }} transition={{ repeat: Infinity, duration: 2.4 }} />
        <Item e={es[0] ?? "💡"} size={360} label={ls[0]} />
      </div>
    );
  } else if (v === "flow") {
    body = (
      <div className="flex items-center justify-center gap-4">
        {es.map((e, i) => (
          <div key={i} className="flex items-center gap-4">
            <Item e={e} label={ls[i]} size={size} delay={i * 2 * gap} />
            {i < n - 1 && <Arrow delay={i * 2 * gap + gap} />}
          </div>
        ))}
      </div>
    );
  } else if (v === "swap") {
    body = (
      <div className="relative flex h-[520px] w-[1100px] items-center justify-center">
        <motion.div className="absolute" initial={{ x: -330, scale: 0 }} animate={{ x: [-330, 330, -330], y: [0, -150, 0], scale: 1 }} transition={{ repeat: Infinity, duration: 3.2, ease: "easeInOut" }}>
          <Item e={es[0]} size={230} bob={false} delay={0} />
        </motion.div>
        <motion.div className="absolute" initial={{ x: 330, scale: 0 }} animate={{ x: [330, -330, 330], y: [0, 150, 0], scale: 1 }} transition={{ repeat: Infinity, duration: 3.2, ease: "easeInOut" }}>
          <Item e={es[1]} size={230} bob={false} delay={0.1} />
        </motion.div>
        <div className="absolute bottom-0 flex gap-[480px] text-[44px] font-extrabold text-white">
          <span className="rounded-2xl bg-white/15 px-6 py-2">{ls[0]}</span>
          <span className="rounded-2xl bg-white/15 px-6 py-2">{ls[1]}</span>
        </div>
        <motion.div className="absolute text-[150px] font-extrabold text-yellow-300" animate={{ rotate: [0, 180, 360] }} transition={{ repeat: Infinity, duration: 3.2 }}>
          ⇄
        </motion.div>
      </div>
    );
  } else if (v === "steps") {
    body = (
      <div className="flex items-end justify-center gap-6">
        {es.map((e, i) => (
          <motion.div key={i} className="flex flex-col items-center" initial={{ opacity: 0, y: 80 }} animate={{ opacity: 1, y: 0 }} transition={{ ...spring, delay: i * 0.5 }}>
            <Em text={e} size={size * 0.8} />
            <div className="mt-3 grid w-[440px] place-items-center rounded-t-3xl px-4 text-center text-[38px] font-extrabold leading-tight text-slate-900" style={{ height: 130 + i * 95, background: `linear-gradient(180deg, ${["#fde047", "#fb923c", "#f472b6", "#a78bfa", "#38bdf8"][i % 5]}, #ffffffcc)` }}>
              {ls[i]}
            </div>
          </motion.div>
        ))}
      </div>
    );
  } else if (v === "vs") {
    body = (
      <div className="flex items-center justify-center gap-10">
        <motion.div initial={{ x: -400, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={spring} className="flex w-[640px] flex-col items-center gap-4 rounded-[40px] border-4 border-sky-300/60 bg-sky-500/20 px-8 py-8">
          <Em text={es[0]} size={230} />
          <div className="text-center text-[48px] font-extrabold text-white">{ls[0]}</div>
        </motion.div>
        <motion.div animate={{ scale: [1, 1.25, 1] }} transition={{ repeat: Infinity, duration: 1.4 }} className="grid h-[150px] w-[150px] shrink-0 place-items-center rounded-full bg-rose-500 text-[68px] font-extrabold text-white shadow-2xl">
          VS
        </motion.div>
        <motion.div initial={{ x: 400, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={spring} className="flex w-[640px] flex-col items-center gap-4 rounded-[40px] border-4 border-amber-300/60 bg-amber-500/20 px-8 py-8">
          <Em text={es[1] ?? es[0]} size={230} />
          <div className="text-center text-[48px] font-extrabold text-white">{ls[1]}</div>
        </motion.div>
      </div>
    );
  } else if (v === "split") {
    const rest = es.slice(1);
    body = (
      <div className="flex items-center justify-center gap-10">
        <Item e={es[0]} label={ls[0]} size={250} />
        <Arrow delay={0.5} />
        <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${rest.length > 2 ? 2 : rest.length}, auto)` }}>
          {rest.map((e, i) => (
            <Item key={i} e={e} label={ls[i + 1]} size={rest.length > 2 ? 150 : 190} delay={0.9 + i * gap} />
          ))}
        </div>
      </div>
    );
  } else if (v === "merge") {
    const src = es.slice(0, -1);
    const last = es[n - 1];
    body = (
      <div className="flex items-center justify-center gap-8">
        <div className="flex items-center gap-6">
          {src.map((e, i) => (
            <Item key={i} e={e} label={ls[i]} size={src.length > 2 ? 150 : 185} delay={i * gap} />
          ))}
        </div>
        <Arrow delay={src.length * gap} />
        <motion.div initial={{ scale: 0 }} animate={{ scale: [0, 1.25, 1] }} transition={{ delay: src.length * gap + 0.6, duration: 0.7 }} className="flex flex-col items-center gap-3">
          <div className="rounded-full p-6" style={{ background: `radial-gradient(${topic.color}88, transparent 70%)` }}>
            <Em text={last} size={280} />
          </div>
          {ls[n - 1] && <div className="rounded-2xl bg-yellow-300 px-6 py-2 text-center text-[42px] font-extrabold text-slate-900">{ls[n - 1]}</div>}
        </motion.div>
      </div>
    );
  } else if (v === "loop") {
    const R = 235;
    body = (
      <div className="relative" style={{ width: 760, height: 620 }}>
        <motion.svg className="absolute inset-0" viewBox="0 0 760 620" animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 14, ease: "linear" }}>
          <ellipse cx="380" cy="310" rx="300" ry="230" fill="none" stroke="#fde047" strokeWidth="10" strokeDasharray="30 22" strokeLinecap="round" />
        </motion.svg>
        {es.map((e, i) => {
          const a = (i / n) * Math.PI * 2 - Math.PI / 2;
          return (
            <div key={i} className="absolute" style={{ left: 380 + R * 1.28 * Math.cos(a) - 110, top: 310 + R * Math.sin(a) - 100, width: 220 }}>
              <Item e={e} label={ls[i]} size={150} delay={i * gap} />
            </div>
          );
        })}
      </div>
    );
  } else if (v === "bars") {
    const bars = ls.map((s) => {
      const [name, val] = s.split(":");
      return { name, val: Number(val) || 0 };
    });
    const mx = Math.max(...bars.map((b) => b.val), 1);
    body = (
      <div className="flex items-end justify-center gap-14" style={{ height: 560 }}>
        {bars.map((b, i) => (
          <div key={i} className="flex flex-col items-center justify-end gap-3" style={{ width: 330 }}>
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ ...spring, delay: 0.5 + i * 0.4 }}>
              <Em text={es[i] ?? es[0]} size={130} />
            </motion.div>
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: Math.max(100, (b.val / mx) * 300) }}
              transition={{ delay: 0.3 + i * 0.4, duration: 0.9, ease: "easeOut" }}
              className="grid w-full place-items-start justify-center rounded-t-3xl pt-3 text-[56px] font-extrabold text-slate-900"
              style={{ background: `linear-gradient(180deg, ${["#38bdf8", "#fbbf24", "#34d399", "#f472b6"][i % 4]}, #ffffffaa)` }}
            >
              {b.val}
            </motion.div>
            <div className="w-full rounded-2xl bg-black/40 px-4 py-2 text-center text-[38px] font-extrabold leading-tight text-white">{b.name}</div>
          </div>
        ))}
      </div>
    );
  } else {
    body = (
      <div className="flex items-end justify-center gap-10">
        {es.map((e, i) => (
          <Item key={i} e={e} label={ls[i]} size={size} delay={i * gap} />
        ))}
      </div>
    );
  }
  return (
    <div className="relative flex h-full w-full items-center justify-center" key={`ex-${beat.idx}`}>
      <div className="absolute left-0 top-0 flex items-center gap-3 rounded-full bg-black/50 px-8 py-3 text-[38px] font-extrabold text-yellow-300 backdrop-blur">
        <Em text="💡" size={46} /> VÍ DỤ {(beat.idx ?? 0) + 1}/{beat.of ?? 1}
      </div>
      {body}
    </div>
  );
}

/* ---------------- Soi đáp án / chốt ---------------- */
export function ReviewScene({ item, beat }: { item: QItem; beat: Beat }) {
  const { cols, fontSize } = optLayout(item);
  const good = (i: number) => item.ans.includes(LETTERS[i]);
  const st = (i: number): OptState => {
    if (beat.k === "whyintro") return "show";
    if (beat.k === "why") {
      const c = beat.i ?? 0;
      if (i < c) return good(i) ? "good" : "bad";
      if (i === c) return good(i) ? "good" : "bad";
      return "show";
    }
    return good(i) ? "good" : "dim";
  };
  const isAns = beat.k === "ans";
  return (
    <div className="relative flex h-full w-full flex-col justify-center gap-5">
      <motion.div key={beat.k === "ans" ? "a" : "r"} initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-center gap-4 text-[58px] font-extrabold text-white">
        {isAns ? (
          <>
            <Em text="🎉" size={80} />
            <span className="rounded-full bg-emerald-400 px-12 py-2 text-slate-900">ĐÁP ÁN: {item.ans.split("").join(" + ")}</span>
            <Em text="🏆" size={80} />
          </>
        ) : (
          <>
            <Em text="🔎" size={70} /> SOI TỪNG ĐÁP ÁN
          </>
        )}
      </motion.div>
      <OptionList opts={item.opts} state={st} fontSize={fontSize} cols={cols} />
    </div>
  );
}

/* ---------------- Confetti ---------------- */
export function Confetti() {
  const items = Array.from({ length: 26 }, (_, i) => ({ i, e: ["🎉", "⭐", "✨", "🎊", "🌟"][i % 5], x: (i * 73) % 100, d: 2.4 + (i % 5) * 0.5, delay: (i % 9) * 0.18 }));
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {items.map((c) => (
        <motion.div key={c.i} className="absolute" style={{ left: `${c.x}%`, top: -120 }} initial={{ y: -120, rotate: 0, opacity: 1 }} animate={{ y: 1100, rotate: 540, opacity: [1, 1, 0] }} transition={{ duration: c.d, delay: c.delay, ease: "easeIn" }}>
          <Em text={c.e} size={70} />
        </motion.div>
      ))}
    </div>
  );
}
