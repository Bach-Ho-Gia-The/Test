"use client";
import { useState } from "react";

const EMOJI_RE = /\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20e3/u;

export function emojiCode(g: string) {
  const cps = Array.from(g).map((c) => (c.codePointAt(0) as number).toString(16));
  const zwj = cps.includes("200d");
  return (zwj ? cps : cps.filter((c) => c !== "fe0f")).join("-");
}

function One({ g, size }: { g: string; size: number }) {
  const [bad, setBad] = useState(false);
  if (bad) return <span style={{ fontSize: size * 0.8 }}>{g}</span>;
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={`/emoji/${emojiCode(g)}.svg`}
      alt=""
      width={size}
      height={size}
      draggable={false}
      onError={() => setBad(true)}
      style={{ width: size, height: size, display: "inline-block", verticalAlign: "middle" }}
    />
  );
}

/** Hiển thị emoji bằng Twemoji SVG (đồng nhất trên mọi thiết bị, không phụ thuộc font hệ thống). */
export function Em({ text, size = 64 }: { text: string; size?: number }) {
  const seg = new Intl.Segmenter("vi", { granularity: "grapheme" });
  const parts = Array.from(seg.segment(text), (s) => s.segment);
  return (
    <>
      {parts.map((g, i) => (EMOJI_RE.test(g) ? <One key={i} g={g} size={size} /> : <span key={i}>{g}</span>))}
    </>
  );
}
