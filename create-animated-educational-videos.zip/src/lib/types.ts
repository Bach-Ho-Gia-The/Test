export type TopicKey = "cnh" | "hh" | "tb" | "dq" | "vn" | "lt";

export interface Beat {
  k: string;
  t0: number;
  t1: number;
  sub?: string;
  first?: boolean;
  i?: number;
  j?: number;
  term?: string;
  emoji?: string;
  step?: number;
  v?: string;
  e?: string;
  l?: string;
  idx?: number;
  of?: number;
  good?: boolean;
  letters?: string;
}
export interface Manifest {
  n: number;
  dur: number;
  beats: Beat[];
}
export interface QItem {
  n: number;
  t: TopicKey;
  q: string;
  opts: string[];
  ans: string;
  dur: number;
}
export interface TopicInfo {
  name: string;
  color: string;
  photo: string;
}
