// Hiệu ứng âm thanh tổng hợp bằng WebAudio (không cần file) + nhạc nền nhẹ.
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicBus: GainNode | null = null;
let sfxOn = true;
let musicOn = true;
let musicTimer: ReturnType<typeof setInterval> | null = null;
let nextBar = 0;
let barIdx = 0;

export function initAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
    musicBus = ctx.createGain();
    musicBus.gain.value = musicOn ? 1 : 0;
    musicBus.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, t0: number, dur: number, type: OscillatorType = "sine", vol = 0.2, dest?: AudioNode, slideTo?: number) {
  if (!ctx || !master) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(dest ?? master);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}

function noise(t0: number, dur: number, f0: number, f1: number, vol = 0.12) {
  if (!ctx || !master) return;
  const len = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const f = ctx.createBiquadFilter();
  f.type = "bandpass";
  f.Q.value = 1.2;
  f.frequency.setValueAtTime(f0, t0);
  f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + dur * 0.35);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f);
  f.connect(g);
  g.connect(master);
  src.start(t0);
}

const now = () => (ctx ? ctx.currentTime : 0);
const guard = (fn: () => void) => () => {
  if (sfxOn && ctx) fn();
};

export const sfx = {
  pop: guard(() => {
    const t = now();
    tone(520, t, 0.12, "sine", 0.16, undefined, 920);
  }),
  whoosh: guard(() => noise(now(), 0.45, 300, 2600, 0.1)),
  tick: guard(() => tone(1100, now(), 0.08, "square", 0.07)),
  go: guard(() => {
    const t = now();
    tone(660, t, 0.18, "triangle", 0.18);
    tone(990, t + 0.1, 0.25, "triangle", 0.18);
  }),
  blip: guard(() => {
    const t = now();
    tone(440, t, 0.1, "triangle", 0.12);
    tone(660, t + 0.09, 0.14, "triangle", 0.12);
  }),
  good: guard(() => {
    const t = now();
    [523, 659, 784].forEach((f, i) => tone(f, t + i * 0.08, 0.3, "triangle", 0.18));
    tone(1047, t + 0.26, 0.4, "sine", 0.14);
  }),
  bad: guard(() => {
    const t = now();
    tone(240, t, 0.28, "sawtooth", 0.08, undefined, 140);
  }),
  fanfare: guard(() => {
    const t = now();
    [523, 659, 784, 1047].forEach((f, i) => tone(f, t + i * 0.11, 0.45, "triangle", 0.2));
    tone(1319, t + 0.5, 0.7, "sine", 0.16);
    noise(t + 0.45, 0.5, 2000, 6000, 0.05);
  }),
  sparkle: guard(() => {
    const t = now();
    [1568, 2093, 2637].forEach((f, i) => tone(f, t + i * 0.06, 0.2, "sine", 0.07));
  }),
};

export function setSfx(on: boolean) {
  sfxOn = on;
}
export function setMusic(on: boolean) {
  musicOn = on;
  if (musicBus && ctx) musicBus.gain.setTargetAtTime(on ? 1 : 0, ctx.currentTime, 0.2);
}

const PROG = [
  [220, 261.6, 329.6],
  [174.6, 220, 261.6],
  [261.6, 329.6, 392],
  [196, 246.9, 293.7],
];
function scheduleBars() {
  if (!ctx || !musicBus) return;
  const bus: AudioNode = musicBus;
  const beat = 60 / 88;
  while (nextBar < ctx.currentTime + 1.2) {
    const chord = PROG[barIdx % 4];
    for (let i = 0; i < 8; i++) {
      const f = chord[i % 3] * (i % 2 ? 2 : 1);
      tone(f, nextBar + i * beat * 0.5, beat * 0.9, "triangle", 0.03, bus);
    }
    chord.forEach((f) => tone(f / 2, nextBar, beat * 3.8, "sine", 0.02, bus));
    nextBar += beat * 4;
    barIdx++;
  }
}
export function startMusic() {
  if (!ctx || musicTimer) return;
  nextBar = ctx.currentTime + 0.1;
  musicTimer = setInterval(scheduleBars, 250);
}
export function stopMusic() {
  if (musicTimer) clearInterval(musicTimer);
  musicTimer = null;
}
