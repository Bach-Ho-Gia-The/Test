// Dựng content/cards100.json từ scripts/cards.raw.json (trích từ PDF) + vá tay các thẻ bị dính.
import fs from 'node:fs';
const raw = JSON.parse(fs.readFileSync('scripts/cards.raw.json','utf8'));
const typo = [
 [/đấy mạnh/g,'đẩy mạnh'],[/gắn liên/g,'gắn liền'],[/thữ ba/g,'thứ ba'],[/nhũng/g,'những'],[/Tư bàn/g,'Tư bản'],[/tư bàn/g,'tư bản'],
 [/tiên tệ/g,'tiền tệ'],[/tiên tê/g,'tiền tệ'],[/tê\?/g,'tệ?'],[/thi trường/g,'thị trường'],[/thị trưởng/g,'thị trường'],[/đinh hướng/g,'định hướng'],
 [/phần bổ/g,'phân bổ'],[/nên tảng/g,'nền tảng'],[/nhày vọt/g,'nhảy vọt'],[/kinh tế trí thức/g,'kinh tế tri thức'],[/chi có thể/g,'chỉ có thể'],
 [/thế k[ỳý]\b/g,'thế kỷ'],[/thế ký/g,'thế kỷ'],[/thể chế/gi,m=>m],[/Thế chế/g,'Thể chế'],[/thế chế/g,'thể chế'],[/tố chức/g,'tổ chức'],[/xã hôi/g,'xã hội'],
 [/Đàng Cộng/g,'Đảng Cộng'],[/đàng V/g,'đảng V'],[/đàng VI/g,'đảng VI'],[/Căn củ/g,'Căn cứ'],[/mỡ rộng/g,'mở rộng'],[/lao đông/g,'lao động'],[/tư nhãn/g,'tư nhân'],
 [/phúc tạp/g,'phức tạp'],[/cố điển/g,'cổ điển'],[/cố điên/g,'cổ điển'],[/phát triên/g,'phát triển'],[/cổ đai/g,'cổ đại'],[/\|$/g,''],[/đễn/g,'đến'],
 [/Xét vẽ/g,'Xét về'],[/lới ích/g,'lợi ích'],[/canh tranh/g,'cạnh tranh'],[/thưởng xuyên/g,'thường xuyên'],[/Xuất khẩu tư bàn/g,'Xuất khẩu tư bản'],
 [/thăng dư/g,'thặng dư'],[/Lương lơi nhuận/g,'Lượng lợi nhuận'],[/Đối tương/g,'Đối tượng'],[/điện tũ/g,'điện tử'],[/võ tuyến/g,'vô tuyến'],[/phấm thặng/g,'phẩm thặng'],
 [/sản phấm/g,'sản phẩm'],[/trinh sản xuất/g,'trình sản xuất'],[/quá trinh/g,'quá trình'],[/gia trị/g,'giá trị'],[/trù đi/g,'trừ đi'],[/rủ ro/g,'rủi ro'],[/phố biến/g,'phổ biến'],
 [/Châu âu/g,'Châu Âu'],[/tuần thủ/g,'tuân thủ'],[/thoa mãn/g,'thỏa mãn'],[/cấn thiết/g,'cần thiết'],[/Nghiên cứu về cách mạng/g,'Nghiên cứu về cách mạng'],
 [/hạn chế của chủ nghĩa/g,'hạn chế của chủ nghĩa'],[/sữ dụng/g,'sử dụng'],[/Chuyễn/g,'Chuyển'],[/Chúc năng/g,'Chức năng'],[/phúc tạp/g,'phức tạp'],[/thủ công/g,'thủ công'],
 [/nữa cuối/g,'nửa cuối'],[/nữa đầu/g,'nửa đầu'],[/nửa đầu thế kỷ XIX\|/g,'nửa đầu thế kỷ XIX'],[/chữ không/g,'chứ không'],[/đây đủ/g,'đầy đủ'],[/tiên tệ/g,'tiền tệ'],
 [/quyên hàng/g,'quyền hàng'],[/độc quyên/g,'độc quyền'],[/Thúc đấy/g,'Thúc đẩy'],[/thúc đấy/g,'thúc đẩy'],[/Quá trình độc quyền hàng hóa/g,'Quá trình độc quyền hàng hóa'],
 [/điều chính cung cầu/g,'điều chỉnh cung cầu'],[/can thiệp/g,'can thiệp'],[/khoa học-công nghệ/g,'khoa học - công nghệ'],[/hoá/g,'hóa'],[/hiếu là/g,'hiểu là'],
 [/Chọn các ý không đúng/g,'Chọn các ý không đúng'],[/đại hội mấy/g,'Đại hội mấy'],[/đảng\b/g,'Đảng'],[/Đại hội đàng/g,'Đại hội Đảng'],[/Đại hội đảng/g,'Đại hội Đảng'],[/Đại hội Đảng V\b/g,'Đại hội Đảng V'],
 [/\s{2,}/g,' ']
];
const extra=[[/khóang/gi,m=>m[0]+'hoáng'],[/hóá/g,'hóa'],[/hàng hóa là gi\?/g,'hàng hóa là gì?'],[/từ đầu mà có/g,'từ đâu mà có'],[/xuất phát từ đầu\?/g,'xuất phát từ đâu?'],[/Lý do đề Việt Nam/g,'Lý do để Việt Nam'],[/tại ở đầu và năm nào/g,'ở đâu và năm nào'],[/các mạng công nghiệp/g,'cách mạng công nghiệp'],[/Điền vào chỗ trống: C\. Mác/g,'Điền vào chỗ trống: C. Mác'],[/Lượng tỷ suất lợi nhuận là/g,'Tỷ suất lợi nhuận là'],[/hiện nay phải gắn liền/g,'hiện nay phải gắn liền'],[/thể chế được phân thành bao nhiêu phương án\?/g,'thể chế được phân thành những loại nào? (chọn nhiều đáp án)']];
const fix = s => { let t=s; for(const [a,b] of typo){ if(typeof b==='function') continue; t=t.replace(a,b);} for(const [a,b] of extra) t=t.replace(a,b); return t.trim(); };
const P = n => raw[n-1];
const mk = (n, c, ans) => ({ n, q: fix(c.q), opts: c.opts.map(fix), ans: ans ?? c.ans });
const out = [];
for (let n=1;n<=92;n++) out.push(mk(n,P(n)));
// patch riêng
const find=(n)=>out[n-1];
find(54).q = 'Lý thuyết bàn tay vô hình của Adam Smith được hiểu là: (chọn 3 phương án đúng)'; find(54).ans='ABC';
find(55).q = 'Thị trường giải quyết ba vấn đề kinh tế nào?';
find(78).ans='ABC';
find(79).q = 'Chọn các ý không đúng về sản phẩm và hàng hóa:';
// 93, 94 thủ công (bị dính trong PDF parser)
out.push({n:93,q:'Mệnh đề nào sau đây là ý không đúng về lao động phức tạp?',opts:[
 'Trong cùng một thời gian lao động, lao động phức tạp tạo ra nhiều giá trị hơn lao động giản đơn',
 'Lao động phức tạp là lao động giản đơn nhân bội lên',
 'Lao động phức tạp là lao động trí tuệ của người lao động có trình độ cao',
 'Lao động phức tạp là lao động trải qua đào tạo, huấn luyện'],ans:'C'});
out.push({n:94,q:'Những thành tựu và hạn chế của chủ nghĩa tư bản bắt nguồn từ mâu thuẫn cơ bản của chủ nghĩa tư bản. Mâu thuẫn cơ bản đó là:',opts:P(93).opts.length===4&&P(93).opts[0].startsWith('Mâu thuẫn giữa trình độ xã hội hóa cao')?P(93).opts.map(fix):[
 'Mâu thuẫn giữa trình độ xã hội hóa cao của lực lượng sản xuất và chế độ sở hữu tư nhân về tư liệu sản xuất',
 'Mâu thuẫn giữa giai cấp công nhân và giai cấp tư sản',
 'Mâu thuẫn giữa người lao động làm thuê và giai cấp bóc lột',
 'Mâu thuẫn giữa trình độ xã hội hóa của lực lượng sản xuất và quan hệ sản xuất'],ans:'A'});
out.push(mk(95,P(94)));
const c96 = mk(96,P(95)); c96.ans='ABD'; out.push(c96);
const c97 = mk(97,P(96)); c97.q='Chi phí sản xuất tư bản chủ nghĩa:'; out.push(c97);
out.push(mk(98,P(97)));
out.push(mk(99,P(98)));
out.push(mk(100,P(99)));
fs.mkdirSync('content',{recursive:true});
fs.writeFileSync('content/cards100.json',JSON.stringify(out,null,1));
console.log('cards',out.length);
