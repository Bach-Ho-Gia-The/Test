// Sinh kịch bản (beat) + giọng đọc nam (vi-VN-NamMinhNeural) cho từng câu.
// Mỗi beat = 1 dòng phụ đề = 1 đoạn TTS => hình ảnh/phụ đề bám theo mốc thời gian thật của audio.
// Chạy:  node scripts/gen-audio.mjs [từ] [đến] [--force]
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { b01 } from "../content/questions/b01.ts";
import { b02 } from "../content/questions/b02.ts";
import { b03 } from "../content/questions/b03.ts";
import { b04 } from "../content/questions/b04.ts";
import { b05 } from "../content/questions/b05.ts";
import { b06 } from "../content/questions/b06.ts";
import { b07 } from "../content/questions/b07.ts";
import { b08 } from "../content/questions/b08.ts";
import { b09 } from "../content/questions/b09.ts";
import { b10 } from "../content/questions/b10.ts";

const CONTENT = { ...b01, ...b02, ...b03, ...b04, ...b05, ...b06, ...b07, ...b08, ...b09, ...b10 };
const CARDS = JSON.parse(fs.readFileSync("content/cards100.json", "utf8"));
const VOICE = "vi-VN-NamMinhNeural";
const RATE = "+6%";
const FRAME = 0.024; // 48kbps mono 24kHz MPEG-2 L3: 144 byte = 24ms
const FRAME_BYTES = 144;
const OUT = "public/audio";
const CACHE = ".cache/tts";
fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(CACHE, { recursive: true });

const args = process.argv.slice(2);
const force = args.includes("--force");
const nums = args.filter((a) => /^\d+$/.test(a)).map(Number);
const FROM = nums[0] ?? 1;
const TO = nums[1] ?? nums[0] ?? 100;

/* ---------- chuẩn hóa lời đọc ---------- */
const D = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"];
function viNum(n) {
  if (n < 10) return D[n];
  if (n < 20) return "mười" + (n % 10 ? " " + (n % 10 === 5 ? "lăm" : D[n % 10]) : "");
  if (n < 100) {
    const t = Math.floor(n / 10), u = n % 10;
    return D[t] + " mươi" + (u ? " " + (u === 1 ? "mốt" : u === 5 ? "lăm" : D[u]) : "");
  }
  if (n < 1000) {
    const h = Math.floor(n / 100), r = n % 100;
    return D[h] + " trăm" + (r ? (r < 10 ? " lẻ " + D[r] : " " + viNum(r)) : "");
  }
  const th = Math.floor(n / 1000), r = n % 1000;
  return viNum(th) + " nghìn" + (r ? (r < 100 ? " không trăm " + (r < 10 ? "lẻ " + D[r] : viNum(r)) : " " + viNum(r)) : "");
}
const ROMAN = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9, X: 10, XI: 11, XII: 12, XIII: 13, XIV: 14, XV: 15, XVI: 16, XVII: 17, XVIII: 18, XIX: 19, XX: 20, XXI: 21 };
const NAMES = [
  [/Paul A\.\s?Samuelson/g, "Pôn Xa-muên-xơn"], [/David Begg/g, "Đa-vít Béc"], [/Stanley Fischer/g, "Xten-li Phi-sờ"],
  [/Rudiger Dornbusch/g, "Ru-đi-gơ Đoóc-bu"], [/David Ricardo/g, "Đa-vít Ri-các-đô"], [/William Petty/g, "Uy-li-am Pét-ty"],
  [/Thomas Mun/g, "Tô-mát Mun"], [/Adam Smith/g, "A-đam Xmít"], [/Karl Marx|K\. Marx/g, "Các Mác"],
  [/V\.\s?I\.\s?Lênin/g, "Vờ I Lê-nin"], [/Ph\.\s?Ăngghen/g, "Phri-đrích Ăng-ghen"], [/Ăngghen/g, "Ăng-ghen"], [/Lênin/g, "Lê-nin"],
  [/C\.\s?Mác/g, "Các Mác"], [/Cartel/gi, "cạc-ten"], [/CNTB/g, "chủ nghĩa tư bản"], [/KVII/g, "khu vực hai"], [/KVI/g, "khu vực một"],
  [/T-H-T'/g, "T, H, T phẩy"], [/H-T-H/g, "H, T, H"], [/T-H-T/g, "T, H, T"],
];
function speak(t) {
  let s = t;
  for (const [a, b] of NAMES) s = s.replace(a, b);
  s = s.replace(/(thế kỷ|Đại hội(?: Đảng| đảng)?)\s+([IVX]+)\b/g, (m, c, r) => (ROMAN[r] ? `${c} ${viNum(ROMAN[r])}` : m));
  s = s.replace(/(\d+)\s*[-–]\s*(\d+)/g, "$1 đến $2");
  s = s.replace(/\d+/g, (m) => viNum(Number(m)));
  s = s.replace(/%/g, " phần trăm").replace(/\b([mpMP])'/g, "$1 phẩy");
  s = s.replace(/\s[x×]\s/g, " nhân ").replace(/\s=\s/g, " bằng ");
  s = s.replace(/\.\.\.|…/g, ", ").replace(/_/g, " chỗ trống ").replace(/[“”"]/g, "").replace(/\(|\)/g, ", ");
  s = s.replace(/\s+/g, " ").replace(/,\s*,/g, ",").trim();
  return s;
}

/* ---------- cắt đoạn phụ đề ---------- */
function chunk(text, max = 96) {
  const sents = text.split(/(?<=[.!?])(?<!\b[A-Z]\.)(?<!\bPh\.)\s+/);
  let out = [];
  for (const s of sents) {
    if (s.length <= max) { out.push(s); continue; }
    const parts = s.split(/(?<=[,;:])\s+/);
    let cur = "";
    for (const p of parts) {
      if (cur && (cur + " " + p).length > max) { out.push(cur); cur = p; } else cur = cur ? cur + " " + p : p;
    }
    if (cur) out.push(cur);
  }
  // chia đôi theo từ nếu vẫn quá dài
  const fin = [];
  for (const s of out) {
    if (s.length <= 130) { fin.push(s); continue; }
    const w = s.split(" ");
    const cut = Math.ceil(w.length / Math.ceil(s.length / 100));
    for (let i = 0; i < w.length; i += cut) fin.push(w.slice(i, i + cut).join(" "));
  }
  // gộp đoạn quá ngắn
  const merged = [];
  for (const s of fin) {
    if (merged.length && (s.length < 16 || merged[merged.length - 1].length < 12) && (merged[merged.length - 1] + " " + s).length <= 120) merged[merged.length - 1] += " " + s;
    else merged.push(s);
  }
  return merged;
}

/* ---------- dựng beat cho 1 câu ---------- */
const L = ["A", "B", "C", "D"];
const EXINTRO = ["Hình dung thế này nhé!", "Cùng xem một ví dụ cho dễ hiểu!", "Đưa vào đời sống để dễ nhớ hơn nhé!", "Xem hình minh họa thật nhanh nào!"];
const WHYINTRO = ["Giờ ta soi từng đáp án một nhé!", "Bây giờ kiểm tra từng đáp án, xem vì sao đúng và vì sao sai!", "Đến lúc loại trừ từng phương án!"];
const THINK = ["Bạn chọn đáp án nào? Nghĩ nhanh trong ba giây nhé!", "Theo bạn, đáp án nào đúng? Ba giây suy nghĩ bắt đầu!", "Bạn nghiêng về đáp án nào? Cho bạn ba giây!"];

function buildBeats(n) {
  const c = CONTENT[n];
  const card = CARDS[n - 1];
  if (!c || !card) throw new Error("thiếu dữ liệu câu " + n);
  const beats = [];
  const push = (b) => beats.push(b);
  const pushText = (text, base, firstPrefix = null, opts = {}) => {
    const parts = chunk(text);
    parts.forEach((p, i) => {
      const pre = i === 0 ? firstPrefix : null;
      push({
        ...base,
        say: (pre ? pre.say + " " : "") + speak(p),
        sub: (pre ? pre.sub : "") + p,
        pad: i === parts.length - 1 ? (opts.padEnd ?? 0.22) : 0.1,
        first: i === 0,
      });
    });
  };
  // 1. mở đầu
  push({ k: "title", say: `Câu số ${viNum(n)}!`, sub: `Câu ${n}`, pad: 0.15 });
  pushText(c.h, { k: "hook" }, null, { padEnd: 0.4 });
  // 2. đọc đề
  pushText(card.q, { k: "ask" }, { say: "Đề bài.", sub: "" }, { padEnd: 0.3 });
  if (card.ans.length > 1) push({ k: "ask", say: "Chú ý, câu này có nhiều hơn một đáp án đúng!", sub: "Chú ý: chọn nhiều đáp án!", pad: 0.3 });
  card.opts.forEach((o, i) =>
    pushText(o, { k: "opt", i }, { say: `Đáp án ${L[i]}.`, sub: `${L[i]}. ` }, { padEnd: 0.25 })
  );
  push({ k: "think", say: THINK[n % 3], sub: THINK[n % 3], pad: 0.1 });
  push({ k: "count", silence: 3.1, sub: "3 … 2 … 1 …", pad: 0.0 });
  // 3. từ khóa
  c.k.forEach(([term, emoji, ask, a1, a2], j) => {
    pushText(ask, { k: "kwq", j, term, emoji }, null, { padEnd: 0.45 });
    pushText(a1, { k: "kwa", j, term, emoji, step: 1 }, null, { padEnd: 0.3 });
    if (a2) pushText(a2, { k: "kwa", j, term, emoji, step: 2 }, null, { padEnd: 0.35 });
  });
  // 4. ví dụ
  push({ k: "exintro", say: EXINTRO[n % 4], sub: EXINTRO[n % 4], pad: 0.25 });
  c.x.forEach(([say, v, e, l], idx) => pushText(say, { k: "ex", v, e, l: l || "", idx, of: c.x.length }, null, { padEnd: 0.4 }));
  // 5. soi đáp án
  push({ k: "whyintro", say: WHYINTRO[n % 3], sub: WHYINTRO[n % 3], pad: 0.2 });
  const ansSet = card.ans.split("");
  card.opts.forEach((_, i) => {
    const good = ansSet.includes(L[i]);
    const pre = { say: `Đáp án ${L[i]}. ${good ? "Chọn!" : "Loại!"}`, sub: `${L[i]}. ${good ? "Chọn!" : "Loại!"} ` };
    pushText(c.w[i], { k: "why", i, good }, pre, { padEnd: 0.4 });
  });
  // 6. chốt
  const letters = ansSet.length > 1 ? ansSet.slice(0, -1).join(", ") + " và " + ansSet[ansSet.length - 1] : ansSet[0];
  push({ k: "ans", letters: card.ans, say: `Vậy đáp án đúng là ${letters}!`, sub: `Đáp án: ${ansSet.join(", ")}`, pad: 0.4 });
  pushText(c.m, { k: "tip", emoji: c.me }, null, { padEnd: 1.2 });
  return beats;
}

/* ---------- TTS ---------- */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function synthOnce(text) {
  const tts = new MsEdgeTTS();
  await tts.setMetadata(VOICE, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
  const { audioStream } = tts.toStream(text, { rate: RATE });
  const chunks = [];
  await new Promise((resolve, reject) => {
    audioStream.on("data", (d) => chunks.push(d));
    audioStream.on("close", resolve);
    audioStream.on("error", reject);
  });
  try { tts.close(); } catch {}
  return Buffer.concat(chunks);
}
async function synth(text) {
  const key = crypto.createHash("sha1").update(VOICE + RATE + text).digest("hex");
  const f = path.join(CACHE, key + ".mp3");
  if (fs.existsSync(f)) return fs.readFileSync(f);
  let lastErr;
  for (let a = 0; a < 6; a++) {
    try {
      const buf = await Promise.race([synthOnce(text), sleep(30000).then(() => { throw new Error("timeout"); })]);
      if (buf.length > 600) {
        const trimmed = buf.subarray(0, buf.length - (buf.length % FRAME_BYTES));
        fs.writeFileSync(f, trimmed);
        return trimmed;
      }
      throw new Error("audio quá ngắn: " + text);
    } catch (e) { lastErr = e; await sleep(800 * (a + 1)); }
  }
  throw lastErr;
}
async function pool(items, limit, fn) {
  const res = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: limit }, async () => {
    while (i < items.length) { const k = i++; res[k] = await fn(items[k], k); }
  }));
  return res;
}

let SILENT = null;
function silentFrames(sec) {
  const frames = Math.max(0, Math.round(sec / FRAME));
  const first = fs.readdirSync(CACHE).find((f) => f.endsWith(".mp3"));
  if (!SILENT) {
    const b = fs.readFileSync(path.join(CACHE, first));
    const hdr = b.subarray(0, 4);
    SILENT = Buffer.concat([hdr, Buffer.alloc(FRAME_BYTES - 4)]);
  }
  return Buffer.concat(Array.from({ length: frames }, () => SILENT));
}

async function buildQuestion(n) {
  const beats = buildBeats(n);
  const need = beats.filter((b) => b.say);
  const bufs = await pool(need, 6, (b) => synth(b.say));
  let bi = 0;
  const parts = [];
  let t = 0;
  const outBeats = [];
  for (const b of beats) {
    let speech = null;
    if (b.say) speech = bufs[bi++];
    const speechSec = speech ? speech.length / FRAME_BYTES * FRAME : 0;
    const silSec = (b.silence || 0) + (b.pad || 0);
    const pad = silentFrames(silSec);
    const padSec = pad.length / FRAME_BYTES * FRAME;
    if (speech) parts.push(speech);
    parts.push(pad);
    const { say, pad: _p, silence, ...rest } = b;
    outBeats.push({ ...rest, t0: +t.toFixed(3), t1: +(t + speechSec + padSec).toFixed(3) });
    t += speechSec + padSec;
  }
  const mp3 = Buffer.concat(parts);
  const id = String(n).padStart(3, "0");
  fs.writeFileSync(path.join(OUT, `q${id}.mp3`), mp3);
  const dur = +(mp3.length / FRAME_BYTES * FRAME).toFixed(2);
  fs.writeFileSync(path.join(OUT, `q${id}.json`), JSON.stringify({ n, dur, beats: outBeats }));
  return { n, dur, beats: outBeats.length };
}

const idxFile = path.join(OUT, "index.json");
const index = fs.existsSync(idxFile) ? JSON.parse(fs.readFileSync(idxFile, "utf8")) : {};
for (let n = FROM; n <= TO; n++) {
  const id = String(n).padStart(3, "0");
  if (!force && fs.existsSync(path.join(OUT, `q${id}.mp3`)) && index[n]) { console.log("skip", n); continue; }
  const t0 = Date.now();
  try {
    const r = await buildQuestion(n);
    index[n] = { dur: r.dur, beats: r.beats };
    fs.writeFileSync(idxFile, JSON.stringify(index));
    console.log(`Q${n}: ${r.dur}s, ${r.beats} beats, ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  } catch (e) {
    console.error("LỖI câu", n, e?.message || e);
  }
}
const total = Object.values(index).reduce((s, x) => s + x.dur, 0);
console.log("Tổng thời lượng:", (total / 60).toFixed(1), "phút,", Object.keys(index).length, "câu");
