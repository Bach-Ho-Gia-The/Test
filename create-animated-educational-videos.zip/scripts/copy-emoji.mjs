// Copy đúng những emoji Twemoji (CC-BY 4.0) đã dùng vào public/emoji để không phụ thuộc font hệ thống.
import fs from "node:fs";
import path from "node:path";

const SRC = "node_modules/@twemoji/svg";
const OUT = "public/emoji";
fs.mkdirSync(OUT, { recursive: true });

const files = [];
const walk = (d) => {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f);
    if (fs.statSync(p).isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(f)) files.push(p);
  }
};
walk("content");
walk("src");
let text = files.map((f) => fs.readFileSync(f, "utf8")).join("\n");
text += fs.readFileSync("scripts/extra-emoji.txt", "utf8");
text = text.replace(/\u200d/g, "\u200d"); // giữ ZWJ

const re = /\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20e3|\u200d|\ufe0f/u;
const seg = new Intl.Segmenter("vi", { granularity: "grapheme" });
const set = new Set();
for (const s of seg.segment(text)) if (/\p{Extended_Pictographic}|\p{Regional_Indicator}/u.test(s.segment)) set.add(s.segment);

const code = (g) => {
  const cps = Array.from(g).map((c) => c.codePointAt(0).toString(16));
  const zwj = cps.includes("200d");
  return (zwj ? cps : cps.filter((c) => c !== "fe0f")).join("-");
};
let ok = 0;
const missing = [];
for (const g of set) {
  const c = code(g);
  const cps = Array.from(g).map((x) => x.codePointAt(0).toString(16));
  const cands = [c, cps.join("-"), cps.filter((x) => x !== "fe0f").join("-")];
  const hit = cands.find((x) => fs.existsSync(path.join(SRC, x + ".svg")));
  if (!hit) { missing.push(g + " " + c); continue; }
  fs.copyFileSync(path.join(SRC, hit + ".svg"), path.join(OUT, c + ".svg"));
  ok++;
}
console.log("emoji copied:", ok, "missing:", missing.length ? missing.join(" | ") : "none");
