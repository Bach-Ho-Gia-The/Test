import cards from "./cards100.json";
import type { QC, TopicKey } from "./types";
import { b01 } from "./questions/b01";
import { b02 } from "./questions/b02";
import { b03 } from "./questions/b03";
import { b04 } from "./questions/b04";
import { b05 } from "./questions/b05";
import { b06 } from "./questions/b06";
import { b07 } from "./questions/b07";
import { b08 } from "./questions/b08";
import { b09 } from "./questions/b09";
import { b10 } from "./questions/b10";

export const CONTENT: Record<number, QC> = { ...b01, ...b02, ...b03, ...b04, ...b05, ...b06, ...b07, ...b08, ...b09, ...b10 };
export interface Card { n: number; q: string; opts: string[]; ans: string }
export const CARDS = cards as Card[];

export const TOPICS: Record<TopicKey, { name: string; color: string; photo: string }> = {
  cnh: { name: "Công nghiệp hóa & Cách mạng công nghiệp", color: "#38bdf8", photo: "cnh" },
  hh: { name: "Hàng hóa – Tiền tệ – Thị trường", color: "#fbbf24", photo: "hh" },
  tb: { name: "Giá trị thặng dư – Tư bản", color: "#f472b6", photo: "tb" },
  dq: { name: "Độc quyền – Tư bản tài chính", color: "#a78bfa", photo: "dq" },
  vn: { name: "Kinh tế thị trường định hướng XHCN – Việt Nam", color: "#34d399", photo: "vn" },
  lt: { name: "Lý luận – Trường phái – Phương pháp", color: "#fb923c", photo: "lt" },
};
