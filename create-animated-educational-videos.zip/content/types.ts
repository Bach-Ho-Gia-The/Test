// Kiểu dữ liệu kịch bản. Mọi chuỗi "say" vừa là LỜI ĐỌC vừa là PHỤ ĐỀ (nên viết như văn nói, số/viết tắt đọc được).
export type TopicKey = "cnh" | "hh" | "tb" | "dq" | "vn" | "lt";

// Hiệu ứng minh họa (preset) cho 1 beat ví dụ
export type Preset =
  | "row" // các biểu tượng xuất hiện lần lượt thành hàng
  | "flow" // hàng có mũi tên + xung chạy (chuỗi quá trình)
  | "swap" // hai vật đổi chỗ cho nhau (trao đổi)
  | "steps" // bậc thang đi lên
  | "vs" // đối đầu: trái / phải
  | "split" // một → nhiều
  | "merge" // nhiều → một (phần tử cuối là kết quả)
  | "big" // một biểu tượng thật to
  | "loop" // vòng tuần hoàn
  | "stack" // chồng nhiều lên (nhân lên)
  | "bars"; // cột so sánh, nhãn dạng "Tên:số"

// [lời đọc, preset, "emoji emoji emoji", "nhãn1|nhãn2|nhãn3"]
export type Ex = [say: string, v: Preset, e: string, l?: string];

// [thuật ngữ hiển thị, emoji, câu tự hỏi, giải thích 1, (giải thích 2 / câu hỏi sâu hơn)]
export type Kw = [term: string, emoji: string, ask: string, a1: string, a2?: string];

export interface QC {
  t: TopicKey;
  /** câu mở đầu gây tò mò */
  h: string;
  /** phân tích từ khóa (tự đặt câu hỏi) */
  k: Kw[];
  /** ví dụ minh họa (2–4 beat) */
  x: Ex[];
  /** lý do cho từng đáp án A,B,C,(D) */
  w: string[];
  /** mẹo nhớ (lời đọc) + emoji */
  m: string;
  me: string;
}
