import type { QC } from "../types";

export const b10: Record<number, QC> = {
  91: {
    t: "vn",
    h: "Kinh tế thị trường ở Việt Nam không giống nhau ở mọi nơi. Có nhiều cấp độ cùng tồn tại, đan xen nhau!",
    k: [
      ["đan xen", "🧶", "Vì sao nhiều cấp độ cùng tồn tại?", "Việt Nam vừa có chợ nhỏ, sản xuất nhỏ, vừa có sàn giao dịch hiện đại. Các cấp độ đan xen nhau.", "Ba cấp độ đó là sản xuất hàng hóa nhỏ, kinh tế thị trường sơ khai, và kinh tế thị trường hiện đại."],
    ],
    x: [
      ["Cô bán rau ngoài chợ: sản xuất hàng hóa nhỏ.", "big", "🥬", "Hàng hóa nhỏ"],
      ["Chợ đầu mối, đại lý: thị trường sơ khai.", "big", "🏪", "Sơ khai"],
      ["Sàn thương mại điện tử, chứng khoán: hiện đại. Và tất cả cùng tồn tại.", "big", "📱", "Hiện đại"],
    ],
    w: [
      "Sản xuất hàng hóa nhỏ, thị trường sơ khai, thị trường hiện đại đan xen. Đúng.",
      "Hàng hóa lớn không phải cấp độ đầu tiên.",
      "Thị trường hoàn thiện không phải cấp độ mà ta đang ở.",
      "Sai cả ở cấp độ đầu lẫn cấp độ giữa.",
    ],
    m: "Nhỏ, sơ khai, hiện đại: đan xen cùng nhau!",
    me: "🧶",
  },
  92: {
    t: "tb",
    h: "Máy móc và nguyên liệu, cái nào chuyển giá trị vào sản phẩm nhanh, cái nào chậm? Đó là cách chia tư bản cố định và lưu động!",
    k: [
      ["tư bản cố định", "🏗️", "Cố định khác lưu động thế nào?", "Tư bản cố định như máy móc, nhà xưởng: chuyển giá trị sang sản phẩm từng phần qua nhiều lần sản xuất.", "Tư bản lưu động như nguyên liệu, tiền công: chuyển toàn bộ giá trị vào sản phẩm chỉ sau một lần sản xuất."],
    ],
    x: [
      ["Máy may dùng nhiều năm, mỗi chiếc áo chỉ nhận một ít giá trị của máy.", "flow", "⚙️ 👕", "Máy may|Áo"],
      ["Vải thì chỉ dùng một lần, vào áo là hết.", "flow", "🧶 👕", "Vải|Áo"],
      ["Khác nhau ở cách chuyển giá trị: từng phần hay một lần.", "vs", "⚙️ 🧶", "Cố định|Lưu động"],
    ],
    w: [
      "Phương thức chuyển giá trị sang sản phẩm. Đúng căn cứ.",
      "Vai trò trong tạo giá trị thặng dư là căn cứ chia tư bản bất biến và khả biến.",
      "Sự thay đổi về lượng cũng thuộc cách chia bất biến, khả biến.",
    ],
    m: "Cố định hay lưu động: nhìn cách chuyển giá trị!",
    me: "⚙️",
  },
  93: {
    t: "tb",
    h: "Lao động phức tạp có đặc điểm gì? Câu này hỏi ý KHÔNG đúng, nên cần đọc từng chữ!",
    k: [
      ["lao động phức tạp", "🎓", "Lao động phức tạp là gì?", "Là lao động phải qua đào tạo, huấn luyện. Nó tạo ra nhiều giá trị hơn trong cùng thời gian, vì được xem là lao động giản đơn nhân bội lên.", "Nói chỉ là lao động trí tuệ của người trình độ cao là hẹp, vì thợ lành nghề làm bằng tay cũng là lao động phức tạp."],
    ],
    x: [
      ["Một thợ bình thường may một cái áo.", "big", "🧵", "Lao động giản đơn"],
      ["Một nhà thiết kế qua đào tạo tạo ra bộ trang phục có giá trị gấp nhiều lần.", "bars", "🧵 🎨", "Giản đơn:10|Phức tạp:30"],
      ["Nên lao động phức tạp là lao động giản đơn nhân bội lên.", "big", "✖️", "Nhân bội"],
    ],
    w: [
      "Tạo ra nhiều giá trị hơn lao động giản đơn. Ý đúng.",
      "Là lao động giản đơn nhân bội lên. Ý đúng.",
      "Nói là lao động trí tuệ của người trình độ cao thì hẹp. Bộ đề chọn đây là ý không đúng.",
      "Là lao động trải qua đào tạo, huấn luyện. Ý đúng.",
    ],
    m: "Phức tạp là qua đào tạo và nhân bội!",
    me: "🎓",
  },
  94: {
    t: "tb",
    h: "Tất cả thành tựu và hạn chế của chủ nghĩa tư bản đều bắt nguồn từ một mâu thuẫn gốc. Mâu thuẫn đó là gì?",
    k: [
      ["mâu thuẫn cơ bản", "⚡", "“Mâu thuẫn cơ bản” là gì?", "Là mâu thuẫn gốc, từ đó nảy sinh các mâu thuẫn khác. Đó là sản xuất ngày càng xã hội hóa, nhưng tư liệu sản xuất vẫn thuộc về tư nhân.", "Nhiều người cùng làm trong một dây chuyền, nhưng thành quả vào túi một ông chủ."],
    ],
    x: [
      ["Hàng nghìn công nhân cùng làm trong một nhà máy: trình độ xã hội hóa cao.", "row", "👷 👷 👷", "Cùng làm|Cùng làm|Cùng làm"],
      ["Nhưng nhà máy thuộc về một ông chủ.", "big", "👔", "Sở hữu tư nhân"],
      ["Làm chung nhưng sở hữu riêng. Đó là mâu thuẫn cơ bản.", "vs", "👷 👔", "Xã hội hóa|Sở hữu tư nhân"],
    ],
    w: [
      "Mâu thuẫn giữa trình độ xã hội hóa cao của lực lượng sản xuất và chế độ sở hữu tư nhân. Đúng.",
      "Công nhân và tư sản là biểu hiện, không phải gốc.",
      "Làm thuê và bóc lột cũng chỉ là biểu hiện.",
      "Nói chung chung về lực lượng và quan hệ, thiếu mất chữ sở hữu tư nhân.",
    ],
    m: "Làm chung, hưởng riêng!",
    me: "⚡",
  },
  95: {
    t: "cnh",
    h: "Ơ, câu này giống hệt câu năm mươi sáu! Gặp lại thì ôn nhanh, xem bạn còn nhớ không nhé!",
    k: [
      ["điện và dây chuyền", "🏭", "Nhắc lại: lần hai gồm hai chữ nào?", "Điện và dây chuyền. Điện cho sức mạnh, dây chuyền cho tốc độ và sản xuất hàng loạt.", "Nhìn thấy máy hơi nước thì nhớ lần một, thấy máy tính thì nhớ lần ba."],
    ],
    x: [
      ["Điện và động cơ điện thắp sáng nhà máy.", "big", "⚡", "Điện"],
      ["Dây chuyền chuyên môn hóa chạy liên tục.", "flow", "🔩 🚪 🎨", "Bắt ốc|Lắp cửa|Sơn"],
      ["Hai thứ ghép lại, xe hơi ra đời hàng loạt.", "big", "🚗", "Sản xuất hàng loạt"],
    ],
    w: [
      "Điện, động cơ điện và dây chuyền chuyên môn hóa. Đúng đặc trưng lần hai.",
      "Máy hơi nước là của lần một.",
      "Hơi nước cơ khí hóa cũng là lần một.",
      "Công nghệ thông tin là của lần ba.",
    ],
    m: "Lần hai là điện cộng dây chuyền!",
    me: "⚡",
  },
  96: {
    t: "vn",
    h: "Thể chế có nhiều loại, nếu chia theo lĩnh vực chính của xã hội. Câu này chọn nhiều đáp án, hãy đếm cho kỹ!",
    k: [
      ["lĩnh vực chính của xã hội", "🧩", "Có những lĩnh vực chính nào?", "Đáp án của bộ đề gồm ba loại: thể chế chính trị, thể chế kinh tế và thể chế xã hội.", "Văn hóa cũng là lĩnh vực quan trọng, nhưng bộ đề không đưa vào đáp án đúng của câu này."],
    ],
    x: [
      ["Thể chế chính trị: tổ chức và vận hành quyền lực nhà nước.", "big", "🏛️", "Chính trị"],
      ["Thể chế kinh tế: luật chơi cho sản xuất và thị trường.", "big", "💹", "Kinh tế"],
      ["Thể chế xã hội: quy định về an sinh, việc làm, đời sống.", "big", "🤝", "Xã hội"],
    ],
    w: [
      "Thể chế chính trị. Đúng, chọn.",
      "Thể chế kinh tế. Đúng, chọn.",
      "Thể chế văn hóa không nằm trong đáp án đúng của bộ đề.",
      "Thể chế xã hội. Đúng, chọn.",
    ],
    m: "Chính trị, kinh tế, xã hội: ba lĩnh vực!",
    me: "🧩",
  },
  97: {
    t: "tb",
    h: "Nhà tư bản bỏ ra bao nhiêu để làm ra một món hàng, và món hàng đó thực sự đáng bao nhiêu? Hai con số này không bằng nhau!",
    k: [
      ["chi phí sản xuất tư bản chủ nghĩa", "🧾", "Chi phí gồm những gì? Vì sao nhỏ hơn giá trị?", "Chi phí chỉ gồm tư bản bất biến cộng tư bản khả biến, tức c cộng v. Giá trị hàng hóa còn có thêm giá trị thặng dư m.", "Thiếu phần m, nên chi phí luôn nhỏ hơn giá trị hàng hóa."],
    ],
    x: [
      ["Chi phí của nhà tư bản: máy móc nguyên liệu một trăm, tiền công năm mươi.", "row", "🏭 👷", "c = 100|v = 50"],
      ["Giá trị hàng hóa còn có thêm phần thặng dư hai mươi.", "bars", "🧾 📦", "Chi phí:150|Giá trị:170"],
      ["Chi phí nhỏ hơn giá trị đúng bằng phần thặng dư.", "big", "✨", "Phần thặng dư"],
    ],
    w: [
      "Bằng giá trị hàng hóa là sai, vì thiếu phần thặng dư.",
      "Lớn hơn giá trị hàng hóa cũng sai.",
      "Chi phí sản xuất nhỏ hơn giá trị hàng hóa. Đúng.",
      "Không xác định là sai, vì công thức rất rõ ràng.",
    ],
    m: "Chi phí bằng c cộng v, giá trị bằng chi phí cộng m!",
    me: "🧾",
  },
  98: {
    t: "tb",
    h: "Tăng năng suất và tăng cường độ cùng lúc, mỗi cái gấp đôi. Kết quả không phải gấp bốn ở mọi thứ đâu! Cùng tính nhé.",
    k: [
      ["tăng đồng thời", "✖️", "Tính từng bước như thế nào?", "Tăng cường độ lên hai lần thì tổng số hàng và tổng giá trị đều gấp đôi, giá trị một hàng không đổi.", "Tăng năng suất lên hai lần thì số hàng gấp đôi, giá trị một hàng giảm một nửa, tổng giá trị không đổi."],
    ],
    x: [
      ["Bước một, tăng cường độ hai lần: hàng gấp đôi, tổng giá trị gấp đôi.", "bars", "📦 📦", "Ban đầu:100|Sau cường độ:200"],
      ["Bước hai, tăng năng suất hai lần: hàng gấp đôi nữa, nhưng giá trị mỗi hàng giảm một nửa.", "bars", "📦 📦", "Sau cường độ:200|Sau năng suất:400"],
      ["Kết quả: hàng gấp bốn, giá trị một hàng giảm hai lần, tổng giá trị gấp hai.", "row", "📦 ➗ 💰", "Hàng ×4|Mỗi hàng ÷2|Tổng giá trị ×2"],
    ],
    w: [
      "Giá trị một hàng giảm hai lần, tổng giá trị tăng hai lần. Đúng.",
      "Tổng số hàng tăng hai lần là thiếu, thực tế tăng bốn lần.",
      "Hàng tăng bốn lần thì đúng, nhưng tổng giá trị tăng bốn lần là sai.",
    ],
    m: "Cường độ thêm giá trị, năng suất chỉ thêm số hàng!",
    me: "📦",
  },
  99: {
    t: "dq",
    h: "Chủ nghĩa tư bản độc quyền có năm đặc điểm kinh tế cơ bản nhất. Bạn có đếm đủ năm không?",
    k: [
      ["năm đặc điểm", "🖐️", "Năm đặc điểm đó là gì?", "Một, tập trung sản xuất và các tổ chức độc quyền. Hai, tư bản tài chính. Ba, xuất khẩu tư bản. Bốn, các tổ chức độc quyền phân chia thị trường thế giới. Năm, các cường quốc phân chia lãnh thổ.", "Chọn đáp án đủ năm mục. Các đáp án khác đều thiếu mất một mục."],
    ],
    x: [
      ["Một và hai: tập trung sản xuất thành độc quyền, ngân hàng hợp nhất với công nghiệp.", "flow", "🏭 🤝 🏦", "Độc quyền|Hợp nhất|Ngân hàng"],
      ["Ba: xuất khẩu tư bản ra nước ngoài.", "big", "✈️", "Xuất khẩu tư bản"],
      ["Bốn và năm: chia thị trường thế giới, chia lãnh thổ giữa các cường quốc.", "split", "🌍 🏢 🏢 🏢", "Thế giới|Tập đoàn|Tập đoàn|Tập đoàn"],
    ],
    w: [
      "Thiếu mất phân chia thế giới giữa các tổ chức độc quyền.",
      "Thiếu mất xuất khẩu tư bản.",
      "Thiếu mất tư bản tài chính.",
      "Đủ cả năm đặc điểm. Đúng.",
    ],
    m: "Năm ngón tay: sản xuất, tài chính, xuất khẩu, chia thị trường, chia lãnh thổ!",
    me: "🖐️",
  },
  100: {
    t: "tb",
    h: "Câu cuối cùng! Điều gì đã giúp chủ nghĩa tư bản ra đời nhanh chóng? Hãy chốt hạ thật đẹp nhé!",
    k: [
      ["tích lũy nguyên thủy", "🚀", "“Tích lũy nguyên thủy” là gì?", "Là quá trình tạo ra hai điều kiện: số tiền vốn lớn tập trung trong tay thiểu số, và một đội ngũ người làm thuê tự do vì mất hết tư liệu sản xuất.", "Có hai thứ đó, chủ nghĩa tư bản mới mọc lên nhanh chóng."],
    ],
    x: [
      ["Một: của cải, vàng bạc dồn vào tay một số ít người.", "big", "💰", "Vốn"],
      ["Hai: nông dân mất đất, buộc phải đi làm thuê.", "flow", "🧑‍🌾 🏚️ 🏭", "Nông dân|Mất đất|Làm thuê"],
      ["Vốn cộng người làm thuê, chủ nghĩa tư bản bùng lên.", "merge", "💰 👷 🏭", "Vốn|Người làm thuê|Chủ nghĩa tư bản"],
    ],
    w: [
      "Tích lũy nguyên thủy, nhân tố cơ bản tạo ra tiền vốn và người làm thuê.",
      "Giao thông vận tải chỉ hỗ trợ, không phải nhân tố cơ bản.",
      "Quy luật giá trị tác động, nhưng không tạo ra hai điều kiện đầu tiên.",
    ],
    m: "Tích lũy nguyên thủy là vốn cộng người làm thuê. Chúc mừng bạn đã hoàn thành một trăm câu!",
    me: "🎉",
  },
};
