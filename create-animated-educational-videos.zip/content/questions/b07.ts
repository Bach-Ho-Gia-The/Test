import type { QC } from "../types";

export const b07: Record<number, QC> = {
  61: {
    t: "hh",
    h: "Khi nào một sản phẩm biến thành hàng hóa? Chỉ khi những người làm ra chúng thật sự độc lập với nhau!",
    k: [
      ["lao động tư nhân độc lập", "🧍", "Vì sao phải “độc lập, không phụ thuộc nhau”?", "Nếu cùng một chủ giao việc thì sản phẩm chỉ chuyển nội bộ, không mua bán. Khi mỗi người làm riêng, quyết riêng, sản phẩm mới phải trao đổi qua thị trường.", "Lúc đối diện nhau như vậy, sản phẩm mang tên là hàng hóa."],
    ],
    x: [
      ["Trong một gia đình, mẹ nấu cơm cho cả nhà, không ai phải trả tiền.", "big", "🍲", "Không mua bán"],
      ["Hai quán ăn độc lập thì phải mua bán với nhau.", "swap", "🍜 🥖", "Quán A|Quán B"],
      ["Sản phẩm của những người độc lập gặp nhau trên thị trường gọi là hàng hóa.", "big", "🛒", "Hàng hóa"],
    ],
    w: [
      "Những hàng hóa, đúng thuật ngữ của kinh tế chính trị.",
      "Sản vật trao đổi không phải là thuật ngữ chuẩn.",
      "Sản phẩm trao đổi nghe mơ hồ, chưa đúng thuật ngữ.",
    ],
    m: "Độc lập cộng trao đổi bằng hàng hóa!",
    me: "🛒",
  },
  62: {
    t: "vn",
    h: "Chủ đạo hay quyết định? Chỉ một chữ khác thôi mà đáp án thay đổi hoàn toàn. Phải phân tích từng chữ!",
    k: [
      ["chủ đạo", "🧭", "“Chủ đạo” là gì? Khác gì “quyết định”?", "Chủ đạo là dẫn dắt, định hướng, làm đầu tàu cho các thành phần khác đi theo, chứ không phải chiếm hết hay quyết định tất cả.", "Còn kinh tế tư nhân là một động lực quan trọng, tức đóng góp lớn thúc đẩy tăng trưởng."],
    ],
    x: [
      ["Đầu tàu kéo cả đoàn đi đúng đường.", "flow", "🚂 🚃 🚃", "Đầu tàu|Toa|Toa"],
      ["Kinh tế nhà nước là đầu tàu: nắm các lĩnh vực then chốt, định hướng và giữ ổn định.", "big", "🏛️", "Chủ đạo"],
      ["Kinh tế tư nhân là động cơ mạnh: tạo việc làm, thúc đẩy tăng trưởng.", "big", "🚀", "Động lực quan trọng"],
    ],
    w: [
      "Nhà nước giữ vai trò chủ đạo, tư nhân là một động lực quan trọng. Đúng.",
      "Dùng chữ “quyết định” cho nhà nước là sai từ, vai trò là chủ đạo.",
      "Tư nhân giữ vai trò chủ đạo là ngược hẳn.",
      "Tư nhân then chốt, nhà nước quyết định cũng sai cả hai vế.",
    ],
    m: "Nhà nước dẫn dắt, tư nhân thúc đẩy!",
    me: "🚂",
  },
  63: {
    t: "tb",
    h: "Tái sản xuất giản đơn và tái sản xuất mở rộng. Chia theo căn cứ nào? Chỉ một từ đúng!",
    k: [
      ["quy mô", "📏", "“Quy mô” là gì?", "Là kích cỡ của sản xuất, to hay nhỏ so với năm trước.", "Tái sản xuất giản đơn là giữ nguyên quy mô. Tái sản xuất mở rộng là quy mô lớn dần."],
    ],
    x: [
      ["Năm nay làm một nghìn cái bánh, năm sau cũng một nghìn: đó là giản đơn.", "bars", "🥖 🥖", "Năm nay:100|Năm sau:100"],
      ["Năm sau làm hai nghìn cái: đó là mở rộng.", "bars", "🥖 🥖", "Năm nay:100|Năm sau:200"],
      ["Chỉ cần nhìn xem quy mô có to ra hay không.", "big", "📏", "Quy mô"],
    ],
    w: [
      "Phạm vi là địa bàn rộng hẹp, không dùng để phân loại.",
      "Nội dung là sản xuất cái gì, không phải căn cứ chia.",
      "Căn cứ vào quy mô, đúng.",
    ],
    m: "Giữ nguyên là giản đơn, to lên là mở rộng!",
    me: "📏",
  },
  64: {
    t: "hh",
    h: "Một người thợ, nhưng lao động của họ có hai mặt! Hai mặt đó là gì?",
    k: [
      ["lao động trừu tượng", "🌀", "Lao động cụ thể và lao động trừu tượng khác nhau thế nào?", "Lao động cụ thể là công việc có hình thức cụ thể, như thợ mộc đóng bàn, tạo ra giá trị sử dụng.", "Lao động trừu tượng là sự hao phí sức lực, trí óc nói chung của người lao động, tạo ra giá trị của hàng hóa."],
    ],
    x: [
      ["Anh thợ mộc đẽo gọt thành cái bàn. Đó là mặt cụ thể.", "big", "🪑", "Cụ thể"],
      ["Bỏ qua việc đóng bàn hay may áo, ai cũng tiêu hao sức lực và thời gian. Đó là mặt trừu tượng.", "big", "⏱️", "Trừu tượng"],
      ["Một người lao động, hai mặt: cụ thể và trừu tượng.", "vs", "🪑 ⏱️", "Cụ thể|Trừu tượng"],
    ],
    w: [
      "Tư nhân và xã hội là tính chất, không phải hai mặt của lao động.",
      "Giản đơn, phức tạp là cách phân loại theo trình độ.",
      "Lao động cụ thể và lao động trừu tượng. Đúng hai mặt.",
    ],
    m: "Cụ thể tạo giá trị sử dụng, trừu tượng tạo giá trị!",
    me: "🪑",
  },
  65: {
    t: "lt",
    h: "Một câu nói nổi tiếng của Mác và Ăng-ghen về sức mạnh của giai cấp tư sản. Bạn điền được từ còn thiếu không?",
    k: [
      ["lực lượng sản xuất", "⚙️", "Vì sao điền “lực lượng sản xuất”?", "Chỉ trong chưa đầy một thế kỷ, giai cấp tư sản tạo ra máy móc, nhà máy, đường sắt, tức toàn bộ sức mạnh sản xuất của xã hội.", "Quan hệ sản xuất là quan hệ giữa người với người, không thể nói là đồ sộ hơn theo nghĩa vật chất như vậy."],
    ],
    x: [
      ["Chưa đầy một thế kỷ, tư sản xây nhà máy, đường sắt, tàu thủy.", "row", "🏭 🚂 🚢", "Nhà máy|Đường sắt|Tàu thủy"],
      ["Tất cả đều là sức mạnh tạo ra của cải, nhiều hơn mọi thế hệ trước cộng lại.", "bars", "🏛️ 🏭", "Các thế hệ trước:30|Riêng thời tư sản:100"],
      ["Đó là lực lượng sản xuất, và từ này lặp lại hai lần trong câu.", "big", "⚙️", "Lực lượng sản xuất"],
    ],
    w: [
      "Lực lượng sản xuất, đúng với câu nói của Mác và Ăng-ghen.",
      "Quan hệ sản xuất không thể đồ sộ hơn theo nghĩa này.",
      "Của cải nói chung chung, không đúng nguyên văn.",
      "Vật chất quá mơ hồ.",
    ],
    m: "Tư sản tạo ra lực lượng sản xuất đồ sộ!",
    me: "🏭",
  },
  66: {
    t: "lt",
    h: "Ai được Mác gọi là người sáng lập ra kinh tế chính trị cổ điển? Có bốn cái tên, nhưng chỉ một người xứng đáng.",
    k: [
      ["sáng lập", "🌟", "Vì sao là Pét-ty chứ không phải Xmít hay Ri-các-đô?", "Mác coi Pét-ty là người sáng lập vì ông là người đầu tiên nêu ý tưởng lao động tạo ra của cải và giá trị, mở đường cho cả trường phái.", "Xmít và Ri-các-đô là những người phát triển lên đỉnh cao sau này."],
    ],
    x: [
      ["Pét-ty, thế kỷ mười bảy, nói rằng lao động là cha, đất là mẹ của của cải.", "big", "🧓", "William Petty"],
      ["Xmít và Ri-các-đô kế tục, phát triển thành học thuyết hoàn chỉnh hơn.", "steps", "🌱 🌿 🌳", "Petty|Smith|Ricardo"],
      ["Người mở đường được Mác gọi là người sáng lập.", "big", "🥇", "Sáng lập"],
    ],
    w: [
      "Ri-các-đô là đại biểu đỉnh cao, không phải người sáng lập.",
      "Xmít là đại biểu tiêu biểu, nhưng đến sau Pét-ty.",
      "Uy-li-am Pét-ty, đúng người được Mác coi là sáng lập.",
      "Tô-mát Mun là đại biểu của chủ nghĩa trọng thương.",
    ],
    m: "Pét-ty mở đường, Xmít đi tiếp, Ri-các-đô cán đích!",
    me: "🥇",
  },
  67: {
    t: "tb",
    h: "Lợi ích kinh tế nghe rất quen, nhưng xét về bản chất thì nó là gì? Đào sâu nhé!",
    k: [
      ["lợi ích kinh tế", "🍰", "“Lợi ích kinh tế” thực chất là gì?", "Là cái con người nhận được từ hoạt động kinh tế, như thu nhập, lợi nhuận, tiền lương.", "Xét về bản chất, nó phản ánh quan hệ giữa người với người trong sản xuất, tức quan hệ sản xuất. Ai được chia bao nhiêu phụ thuộc quan hệ sở hữu và phân phối."],
    ],
    x: [
      ["Chủ xưởng và công nhân cùng làm ra chiếc bánh.", "big", "🍰", "Chiếc bánh"],
      ["Chia chiếc bánh thế nào phụ thuộc vào ai sở hữu nhà máy.", "split", "🍰 👔 👷", "Bánh|Chủ|Công nhân"],
      ["Cách chia đó chính là quan hệ sản xuất, và nó là bản chất của lợi ích kinh tế.", "big", "🤝", "Quan hệ sản xuất"],
    ],
    w: [
      "Quan hệ kinh tế xã hội nói rộng quá, chưa chính xác bằng quan hệ sản xuất.",
      "Quan hệ xã hội mang tính lịch sử là cách nói chung chung.",
      "Xét về bản chất, lợi ích kinh tế là quan hệ sản xuất.",
      "Quan hệ chính trị mang tính lợi ích là lệch sang lĩnh vực chính trị.",
    ],
    m: "Lợi ích là mặt kết quả, quan hệ sản xuất mới là bản chất!",
    me: "🤝",
  },
  68: {
    t: "hh",
    h: "Cạnh tranh thường bị coi là xấu. Nhưng trong kinh tế hàng hóa, nó có một tác dụng rất tích cực!",
    k: [
      ["năng động, nhạy bén", "⚡", "Vì sao cạnh tranh buộc con người phải năng động?", "Cạnh tranh nghĩa là có người khác đang giành khách của bạn. Nếu đứng yên, bạn bị bỏ lại.", "Nên người sản xuất phải liên tục cải tiến, giảm giá, nâng chất lượng và nhạy bén với thị trường."],
    ],
    x: [
      ["Hai quán cà phê cạnh nhau, khách chỉ chọn quán ngon và rẻ hơn.", "vs", "☕ ☕", "Quán A|Quán B"],
      ["Một quán thêm món mới, nhạc hay, giá tốt.", "flow", "💡 ☕ 🎶", "Ý tưởng|Món mới|Không gian"],
      ["Quán kia buộc phải nhạy bén hơn nếu không muốn vắng khách.", "big", "⚡", "Năng động"],
    ],
    w: [
      "Làm sản xuất thiếu nhân văn là cách nói tiêu cực, không phải tác dụng cơ bản.",
      "Buộc người sản xuất phải thường xuyên năng động, nhạy bén. Đúng tác dụng.",
      "Mang tính nhân văn hơn là lạc đề.",
    ],
    m: "Cạnh tranh thúc ép con người chạy nhanh hơn!",
    me: "⚡",
  },
  69: {
    t: "vn",
    h: "Hoàn thiện thể chế kinh tế thị trường định hướng xã hội chủ nghĩa cần mấy nhiệm vụ chủ yếu? Một con số cần nhớ chắc.",
    k: [
      ["nhiệm vụ chủ yếu", "📋", "Vì sao nhớ con số năm?", "Đề hỏi số lượng nhiệm vụ chủ yếu thiên về hoàn thiện thể chế. Đây là kiến thức cần thuộc: theo giáo trình, đáp án là năm nhiệm vụ.", "Các nhiệm vụ trải trên nhiều lĩnh vực như sở hữu, thị trường, phân phối, hội nhập và quản lý."],
    ],
    x: [
      ["Hãy nhớ con số năm như năm ngón tay trên bàn tay.", "big", "🖐️", "5 nhiệm vụ"],
      ["Năm hướng chính trải khắp nền kinh tế: sở hữu, thị trường, phân phối, hội nhập, quản lý.", "row", "🏠 🛒 ⚖️ 🌍 🏛️", "Sở hữu|Thị trường|Phân phối|Hội nhập|Quản lý"],
    ],
    w: [
      "Ba nhiệm vụ là thiếu.",
      "Năm nhiệm vụ, đúng theo giáo trình.",
      "Sáu nhiệm vụ là thừa.",
      "Chín nhiệm vụ là thừa nhiều.",
    ],
    m: "Năm nhiệm vụ, nhớ một bàn tay!",
    me: "🖐️",
  },
  70: {
    t: "lt",
    h: "Kinh tế chính trị cổ điển Anh nở rộ vào thời kỳ nào? Một câu hỏi lịch sử rất đáng nhớ.",
    k: [
      ["cổ điển Anh", "🕰️", "Vì sao rơi vào thời kỳ này?", "Đây là lúc cách mạng công nghiệp ở Anh bùng nổ, chủ nghĩa tư bản trưởng thành, nên cần lý thuyết để giải thích.", "Xmít viết Của cải của các dân tộc năm một bảy bảy sáu, Ri-các-đô hoàn thiện học thuyết vào đầu thế kỷ mười chín."],
    ],
    x: [
      ["Cuối thế kỷ mười tám, máy hơi nước nổ ầm ầm ở nước Anh.", "big", "💨", "Cách mạng công nghiệp"],
      ["Xmít viết cuốn Của cải của các dân tộc vào năm một bảy bảy sáu.", "big", "📖", "1776"],
      ["Đến nửa đầu thế kỷ mười chín, Ri-các-đô đưa học thuyết lên đỉnh cao.", "steps", "📖 ✍️ 🏁", "Smith|Ricardo|Đỉnh cao"],
    ],
    w: [
      "Từ cổ đại đến thế kỷ mười tám là khoảng quá rộng.",
      "Nửa cuối mười bảy đến nửa đầu mười tám là thời kỳ tiền thân.",
      "Từ cuối thế kỷ mười tám đến nửa đầu thế kỷ mười chín. Đúng thời kỳ.",
      "Từ nửa đầu thế kỷ mười chín thì quá muộn, bỏ qua giai đoạn hình thành.",
    ],
    m: "Cổ điển Anh: từ Xmít một bảy bảy sáu đến Ri-các-đô!",
    me: "📖",
  },
};
