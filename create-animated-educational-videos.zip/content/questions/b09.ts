import type { QC } from "../types";

export const b09: Record<number, QC> = {
  81: {
    t: "tb",
    h: "Quy luật chung của tích lũy tư bản. Câu này hỏi ý KHÔNG đúng, hãy xem vì sao một ý nghe có vẻ hợp lý lại bị loại!",
    k: [
      ["quy luật chung của tích lũy", "📈", "Quy luật chung của tích lũy nói gì?", "Tích lũy tư bản làm cấu tạo hữu cơ tăng: nhiều máy ít người, nên thất nghiệp nhiều và giai cấp vô sản bị bần cùng hóa.", "Đáp án A chỉ nói tư sản giàu và mâu thuẫn tăng, bỏ qua mặt bần cùng hóa và thất nghiệp. Theo bộ đề, đây là ý được chọn là không đúng."],
    ],
    x: [
      ["Nhà máy mua thêm máy móc, cần ít công nhân hơn. Đó là cấu tạo hữu cơ tăng.", "flow", "🤖 📈 👷", "Máy móc|Tăng|Công nhân giảm"],
      ["Công nhân bị đào thải, thất nghiệp, sống bấp bênh: đó là bần cùng hóa.", "big", "🏚️", "Bần cùng hóa"],
      ["Một cực giàu có chất đống, cực kia nghèo khổ. Khoảng cách ngày càng tăng.", "bars", "💎 🏚️", "Giàu:95|Nghèo:10"],
    ],
    w: [
      "Chỉ nói tư sản giàu và mâu thuẫn tăng, thiếu nội dung cốt lõi. Bộ đề chọn đây là ý không đúng.",
      "Cấu tạo hữu cơ tăng là nội dung đúng của quy luật.",
      "Bần cùng hóa giai cấp vô sản là nội dung đúng.",
      "Khoảng cách giàu nghèo và thất nghiệp là nội dung đúng.",
    ],
    m: "Câu hỏi ý không đúng: A là kẻ lạc loài!",
    me: "🔎",
  },
  82: {
    t: "tb",
    h: "Khi nghiên cứu cả nền kinh tế, Mác chia thành hai khu vực lớn. Chia theo gì? Câu trả lời khá thú vị!",
    k: [
      ["tư liệu sản xuất và tư liệu tiêu dùng", "🏭", "Hai khu vực khác nhau thế nào?", "Khu vực một sản xuất tư liệu sản xuất: máy móc, nguyên liệu. Khu vực hai sản xuất tư liệu tiêu dùng: thứ con người dùng như quần áo, lương thực.", "Các đáp án kia nói hàng công nghiệp hay hàng nông nghiệp, tức chia theo ngành, không phải theo công dụng."],
    ],
    x: [
      ["Khu vực một: các nhà máy làm ra máy móc và nguyên liệu.", "big", "🏭", "Khu vực I"],
      ["Khu vực hai: sản xuất thứ để dùng, như quần áo và gạo.", "big", "🍚", "Khu vực II"],
      ["Hai khu vực phải cân đối thì nền kinh tế mới trơn tru.", "flow", "🏭 ⚖️ 🍚", "Khu vực I|Cân đối|Khu vực II"],
    ],
    w: [
      "Hàng công nghiệp là chia theo ngành, sai tiêu chí.",
      "Hàng nông nghiệp cũng chia theo ngành, sai tiêu chí.",
      "Tư liệu sản xuất và tư liệu tiêu dùng, đúng cách chia của Mác.",
      "Máy móc chỉ là một phần của tư liệu sản xuất, nên chưa đủ.",
    ],
    m: "Một là làm ra máy, hai là làm ra đồ dùng!",
    me: "⚙️",
  },
  83: {
    t: "tb",
    h: "Người thuê đất nông nghiệp phải nộp tiền cho chủ đất. Vậy phần nộp đó, về bản chất, là gì?",
    k: [
      ["địa tô", "🌾", "“Địa tô” là gì?", "Nhà tư bản thuê đất của địa chủ để làm nông nghiệp. Sau khi giữ phần lợi nhuận của mình, phần giá trị thặng dư còn lại phải nộp cho địa chủ gọi là địa tô.", "Các đáp án khác nói sai thành phần, như nói giá trị chung chung hoặc nói thu nhập bình quân."],
    ],
    x: [
      ["Địa chủ có đất, nhà tư bản thuê đất để canh tác.", "flow", "🏞️ 👔 🌾", "Đất|Nhà tư bản|Lúa"],
      ["Sau thu hoạch, nhà tư bản giữ phần lợi nhuận của mình.", "bars", "💰 🏞️", "Lợi nhuận:60|Địa tô:40"],
      ["Phần thặng dư còn lại nộp cho địa chủ chính là địa tô.", "big", "🏞️", "Địa tô"],
    ],
    w: [
      "Phần giá trị thặng dư còn lại sau lợi nhuận mà nhà nông nghiệp nộp cho địa chủ. Đúng theo đáp án.",
      "Thu nhập bình quân không phải khái niệm chuẩn ở đây.",
      "Nói phần giá trị chung chung và nhà tư bản chung chung, chưa chính xác.",
      "Phần giá trị còn lại sau lợi nhuận thu được, sai đối tượng.",
    ],
    m: "Địa tô là thặng dư nộp cho địa chủ!",
    me: "🏞️",
  },
  84: {
    t: "tb",
    h: "Các nước tư bản đi đầu lấy tiền ở đâu để xây dựng công nghiệp? Câu trả lời khá phũ phàng!",
    k: [
      ["tích lũy nguyên thủy", "💰", "Nguồn vốn công nghiệp hóa lấy từ đâu?", "Từ cướp bóc thuộc địa, khai thác lao động làm thuê, và làm phá sản người sản xuất nhỏ để biến họ thành công nhân.", "Cả ba đều là nguồn vốn, nên đáp án là tất cả các phương án trên."],
    ],
    x: [
      ["Cướp tài nguyên, vàng bạc từ thuộc địa mang về chính quốc.", "flow", "🚢 💎 🏛️", "Thuộc địa|Của cải|Chính quốc"],
      ["Bắt người làm thuê làm việc nhiều giờ, lương thấp.", "big", "⛓️", "Lao động làm thuê"],
      ["Nông dân nhỏ mất đất, phá sản, đi làm công nhân.", "flow", "🧑‍🌾 🏚️ 🏭", "Nông dân|Mất đất|Công nhân"],
    ],
    w: [
      "Cướp bóc thuộc địa là một nguồn đúng, nhưng chưa đủ.",
      "Khai thác lao động làm thuê cũng đúng, nhưng chưa đủ.",
      "Làm phá sản người sản xuất nhỏ cũng đúng, nhưng chưa đủ.",
      "Tất cả phương án trên. Cả ba nguồn đều đúng.",
    ],
    m: "Ba nguồn, một đáp án: tất cả các phương án trên!",
    me: "💰",
  },
  85: {
    t: "cnh",
    h: "Công nghiệp hóa ở Việt Nam có những đặc trưng riêng. Câu này hỏi cái KHÔNG phải đặc trưng. Cẩn thận!",
    k: [
      ["định hướng", "🧭", "Vì sao “theo định hướng tư bản chủ nghĩa” là đáp án?", "Việt Nam đi theo con đường xã hội chủ nghĩa chứ không phải tư bản chủ nghĩa. Ba đáp án còn lại đều là đặc trưng đúng.", "Hãy luôn kiểm tra cụm “không phải” ở đầu câu để không đảo ngược ý."],
    ],
    x: [
      ["Công nghiệp hóa gắn với kinh tế thị trường định hướng xã hội chủ nghĩa.", "big", "🧭", "Định hướng XHCN"],
      ["Diễn ra trong bối cảnh toàn cầu hóa và hội nhập quốc tế.", "big", "🌐", "Toàn cầu hóa"],
      ["Còn định hướng tư bản chủ nghĩa là trái với con đường đã chọn.", "big", "🚫", "Không phải"],
    ],
    w: [
      "Gắn liền với phát triển công nghiệp, là đặc trưng đúng theo đề, nên loại.",
      "Trong điều kiện kinh tế thị trường định hướng xã hội chủ nghĩa, là đặc trưng đúng, nên loại.",
      "Trong bối cảnh toàn cầu hóa, là đặc trưng đúng, nên loại.",
      "Theo định hướng tư bản chủ nghĩa không phải đặc trưng của Việt Nam. Chọn đáp án này.",
    ],
    m: "Việt Nam: định hướng xã hội chủ nghĩa, không phải tư bản chủ nghĩa!",
    me: "🇻🇳",
  },
  86: {
    t: "hh",
    h: "Một món hàng có thể có nhiều giá trị khác nhau tùy từng người làm. Giá trị đó gọi là gì, và do ai quyết định?",
    k: [
      ["giá trị cá biệt", "🧍", "“Cá biệt” khác “xã hội” thế nào?", "Giá trị cá biệt là lao động mà một người sản xuất riêng lẻ bỏ ra. Còn giá trị xã hội là mức hao phí trung bình của cả ngành.", "Mỗi người làm một kiểu, có người nhanh, có người chậm, nên giá trị cá biệt khác nhau."],
    ],
    x: [
      ["Anh A may một cái áo hết hai giờ.", "big", "👕", "Anh A: 2 giờ"],
      ["Chị B may cái áo y như vậy chỉ mất một giờ.", "big", "⚡", "Chị B: 1 giờ"],
      ["Mỗi người một mức hao phí riêng. Đó là giá trị cá biệt.", "bars", "🧍 🧍", "Anh A:2|Chị B:1"],
    ],
    w: [
      "Hao phí lao động cá biệt của người sản xuất quyết định. Đúng.",
      "Nói nhiều hàng hóa quyết định thì sai khái niệm.",
      "Hao phí của ngành quyết định, đó là giá trị xã hội chứ không phải cá biệt.",
    ],
    m: "Cá biệt là của riêng mình, xã hội là của cả ngành!",
    me: "🧍",
  },
  87: {
    t: "tb",
    h: "Có ba luận điểm, chỉ một cái sai. Mẹo: cứ thấy chữ “chỉ có” thì phải nghi ngờ ngay!",
    k: [
      ["sản phẩm thặng dư", "🍞", "Sản phẩm thặng dư là gì? Vì sao chữ “chỉ” làm câu sai?", "Là phần sản phẩm người lao động làm ra dôi khỏi nhu cầu thiết yếu mà bị người khác chiếm. Thời nô lệ và phong kiến cũng có chuyện này.", "Nên nói chỉ có ở chủ nghĩa tư bản là sai. Riêng giá trị thặng dư mới là đặc trưng của tư bản."],
    ],
    x: [
      ["Thời phong kiến, nông dân phải nộp một phần thóc cho địa chủ.", "flow", "🧑‍🌾 🌾 🏯", "Nông dân|Thóc|Địa chủ"],
      ["Thời nô lệ, chủ chiếm cả sản phẩm của nô lệ.", "big", "⛓️", "Nô lệ"],
      ["Bóc lột sản phẩm thặng dư có ở nhiều chế độ, không riêng gì tư bản.", "row", "🏺 🏯 🏭", "Nô lệ|Phong kiến|Tư bản"],
    ],
    w: [
      "Chữ “chỉ có” làm câu này sai. Chọn đáp án này.",
      "Trước tư bản, người ta bóc lột sản phẩm thặng dư trực tiếp. Ý đúng.",
      "Giá trị thặng dư tuyệt đối là hình thái chung nhất. Ý đúng.",
    ],
    m: "Thấy chữ “chỉ” là soi thật kỹ!",
    me: "🔍",
  },
  88: {
    t: "hh",
    h: "Ngang giá có nghĩa là giá luôn bằng giá trị không? Câu trả lời khiến nhiều bạn bị lừa!",
    k: [
      ["ngang giá", "⚖️", "Ngang giá có phải giá luôn bằng giá trị?", "Ngang giá là trao đổi dựa trên giá trị. Nhưng giá cả có thể lúc cao lúc thấp, xoay quanh giá trị như con diều quanh sợi dây.", "Nhìn tổng thể thì ngang giá, còn từng lần mua bán thì không nhất thiết bằng nhau."],
    ],
    x: [
      ["Giá trị của chiếc áo là hai trăm nghìn.", "big", "👕", "200 nghìn"],
      ["Hôm đông khách giá lên hai trăm hai mươi, hôm ế còn một trăm tám mươi.", "bars", "📉 ⚖️ 📈", "Ế:180|Đúng:200|Đông:220"],
      ["Giá cả xoay quanh giá trị như con diều quanh dây.", "loop", "📈 ⚖️ 📉", "Cao|Giá trị|Thấp"],
    ],
    w: [
      "Giá cả từng hàng hóa luôn bằng giá trị là tuyệt đối hóa, sai.",
      "Giá trị luôn bằng giá cả cũng sai, vì giá cả có thể lệch.",
      "Giá cả có thể tách rời và xoay quanh giá trị. Đúng.",
    ],
    m: "Giá cả là con diều, giá trị là sợi dây!",
    me: "🪁",
  },
  89: {
    t: "cnh",
    h: "Mỗi cuộc cách mạng công nghiệp có một biệt danh. Lần ba mang biệt danh nào?",
    k: [
      ["cách mạng máy tính", "💻", "Vì sao gọi là cách mạng máy tính?", "Vì dấu ấn lớn nhất là máy tính, vi mạch, Internet và tự động hóa bằng công nghệ thông tin.", "Điện tử hay vô tuyến chỉ là một phần nhỏ của bức tranh."],
    ],
    x: [
      ["Máy tính từ căn phòng lớn thu nhỏ thành chiếc laptop.", "flow", "🖥️ 💻", "Phòng máy|Laptop"],
      ["Máy tính nối với nhau thành Internet.", "big", "🌐", "Internet"],
      ["Từ đó mọi ngành đều tự động hóa bằng phần mềm.", "flow", "💻 🤖 🏭", "Phần mềm|Robot|Nhà máy"],
    ],
    w: [
      "Cách mạng máy tính, đúng biệt danh của lần ba.",
      "Cách mạng điện tử nghe hợp lý nhưng quá hẹp.",
      "Sinh học là lĩnh vực khác, gắn với dự báo lần bốn.",
      "Cách mạng vô tuyến cũng quá hẹp.",
    ],
    m: "Lần ba, nhớ máy tính!",
    me: "💻",
  },
  90: {
    t: "lt",
    h: "Môn kinh tế chính trị nghiên cứu cái gì? Không phải máy móc, cũng không phải tiền bạc, mà là… mối quan hệ!",
    k: [
      ["quan hệ xã hội của sản xuất và trao đổi", "🔗", "“Quan hệ xã hội” trong sản xuất là gì?", "Là quan hệ giữa người với người: ai sở hữu, ai làm, ai hưởng. Không phải quan hệ giữa người với máy móc.", "Kinh tế chính trị nghiên cứu mặt xã hội này. Máy móc, kỹ thuật là việc của khoa học kỹ thuật."],
    ],
    x: [
      ["Cùng một cái máy cày, người chủ và người làm thuê có quan hệ khác nhau.", "vs", "👔 👷", "Chủ|Người làm thuê"],
      ["Kinh tế chính trị hỏi: ai sở hữu, ai làm, ai hưởng?", "row", "🔑 🛠️ 💰", "Sở hữu|Làm|Hưởng"],
      ["Đó chính là các quan hệ xã hội của sản xuất và trao đổi.", "big", "🔗", "Quan hệ xã hội"],
    ],
    w: [
      "Các quan hệ xã hội của sản xuất và trao đổi. Đúng đối tượng nghiên cứu.",
      "Quan hệ giữa lực lượng sản xuất và quan hệ sản xuất thiên về triết học.",
      "Cơ sở hạ tầng và kiến trúc thượng tầng cũng thuộc triết học.",
      "Biểu hiện vật chất của lực lượng sản xuất thuộc về kỹ thuật.",
    ],
    m: "Nghiên cứu người với người, không phải người với máy!",
    me: "🔗",
  },
};
