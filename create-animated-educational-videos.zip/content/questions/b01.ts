import type { QC } from "../types";

export const b01: Record<number, QC> = {
  1: {
    t: "cnh",
    h: "Làm sao để một đất nước chạy nhanh hơn người khác? Câu một sẽ cho bạn thấy: phải biến tri thức thành sức mạnh!",
    k: [
      ["gắn liền", "🔗", "“Gắn liền” nghĩa là gì nhỉ?", "Gắn liền là dính chặt vào nhau, không tách rời được, như hai mặt của một đồng xu.", "Vậy ứng dụng khoa học công nghệ phải dính chặt với thứ gì? Với một nền kinh tế cũng chạy bằng chất xám."],
      ["kinh tế tri thức", "🧠", "Thế “kinh tế tri thức” là gì?", "Là nền kinh tế kiếm tiền chủ yếu bằng hiểu biết và sáng tạo, chứ không chỉ bằng sức tay chân hay tài nguyên."],
    ],
    x: [
      ["Ngày xưa, nông dân chỉ có cuốc và sức tay chân. Thu hoạch được bao nhiêu là nhờ trời.", "row", "🧑‍🌾 ⛏️ 🌧️", "Sức người|Công cụ thô|Nhờ trời"],
      ["Bây giờ, nông dân dùng điện thoại, cảm biến và dữ liệu. Biết chính xác khi nào tưới, bón bao nhiêu.", "flow", "📱 📡 🌱", "Dữ liệu|Cảm biến|Cây trồng"],
      ["Cùng một mảnh ruộng, năng suất tăng vọt. Đó là khoa học công nghệ chạy cùng kinh tế tri thức.", "bars", "🌾 🌾", "Trước:30|Sau:90"],
    ],
    w: [
      "Kinh tế tri thức chính là sân chơi tự nhiên của khoa học công nghệ.",
      "Công nghiệp nặng chỉ là một ngành, không phải điều kiện gắn liền với việc ứng dụng công nghệ.",
      "Công nghiệp nhẹ cũng chỉ là một ngành, không nói lên hướng đi bằng tri thức.",
      "Công nghệ cao chỉ là một phần nhỏ. Phạm vi rộng hơn là cả nền kinh tế tri thức.",
    ],
    m: "Mẹo nhớ: khoa học công nghệ và kinh tế tri thức là một cặp bài trùng!",
    me: "🧠",
  },
  2: {
    t: "cnh",
    h: "Có nước chỉ mất vài chục năm để đi từ ruộng đồng thành cường quốc công nghiệp. Chính xác là bao nhiêu năm?",
    k: [
      ["rút ngắn", "⏩", "Công nghiệp hóa “rút ngắn” là sao?", "Các nước châu Âu đi đầu phải mất cả trăm năm mò mẫm. Rút ngắn là đi đường tắt: học lại kinh nghiệm, tiếp thu công nghệ có sẵn để chạy nhanh hơn nhiều.", "Nhật Bản và các nước công nghiệp mới như Hàn Quốc hay Xin-ga-po làm đúng như vậy, và họ chỉ mất khoảng hai mươi đến ba mươi năm."],
    ],
    x: [
      ["Nước đi đầu giống người tự dò đường trong rừng, mất cả thế kỷ mới tới nơi.", "row", "🚶 🛤️ 🏛️", "Tự dò đường|Hàng trăm năm|Cường quốc"],
      ["Nước đi sau giống người đi tàu cao tốc: đã có bản đồ, có công nghệ để học.", "flow", "🚄 🗺️ 🏭", "Tàu cao tốc|Bản đồ|Nhà máy"],
      ["Kết quả là Nhật Bản và các nước công nghiệp mới chỉ cần khoảng hai mươi đến ba mươi năm.", "bars", "🐢 🐇", "Kiểu cũ:100|Rút ngắn:25"],
    ],
    w: [
      "Mười đến hai mươi năm là quá ngắn so với thực tế.",
      "Mười lăm đến hai mươi lăm năm vẫn chưa đúng khoảng thời gian trong giáo trình.",
      "Hai mươi đến ba mươi năm khớp với mô hình của Nhật Bản và các nước công nghiệp mới.",
      "Hai mươi lăm đến ba mươi lăm năm lại kéo dài hơn thực tế.",
    ],
    m: "Nhớ hai con số tròn trĩnh: hai mươi và ba mươi!",
    me: "⏱️",
  },
  3: {
    t: "cnh",
    h: "Điện thoại, máy tính, Internet… tất cả đều khởi đầu từ cuộc cách mạng công nghiệp nào?",
    k: [
      ["đặc trưng cơ bản", "🔍", "“Đặc trưng cơ bản” nghĩa là gì?", "Đặc trưng là dấu hiệu riêng giống như vân tay, còn cơ bản là điều quan trọng nhất. Nhìn vào là biết ngay đó là cuộc cách mạng nào.", "Mỗi cuộc cách mạng công nghiệp có một dấu vân tay khác nhau: hơi nước, điện, rồi máy tính."],
    ],
    x: [
      ["Lần một, máy hơi nước kéo máy dệt chạy ầm ầm.", "big", "💨", "Lần 1: hơi nước"],
      ["Lần hai, điện thắp sáng thành phố và chạy các dây chuyền sản xuất.", "big", "⚡", "Lần 2: điện"],
      ["Lần ba, máy tính và Internet nối cả thế giới lại với nhau. Đó mới là đáp án của chúng ta.", "big", "💻", "Lần 3: máy tính"],
    ],
    w: [
      "Công nghệ thông tin và máy tính chính là dấu vân tay của cuộc cách mạng lần ba.",
      "Năng lượng điện là dấu hiệu của cuộc cách mạng lần hai.",
      "Động cơ hơi nước thuộc về cuộc cách mạng lần một.",
      "Động cơ điện cũng là của lần hai, đừng nhầm nhé.",
    ],
    m: "Lần ba là lần của máy tính. Cứ thấy số ba thì nghĩ tới bàn phím!",
    me: "⌨️",
  },
  4: {
    t: "vn",
    h: "Chia bánh thế nào mới gọi là công bằng? Thật ra có hai cách nhìn, và đề bài đang hỏi đúng hai cách đó.",
    k: [
      ["công bằng", "⚖️", "“Công bằng” có phải là chia đều cho mọi người không?", "Không hẳn. Công bằng là mỗi người nhận được xứng đáng với điều mình đóng góp hoặc điều mình cần.", "Vậy có mấy cách hiểu? Hai cách: công bằng theo cống hiến, và công bằng theo hưởng thụ."],
      ["cống hiến", "🎁", "Vậy “cống hiến” là gì?", "Là phần bạn bỏ ra cho xã hội: sức lao động, trí tuệ, vốn liếng. Đóng góp nhiều thì được nhận nhiều."],
    ],
    x: [
      ["Cả nhóm làm bài tập chung. Bạn làm nhiều nhất mà điểm bằng người chẳng làm gì. Bạn thấy sao?", "vs", "😎 😴", "Làm nhiều|Không làm"],
      ["Chia theo đóng góp như vậy gọi là công bằng theo cống hiến.", "big", "🏅", "Cống hiến"],
      ["Còn công bằng theo hưởng thụ là ai cũng được đảm bảo mức sống cơ bản như y tế, giáo dục, ăn no mặc ấm.", "row", "🏥 🏫 🍚", "Y tế|Giáo dục|Ăn no"],
    ],
    w: [
      "Mức độ và chức năng không phải hai quan niệm chính về phân phối.",
      "Hưởng thụ và cống hiến, đúng cặp quan niệm mà giáo trình nêu ra.",
      "Lao động chỉ là một dạng cống hiến, và cách ghép này không đúng cặp.",
      "Mức độ và lao động cũng không phải cặp quan niệm được nêu.",
    ],
    m: "Công bằng có hai chân: một chân cống hiến, một chân hưởng thụ.",
    me: "⚖️",
  },
  5: {
    t: "dq",
    h: "Nghe thật ngược đời: cạnh tranh càng khốc liệt thì càng sinh ra độc quyền!",
    k: [
      ["độc quyền", "👑", "“Độc quyền” là gì?", "Là khi một hay vài doanh nghiệp nắm gần hết thị trường, nên họ tự quyết định giá cả và điều kiện bán hàng.", "Vậy vì sao cạnh tranh lại sinh ra độc quyền? Vì kẻ thắng sẽ nuốt kẻ yếu, ngày càng to ra."],
    ],
    x: [
      ["Một con phố có mười quán trà sữa, đánh nhau bằng giá rẻ và chất lượng.", "row", "🧋 🧋 🧋 🧋 🧋", ""],
      ["Quán mạnh bán rẻ hơn, quán yếu phá sản hoặc bị mua lại.", "merge", "🧋 🧋 🧋 🏢", "||Bị nuốt|Quán lớn"],
      ["Cuối cùng chỉ còn vài ông lớn nắm cả thị trường. Cạnh tranh đã đẻ ra độc quyền!", "big", "👑", "Độc quyền"],
    ],
    w: [
      "Cạnh tranh dẫn tới tích tụ và tập trung sản xuất, và từ đó sinh ra độc quyền.",
      "Học thuyết kinh tế không phải là nguyên nhân sinh ra độc quyền.",
      "Bóc lột sức lao động là bản chất chung của tư bản, không phải nguyên nhân riêng của độc quyền.",
      "Nhà nước ra đời từ rất lâu, không phải nguồn gốc của độc quyền kinh tế.",
    ],
    m: "Ba bước nhớ liền: cạnh tranh, tích tụ, độc quyền!",
    me: "👑",
  },
  6: {
    t: "dq",
    h: "Ai là người đã định nghĩa tư bản tài chính nổi tiếng như vậy? Nghe câu trích thật kỹ nhé.",
    k: [
      ["tư bản tài chính", "🏦", "“Tư bản tài chính” thực chất là gì?", "Là sự hợp nhất giữa tư bản ngân hàng của vài ngân hàng độc quyền khổng lồ với tư bản của các liên minh độc quyền công nghiệp.", "Nói dễ hiểu: ngân hàng và nhà máy bắt tay làm một, tiền và sản xuất cùng một chủ."],
      ["Lê-nin", "📕", "Vì sao câu này thuộc về Lê-nin?", "Vì Lê-nin viết tác phẩm về chủ nghĩa đế quốc, nghiên cứu sâu giai đoạn độc quyền của chủ nghĩa tư bản."],
    ],
    x: [
      ["Một bên là ngân hàng khổng lồ nắm hầu hết tiền vốn.", "big", "🏦", "Ngân hàng"],
      ["Một bên là liên minh các nhà máy độc quyền nắm sản xuất.", "big", "🏭", "Công nghiệp"],
      ["Hai bên gộp lại thành một thế lực. Đó là tư bản tài chính.", "merge", "🏦 🏭 💰", "Ngân hàng|Công nghiệp|Tư bản tài chính"],
    ],
    w: [
      "Các Mác nghiên cứu tư bản thời tự do cạnh tranh, chưa nói tới tư bản tài chính theo cách này.",
      "Ăng-ghen là bạn đồng hành của Mác, không phải tác giả của định nghĩa này.",
      "Lê-nin đã phân tích chủ nghĩa đế quốc và đưa ra định nghĩa tư bản tài chính này.",
      "Hồ Chí Minh nói về cách mạng Việt Nam, không phải định nghĩa này.",
    ],
    m: "Độc quyền, đế quốc, tư bản tài chính: ba cái tên đi liền với Lê-nin!",
    me: "📕",
  },
  7: {
    t: "cnh",
    h: "Câu hỏi mốc thời gian là chỗ dễ mất điểm nhất. Nhớ thật chắc mốc này nhé!",
    k: [
      ["thập niên", "📅", "“Thập niên sáu mươi” là những năm nào?", "Thập niên là mười năm. Thập niên sáu mươi là từ một chín sáu mươi đến một chín sáu chín.", "Bẫy là bốn đáp án chỉ khác nhau mỗi con số: năm mươi, sáu mươi, bảy mươi hay tám mươi."],
    ],
    x: [
      ["Cuộc cách mạng lần ba gắn với sự ra đời của máy tính điện tử và vi mạch.", "flow", "🖥️ 🔬", "Máy tính|Vi mạch"],
      ["Từ những năm sáu mươi, máy tính lớn, máy tính cá nhân rồi Internet lần lượt xuất hiện.", "row", "🖥️ 💻 🌐", "Máy tính lớn|Máy tính cá nhân|Internet"],
      ["Cuộc cách mạng này kéo dài tới tận cuối thế kỷ hai mươi.", "big", "⏳", "Đầu thập niên 60 đến cuối thế kỷ 20"],
    ],
    w: [
      "Thập niên năm mươi là quá sớm so với mốc của giáo trình.",
      "Từ đầu thập niên sáu mươi đến cuối thế kỷ hai mươi, đúng mốc.",
      "Thập niên bảy mươi là muộn mất mười năm.",
      "Thập niên tám mươi còn muộn hơn nữa.",
    ],
    m: "Lần ba thì thập niên sáu mươi, ba với sáu là một cặp dễ nhớ!",
    me: "📅",
  },
  8: {
    t: "hh",
    h: "Thị trường không phải do chủ nghĩa tư bản phát minh đâu! Nó có từ xa xưa hơn thế nhiều.",
    k: [
      ["kinh tế thị trường", "🛒", "“Kinh tế thị trường” là gì?", "Là nền kinh tế mà phần lớn sản phẩm làm ra để mua bán trao đổi, và giá cả do cung cầu quyết định.", "Vì sao nó hình thành từ xã hội phong kiến? Vì lúc đó thủ công nghiệp và buôn bán phát triển, thợ thủ công và nông dân mang hàng ra chợ bán."],
    ],
    x: [
      ["Thời phong kiến, người thợ gốm làm bình không chỉ để dùng mà còn để bán.", "row", "🏺 🛒 💰", "Làm ra|Mang đi bán|Thu tiền"],
      ["Phố cổ, chợ búa nhộn nhịp. Mầm mống của thị trường mọc lên từ đó.", "row", "🏮 🧺 🪙", "Phố cổ|Chợ|Tiền"],
      ["Đến chủ nghĩa tư bản, kinh tế thị trường mới phát triển lên trình độ cao.", "bars", "🏯 🏭", "Phong kiến:30|Tư bản:90"],
    ],
    w: [
      "Kinh tế thị trường hình thành từ xã hội phong kiến.",
      "Chiếm hữu nô lệ chủ yếu là kinh tế tự cung tự cấp, chưa có thị trường rộng.",
      "Tư bản chủ nghĩa là nơi nó phát triển cao, chứ không phải nơi nó hình thành.",
      "Xã hội chủ nghĩa còn đến sau rất lâu.",
    ],
    m: "Hình thành ở phong kiến, nở rộ ở tư bản.",
    me: "🌱",
  },
  9: {
    t: "hh",
    h: "Sản xuất hàng hóa cần hai điều kiện. Câu này hỏi điều kiện thứ hai: vì sao các chủ thể lại tách biệt nhau?",
    k: [
      ["tách biệt về kinh tế", "✂️", "“Tách biệt về mặt kinh tế” là sao?", "Là mỗi người sản xuất độc lập, tự quyết làm gì, bán cho ai, lời lỗ tự chịu.", "Vậy cái gì tạo ra sự độc lập đó? Chính là quyền sở hữu: tài sản của ai thì người đó quyết định."],
    ],
    x: [
      ["Hai hộ nông dân cùng trồng lúa. Ruộng và máy cày của nhà nào thì nhà đó quyết.", "vs", "🏠 🏡", "Hộ A|Hộ B"],
      ["Muốn có gạo của nhà bên, phải trả tiền hoặc đổi hàng.", "swap", "🌾 💵", "Gạo|Tiền"],
      ["Nhờ có quyền sở hữu riêng, sản phẩm mới trở thành hàng hóa để trao đổi.", "big", "🔑", "Quyền sở hữu"],
    ],
    w: [
      "Tổ chức sản xuất chỉ là cách làm việc, chưa phải gốc của sự tách biệt.",
      "Phân phối sản phẩm là chuyện xảy ra sau, không phải cơ sở.",
      "Quyền sở hữu khác nhau chính là cơ sở của sự tách biệt về kinh tế.",
      "Vai trò sản xuất liên quan tới phân công lao động, thuộc điều kiện thứ nhất.",
    ],
    m: "Điều kiện hai: tách biệt, và chìa khóa là quyền sở hữu!",
    me: "🔑",
  },
  10: {
    t: "tb",
    h: "Muốn tích lũy được nhiều tư bản hơn thì cần những nhân tố nào? Đáp án khá dài, nhưng đừng hoảng nhé!",
    k: [
      ["tích lũy tư bản", "🐷", "“Tích lũy tư bản” nghĩa là gì?", "Là biến một phần giá trị thặng dư thành tư bản phụ thêm để đầu tư tiếp, như chú heo đất ngày càng to.", "Có bốn nhân tố quyết định heo đất to hay nhỏ: năng suất lao động, mức bóc lột sức lao động, chênh lệch giữa tư bản sử dụng và tư bản tiêu dùng, và quy mô tư bản ứng trước."],
    ],
    x: [
      ["Thứ nhất, năng suất lao động tăng thì làm ra nhiều hơn với cùng chi phí.", "big", "📈", "Năng suất"],
      ["Thứ hai, mức bóc lột sức lao động càng cao thì giá trị thặng dư càng lớn.", "big", "💪", "Bóc lột"],
      ["Thứ ba, máy móc dùng được nhiều năm dù đã hao mòn dần. Thứ tư, vốn ban đầu càng lớn thì tích lũy càng mạnh.", "row", "🏗️ 💼", "Chênh lệch sử dụng và tiêu dùng|Vốn ứng trước"],
    ],
    w: [
      "Cường độ lao động không nằm trong bộ bốn nhân tố này, mà là năng suất lao động.",
      "Đủ cả bốn nhân tố: năng suất, bóc lột, chênh lệch sử dụng và tiêu dùng, vốn ứng trước.",
      "Thiếu mất nhân tố năng suất lao động.",
      "Thiếu mất quy mô tư bản ứng trước.",
    ],
    m: "Nhớ bốn chữ: Năng, Bóc, Chênh, Vốn!",
    me: "🐷",
  },
};
