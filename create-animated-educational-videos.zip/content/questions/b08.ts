import type { QC } from "../types";

export const b08: Record<number, QC> = {
  71: {
    t: "cnh",
    h: "Câu này hỏi lại kiến thức quen: Mác chia cách mạng công nghiệp lần một thành mấy giai đoạn?",
    k: [
      ["ba giai đoạn", "🪜", "Ba giai đoạn đó là gì?", "Hợp tác giản đơn, công trường thủ công, đại công nghiệp. Ở câu ba mươi ba ta đã gặp, đây là cùng nội dung nhưng hỏi bằng số lượng.", "Mẹo là hình dung ba bậc thang đi lên từ tay đến máy."],
    ],
    x: [
      ["Như làm bánh mì: một người làm tất cả mọi việc, đó là giản đơn.", "big", "👨‍🍳", "Hợp tác giản đơn"],
      ["Nhiều người, mỗi người một công đoạn bằng tay, đó là thủ công.", "flow", "🥣 🔥 🥖", "Nhào bột|Nướng|Đóng gói"],
      ["Cả dây chuyền máy làm bánh, đó là đại công nghiệp.", "big", "🏭", "Đại công nghiệp"],
    ],
    w: [
      "Một giai đoạn là thiếu.",
      "Hai giai đoạn vẫn thiếu một bậc.",
      "Ba giai đoạn, đúng theo Mác.",
      "Bốn giai đoạn là thừa.",
    ],
    m: "Ba bậc: giản đơn, thủ công, đại công nghiệp!",
    me: "🪜",
  },
  72: {
    t: "vn",
    h: "Gặp đáp án “tất cả các phương án trên” thì chọn thế nào? Đừng đoán, hãy kiểm tra từng ý!",
    k: [
      ["tất cả các phương án trên", "✅", "Khi nào mới chọn “tất cả các phương án trên”?", "Khi mỗi đáp án A, B, C đều đúng. Hãy kiểm tra từng cái: vốn và công nghệ, kinh nghiệm quản lý, thị trường tiêu thụ.", "Cả ba đều là mục tiêu của hội nhập, nên chọn D."],
    ],
    x: [
      ["Mở cửa đón vốn và công nghệ hiện đại từ nước ngoài.", "flow", "💰 🔬 🇻🇳", "Vốn|Công nghệ|Việt Nam"],
      ["Học cách quản lý tiên tiến của thế giới.", "big", "📚", "Quản lý tiên tiến"],
      ["Đem hàng Việt ra thế giới, như cà phê, gạo, dệt may.", "flow", "☕ 🚢 🌏", "Hàng Việt|Tàu|Thế giới"],
    ],
    w: [
      "Ý này đúng, nhưng chưa đủ vì còn hai ý còn lại.",
      "Ý này cũng đúng, nhưng chưa đủ.",
      "Ý này cũng đúng, nhưng chưa đủ.",
      "Cả ba ý đều đúng. Chọn tất cả các phương án trên.",
    ],
    m: "A, B, C đều đúng thì D thắng!",
    me: "🏆",
  },
  73: {
    t: "vn",
    h: "Thể chế có thể chia theo nhiều cách. Nếu chia theo những ai tham gia xã hội, ta được những loại nào?",
    k: [
      ["tiêu chí cấu trúc", "🏗️", "“Cấu trúc các tổ chức tham gia xã hội” là gì?", "Là xem xã hội gồm những loại chủ thể nào, như nhà nước và các tổ chức tư nhân. Mỗi loại có luật chơi riêng.", "Vì vậy ta chia thành thể chế nhà nước và thể chế tư bản tư nhân, theo đáp án của bộ đề."],
    ],
    x: [
      ["Cơ quan nhà nước làm việc theo luật và quy định chung.", "big", "🏛️", "Thể chế nhà nước"],
      ["Công ty tư nhân có điều lệ và quy chế riêng.", "big", "🏢", "Thể chế tư nhân"],
      ["Hai nhóm chủ thể, hai loại thể chế.", "vs", "🏛️ 🏢", "Nhà nước|Tư nhân"],
    ],
    w: [
      "Công và tư nói chung chung, chưa đúng tên theo đáp án.",
      "Thể chế nhà nước và thể chế tư bản tư nhân. Chia theo chủ thể.",
      "Trong nước và ngoài nước chia theo địa lý, không phải cấu trúc chủ thể.",
      "Chính trị và kinh tế chia theo lĩnh vực, không phải theo chủ thể.",
    ],
    m: "Chia theo chủ thể thì nhà nước và tư nhân!",
    me: "🏛️",
  },
  74: {
    t: "tb",
    h: "Lợi nhuận có phải lúc nào cũng bằng giá trị thặng dư không? Câu trả lời sẽ khiến bạn bất ngờ!",
    k: [
      ["lợi nhuận", "📊", "Vì sao lợi nhuận không luôn bằng giá trị thặng dư?", "Lợi nhuận là giá bán trừ chi phí. Bán đúng giá trị thì bằng thặng dư, bán cao hơn thì lớn hơn, bán thấp hơn thì nhỏ hơn.", "Giá cả lên xuống quanh giá trị, nên lợi nhuận cũng lên xuống quanh giá trị thặng dư."],
    ],
    x: [
      ["Giả sử giá trị thặng dư là một trăm.", "big", "💯", "m = 100"],
      ["Bán đúng giá trị thì lãi một trăm. Bán đắt hơn thì lãi một trăm hai mươi. Bán rẻ hơn thì còn tám mươi.", "bars", "📉 ⚖️ 📈", "Rẻ:80|Đúng:100|Đắt:120"],
      ["Vậy lợi nhuận có thể bằng, cao hơn hoặc thấp hơn.", "loop", "📉 ⚖️ 📈", "Thấp|Bằng|Cao"],
    ],
    w: [
      "Thiếu khả năng cao hơn.",
      "Thiếu khả năng bằng.",
      "Bằng, cao hơn hoặc thấp hơn. Đủ ba khả năng.",
      "Thiếu khả năng thấp hơn.",
    ],
    m: "Ba khả năng: bằng, hơn, kém!",
    me: "📊",
  },
  75: {
    t: "vn",
    h: "Thể chế là một từ nghe rất to tát. Nhưng thực ra nó rất gần gũi, như luật chơi của một trò chơi!",
    k: [
      ["thể chế", "📜", "“Thể chế” thực sự là gì?", "Là bộ quy tắc, tổ chức và cách vận hành để điều chỉnh hoạt động của xã hội, như luật chơi cùng trọng tài và sân chơi.", "Đáp án A có đủ ba yếu tố: quy định, bộ máy và cơ chế vận hành."],
    ],
    x: [
      ["Trò chơi nào cũng cần có luật chơi.", "big", "📜", "Quy định"],
      ["Cần có trọng tài và bộ máy điều hành.", "big", "🧑‍⚖️", "Bộ máy"],
      ["Cộng lại là thể chế: quy định, bộ máy, cơ chế vận hành.", "merge", "📜 🧑‍⚖️ ⚙️", "Quy định|Bộ máy|Cơ chế"],
    ],
    w: [
      "Quy định, bộ máy quản lý và cơ chế vận hành. Đủ ba yếu tố.",
      "Chỉ nhấn vào luật chơi, thiếu bộ máy và cơ chế vận hành.",
      "Nói về cấu thành hệ thống, lệch khỏi định nghĩa.",
    ],
    m: "Thể chế bằng quy định cộng bộ máy cộng cơ chế!",
    me: "📜",
  },
  76: {
    t: "cnh",
    h: "“Cách mạng công nghiệp lần thứ tư” mang hàm ý gì? Chú ý hai chữ “chất” và “lượng”, rất dễ nhầm!",
    k: [
      ["thay đổi về chất", "🦋", "“Chất” khác “lượng” thế nào?", "Lượng là tăng thêm số lượng, như thêm máy móc. Chất là đổi hẳn bản chất, như sâu hóa thành bướm.", "Lần bốn không chỉ thêm máy, mà đổi hẳn cách sản xuất bằng trí tuệ nhân tạo, dữ liệu lớn, robot. Đề nhấn vào lực lượng sản xuất."],
    ],
    x: [
      ["Thêm máy dệt thứ hai, thứ ba: đó là thay đổi về lượng.", "row", "⚙️ ⚙️ ⚙️", "Máy 1|Máy 2|Máy 3"],
      ["Sâu hóa thành bướm: đổi hẳn bản chất, đó là thay đổi về chất.", "flow", "🐛 🦋", "Sâu|Bướm"],
      ["Cách mạng lần bốn biến cách làm việc thành thông minh và tự động.", "big", "🤖", "Thay đổi về chất"],
    ],
    w: [
      "Thay đổi về lượng là chưa đủ, vì lần bốn là đổi chất.",
      "Thay đổi về chất trong lực lượng sản xuất. Đúng theo đáp án.",
      "Đổi chất trong quan hệ sản xuất là sai đối tượng.",
      "Thay đổi toàn diện cả đời sống là cách nói rộng, đáp án bộ đề là phương án B.",
    ],
    m: "Chất đổi, lực lượng sản xuất đổi!",
    me: "🦋",
  },
  77: {
    t: "tb",
    h: "Làm nhanh hơn nhờ máy hay làm vất vả hơn bằng sức? Hai thứ rất khác nhau, nhưng có một điểm chung!",
    k: [
      ["năng suất và cường độ", "🏃", "Tăng năng suất và tăng cường độ khác nhau thế nào?", "Tăng năng suất là làm nhanh hơn nhờ máy móc, kỹ thuật, nên không mệt hơn. Tăng cường độ là làm vất vả hơn trong cùng thời gian.", "Giống nhau: trong cùng một thời gian, số sản phẩm làm ra đều tăng."],
    ],
    x: [
      ["Công nhân A dùng máy mới, làm gấp đôi mà vẫn thoải mái.", "big", "🤖", "Tăng năng suất"],
      ["Công nhân B phải chạy tay nhanh gấp đôi, mệt hơn nhiều.", "big", "💦", "Tăng cường độ"],
      ["Dù cách khác nhau, cả hai đều ra nhiều hàng hơn trong cùng một giờ.", "bars", "📦 📦 📦", "Bình thường:10|Tăng năng suất:20|Tăng cường độ:20"],
    ],
    w: [
      "Đều làm tăng số hàng hóa sản xuất ra trong một thời gian. Đúng điểm giống nhau.",
      "Hao phí lao động tăng chỉ đúng với tăng cường độ.",
      "Giá trị một đơn vị hàng hóa giảm chỉ đúng với tăng năng suất.",
    ],
    m: "Giống nhau ở chỗ số hàng làm ra tăng!",
    me: "📦",
  },
  78: {
    t: "tb",
    h: "Chủ nghĩa tư bản có thành tựu, nhưng cũng có hạn chế. Câu này chọn BA ý đúng, bạn sẵn sàng chưa?",
    k: [
      ["hạn chế", "🧱", "Vì sao mục đích sản xuất lại là hạn chế?", "Chủ nghĩa tư bản sản xuất chủ yếu để thu lợi nhuận cho thiểu số chủ tư bản, không phải vì lợi ích của đa số.", "Từ đó sinh ra phân hóa giàu nghèo và xung đột. Đây là mặt trái cố hữu chứ không chỉ là sai sót nhỏ."],
    ],
    x: [
      ["Một nhà máy lớn tạo ra rất nhiều của cải.", "big", "🏭", "Của cải"],
      ["Nhưng của cải dồn về thiểu số, đa số vẫn thiếu thốn.", "bars", "💎 🏚️", "Thiểu số:90|Đa số:10"],
      ["Xung đột, chiến tranh và phân hóa giàu nghèo là hệ quả.", "row", "⚔️ 🏚️ 💎", "Xung đột|Nghèo|Giàu"],
    ],
    w: [
      "Mục đích sản xuất tập trung vào lợi ích thiểu số. Đúng, một hạn chế.",
      "Gây chiến tranh và xung đột ở nhiều nơi. Đúng, một hạn chế.",
      "Phân hóa giàu nghèo ngày càng sâu sắc. Đúng, một hạn chế.",
      "Môi trường là vấn đề chung của nhiều nền kinh tế, đề không xếp vào ba hạn chế chính này.",
    ],
    m: "Ba hạn chế: thiểu số, chiến tranh, giàu nghèo!",
    me: "⚠️",
  },
  79: {
    t: "hh",
    h: "Sản phẩm và hàng hóa có phải là một không? Câu này hỏi ý KHÔNG đúng, đọc kỹ đề nhé!",
    k: [
      ["không phải mọi sản phẩm đều là hàng hóa", "🚫", "Sản phẩm và hàng hóa khác nhau ra sao?", "Sản phẩm là bất cứ thứ gì lao động làm ra. Hàng hóa là sản phẩm làm ra để trao đổi, mua bán.", "Rau bạn tự trồng để ăn là sản phẩm nhưng không phải hàng hóa. Nên nói mọi sản phẩm đều là hàng hóa là sai."],
    ],
    x: [
      ["Chị trồng rau trong vườn để cả nhà ăn.", "big", "🥬", "Chỉ là sản phẩm"],
      ["Chị mang chính số rau đó ra chợ bán, lúc này nó mới thành hàng hóa.", "flow", "🥬 🛒 💵", "Rau|Chợ|Tiền"],
      ["Vậy hàng hóa chỉ là một phần của sản phẩm.", "vs", "📦 🛒", "Sản phẩm|Hàng hóa"],
    ],
    w: [
      "Mọi sản phẩm đều là hàng hóa là ý sai. Đây là đáp án chúng ta cần chọn.",
      "Mọi sản phẩm đều là kết quả của sản xuất, nghe hợp lý nên không chọn.",
      "Không phải mọi sản phẩm đều là hàng hóa là ý đúng, nên loại.",
    ],
    m: "Hàng hóa là sản phẩm đi chợ!",
    me: "🛒",
  },
  80: {
    t: "hh",
    h: "Chi phí thực tế mà cả xã hội phải bỏ ra để làm một món hàng gồm những gì?",
    k: [
      ["lao động sống và lao động quá khứ", "⏳", "Hai loại lao động này là gì?", "Lao động sống là sức lao động của người công nhân đang làm việc. Lao động quá khứ là lao động đã kết tinh trong máy móc và nguyên liệu.", "Cộng cả hai lại ta được chi phí thực tế của xã hội, tức giá trị của hàng hóa."],
    ],
    x: [
      ["Một chiếc áo cần công của người thợ may đang làm việc.", "big", "🧵", "Lao động sống"],
      ["Cùng vải, kim chỉ và máy may đã được làm ra từ trước.", "big", "🧶", "Lao động quá khứ"],
      ["Cộng lại là toàn bộ chi phí xã hội bỏ ra.", "merge", "🧵 🧶 👕", "Sống|Quá khứ|Chi phí xã hội"],
    ],
    w: [
      "Chi phí lao động sống và lao động quá khứ. Đúng chi phí thực tế của xã hội.",
      "Tư bản bất biến và khả biến là chi phí của nhà tư bản, không phải của xã hội.",
      "Chi phí sức lao động của toàn xã hội thiếu mất phần lao động quá khứ.",
    ],
    m: "Sống cộng quá khứ bằng chi phí xã hội!",
    me: "⏳",
  },
};
