import type { QC } from "../types";

export const b03: Record<number, QC> = {
  21: {
    t: "hh",
    h: "Kinh tế thị trường và kinh tế hàng hóa. Hai cái tên, nhưng thật ra có quan hệ như thế nào?",
    k: [
      ["cùng bản chất", "🧬", "Vì sao hai thứ này “cùng bản chất”?", "Kinh tế thị trường là kinh tế hàng hóa ở trình độ phát triển cao. Giống cây con và cây trưởng thành: cùng một loài, chỉ khác độ lớn.", "Vậy nó có phải của riêng chủ nghĩa tư bản không? Không, nó có từ trước và còn tồn tại trong thời kỳ quá độ."],
    ],
    x: [
      ["Chợ làng bán rau, đổi cá. Đó là kinh tế hàng hóa giản đơn.", "row", "🥬 🐟 🧺", "Rau|Cá|Chợ"],
      ["Siêu thị, sàn thương mại điện tử, ngân hàng. Đó là kinh tế thị trường hiện đại.", "row", "🏬 📱 🏦", "Siêu thị|Mua online|Ngân hàng"],
      ["Cả hai đều là mua bán trao đổi, chỉ khác độ lớn. Cùng bản chất!", "steps", "🌱 🌿 🌳", "Hàng hóa giản đơn|Hàng hóa phát triển|Thị trường hiện đại"],
    ],
    w: [
      "Kinh tế thị trường không do chủ nghĩa tư bản sinh ra, nó đã có từ trước.",
      "Có cùng bản chất với kinh tế hàng hóa, vì nó là kinh tế hàng hóa phát triển cao.",
      "Sự tồn tại của nó là khách quan chứ không phải chủ quan. Sai ngay từ chữ này!",
      "Không phải sản phẩm riêng của tư bản, vì nó có trước và dùng được ở nhiều chế độ.",
    ],
    m: "Thị trường chính là hàng hóa đã lớn lên!",
    me: "🌳",
  },
  22: {
    t: "tb",
    h: "Muốn mở rộng việc kinh doanh thì cần thêm vốn. Vốn mới ấy rốt cuộc từ đâu mà ra?",
    k: [
      ["tích lũy", "🐷", "Tích lũy lấy vốn ở đâu ra?", "Tư bản muốn to lên phải có thêm vốn. Vốn mới ấy lấy từ chính phần lợi nhuận, tức giá trị thặng dư.", "Vì sao không phải giá trị của hàng hóa? Vì giá trị hàng hóa còn gồm cả phần bù chi phí cũ, chỉ phần dôi ra mới là tiền mới để đầu tư thêm."],
    ],
    x: [
      ["Quán bánh mì thu hai trăm nghìn một ngày, trừ hết chi phí còn lại năm mươi nghìn.", "bars", "🥖 🧾 💰", "Doanh thu:200|Chi phí:150|Lãi:50"],
      ["Chủ quán đem số lãi đó mở thêm một chỗ bán nữa.", "flow", "💰 🏪 🏪", "Tiền lãi|Quán cũ|Quán mới"],
      ["Tiền lãi là giá trị thặng dư, và đem nó đầu tư tiếp chính là tích lũy.", "loop", "💰 🏪 📈", "Lãi|Đầu tư|Lớn hơn"],
    ],
    w: [
      "Giá trị hàng hóa gồm cả phần bù chi phí, không phải phần mới.",
      "Giá trị thặng dư là nguồn gốc của tích lũy tư bản.",
      "Giá trị hàng hóa sức lao động là tiền lương, đã trả cho công nhân rồi.",
    ],
    m: "Tích lũy ăn từ phần lãi, không ăn từ vốn gốc!",
    me: "🐷",
  },
  23: {
    t: "cnh",
    h: "Việt Nam đi sau, muốn đuổi kịp thì phải đi nhanh. Vậy cần làm điều gì đầu tiên?",
    k: [
      ["nền tảng và động lực", "🚀", "“Nền tảng” và “động lực” khác nhau thế nào?", "Nền tảng là phần móng bên dưới, nâng đỡ tất cả. Động lực là lực đẩy giúp chạy nhanh.", "Giáo dục, đào tạo, khoa học và công nghệ vừa là móng vừa là động cơ cho công nghiệp hóa, hiện đại hóa."],
    ],
    x: [
      ["Muốn xây nhà cao, phải có móng sâu.", "big", "🏗️", "Nền tảng"],
      ["Muốn xe chạy nhanh, phải có động cơ mạnh.", "big", "🏎️", "Động lực"],
      ["Giáo dục và khoa học công nghệ chính là móng và là động cơ của đất nước.", "merge", "🎓 🔬 🚀", "Giáo dục|Khoa học|Bứt phá"],
    ],
    w: [
      "Nhảy vọt thì có, nhưng nói “không cần tuần tự” là tuyệt đối hóa quá mức.",
      "Coi trọng giáo dục, khoa học, công nghệ làm nền tảng và động lực. Đây là yêu cầu của rút ngắn.",
      "Dời kinh tế tri thức lại giai đoạn sau là đi ngược yêu cầu rút ngắn.",
      "Ưu tiên công nghiệp nặng là kiểu cũ, không phải yêu cầu cốt lõi của rút ngắn.",
    ],
    m: "Muốn rút ngắn: đầu tư vào con người và khoa học!",
    me: "🎓",
  },
  24: {
    t: "lt",
    h: "Không có lý thuyết nào tự nhiên mọc ra. Kinh tế chính trị Mác Lê-nin đứng trên vai ai?",
    k: [
      ["kế thừa và phát triển", "🧬", "“Kế thừa” khác gì “sao chép”?", "Kế thừa là giữ lại phần đúng rồi nâng cao hơn, như học trò giỏi vượt thầy.", "Mác lấy phần khoa học của kinh tế chính trị cổ điển Anh, như học thuyết giá trị lao động, rồi sửa chữa và nâng cấp thành lý luận của mình."],
    ],
    x: [
      ["Các nhà kinh tế người Anh nói: lao động tạo ra giá trị.", "row", "📚 ⚒️ 💎", "Cổ điển Anh|Lao động|Giá trị"],
      ["Mác giữ ý hay đó, rồi hỏi thêm: vậy lợi nhuận của nhà tư bản từ đâu ra?", "big", "❓", "Câu hỏi của Mác"],
      ["Từ câu hỏi đó, ông phát hiện giá trị thặng dư và nâng lý luận lên tầm mới.", "steps", "📚 🔍 🌟", "Cổ điển Anh|Mác phê phán|Lý luận mới"],
    ],
    w: [
      "Kinh tế chính trị cổ điển Anh, chính là nguồn kế thừa trực tiếp.",
      "Chủ nghĩa trọng thương chỉ nhìn vào lưu thông và vàng bạc, chưa đi vào sản xuất.",
      "Chủ nghĩa trọng nông chỉ coi nông nghiệp mới tạo ra giá trị.",
      "Kinh tế chính trị tầm thường bị Mác phê phán, không phải nguồn kế thừa.",
    ],
    m: "Mác đứng trên vai người Anh!",
    me: "📚",
  },
  25: {
    t: "hh",
    h: "Lại một câu chọn câu SAI. Mẹo nhỏ: hãy săn lùng những chữ nghe thật tuyệt đối!",
    k: [
      ["chỉ có thể", "🚫", "Chữ “chỉ” trong đáp án C nguy hiểm thế nào?", "Chữ chỉ là kiểu khẳng định tuyệt đối. Trong đề trắc nghiệm, câu có chữ chỉ hoặc luôn luôn thường là câu sai.", "Thực tế, kinh tế thị trường phát triển mạnh nhất ở chủ nghĩa tư bản chứ không phải ở phong kiến."],
    ],
    x: [
      ["Xã hội phong kiến: chợ làng nhỏ, đường xá khó khăn.", "row", "🏯 🛖 🐂", "Phong kiến|Làng|Trâu bò"],
      ["Chủ nghĩa tư bản: nhà máy, tàu hỏa, ngân hàng, thị trường toàn cầu.", "row", "🏭 🚂 🏦", "Nhà máy|Tàu hỏa|Ngân hàng"],
      ["Thị trường bùng nổ ở thời tư bản. Nên nói “chỉ phát triển mạnh ở phong kiến” là sai.", "bars", "🏯 🏭", "Phong kiến:25|Tư bản:95"],
    ],
    w: [
      "Kinh tế thị trường là kinh tế hàng hóa phát triển cao, đúng, nên loại.",
      "Lấy khoa học công nghệ hiện đại làm cơ sở, đúng, nên loại.",
      "Câu này sai, vì nó phát triển mạnh nhất ở chủ nghĩa tư bản chứ không chỉ ở phong kiến.",
      "Đạt trình độ cao trong chủ nghĩa tư bản, đúng, nên loại.",
    ],
    m: "Thấy chữ “chỉ có” là nghi ngờ ngay!",
    me: "🚨",
  },
  26: {
    t: "hh",
    h: "Cắt tóc, đi xe buýt, học online… đều là dịch vụ. Vậy dịch vụ khác hàng hóa thông thường ở điểm cốt lõi nào?",
    k: [
      ["cất trữ", "🧊", "“Không thể cất trữ” nghĩa là gì?", "Gạo hay áo thì mua về cất tủ dùng sau. Dịch vụ thì tạo ra là dùng ngay, không để dành được.", "Vậy sao các đáp án kia chưa đúng? Vì phục vụ người khác và đáp ứng nhu cầu là đặc điểm chung của mọi hàng hóa, đâu riêng gì dịch vụ."],
    ],
    x: [
      ["Một bao gạo, mua hôm nay cất tủ ăn tuần sau, không sao cả.", "big", "🍚", "Hàng hóa: cất được"],
      ["Một lần cắt tóc, thợ cắt xong là xong. Bạn không thể mang về cất.", "flow", "💇 ✂️ 😎", "Thợ|Cắt|Xong"],
      ["Ghế trống trên chuyến xe hôm nay, qua ngày là mất, không bán lại được.", "big", "🚌", "Ghế trống = mất"],
    ],
    w: [
      "Dịch vụ không thể cất trữ, đây là điểm khác biệt cốt lõi.",
      "Phục vụ người khác thì hàng hóa nào cũng vậy, không phải điểm khác biệt.",
      "Đáp ứng nhu cầu khách hàng cũng là mục đích chung của mọi hàng hóa.",
      "Tính thời điểm chỉ là hệ quả. Không thể cất trữ mới là điểm cốt lõi.",
    ],
    m: "Dịch vụ: làm xong, dùng liền, không để dành!",
    me: "💇",
  },
  27: {
    t: "dq",
    h: "Các tập đoàn độc quyền kiếm lợi nhuận rất cao. Vậy tiền đó thực sự từ đâu ra?",
    k: [
      ["lợi nhuận độc quyền cao", "💎", "“Lợi nhuận độc quyền cao” là gì?", "Là phần lợi nhuận lớn hơn mức trung bình mà tổ chức độc quyền thu được nhờ nắm quyền định giá.", "Nguồn chính vẫn là lao động của công nhân ngay trong xí nghiệp độc quyền, còn các nguồn khác chỉ là phụ."],
    ],
    x: [
      ["Tập đoàn độc quyền có hàng nghìn công nhân cùng làm việc.", "row", "🏭 👷 👷", "Tập đoàn|Công nhân|Công nhân"],
      ["Họ tạo ra giá trị lớn hơn nhiều so với tiền lương được trả.", "bars", "💵 📦", "Lương:30|Giá trị tạo ra:100"],
      ["Cộng thêm giá bán độc quyền cao, tập đoàn thu về lợi nhuận khổng lồ.", "big", "💎", "Lợi nhuận độc quyền"],
    ],
    w: [
      "Lao động ngoài độc quyền cũng bị chiếm một phần, nhưng không phải nguồn chính.",
      "Giá trị thặng dư của nhà tư bản vừa và nhỏ chỉ là nguồn phụ.",
      "Lao động của người sản xuất nhỏ cũng chỉ là nguồn phụ.",
      "Nguồn chính là lao động của công nhân làm việc trong chính các xí nghiệp độc quyền.",
    ],
    m: "Gốc ở trong nhà máy, ngọn mới ở bên ngoài!",
    me: "💎",
  },
  28: {
    t: "lt",
    h: "Trường phái nào tin rằng xã hội vận hành như thiên nhiên, theo quy luật khách quan? Bạn thử đoán trước khi xem nhé!",
    k: [
      ["quy luật tự nhiên", "🍎", "Vì sao họ xem xã hội chạy theo quy luật tự nhiên?", "Họ tin kinh tế vận hành như quả táo rơi: có quy luật khách quan, con người không thể tùy ý thay đổi.", "Trường phái nổi bật nhất với ý tưởng này là kinh tế chính trị cổ điển Anh, với “bàn tay vô hình” của Xmít."],
    ],
    x: [
      ["Quả táo rơi xuống đất chứ không bay lên trời. Đó là quy luật tự nhiên.", "flow", "🍎 ⬇️ 🌍", "Táo|Rơi|Đất"],
      ["Người Anh cho rằng giá cả cũng lên xuống theo quy luật như vậy.", "row", "📈 📉 🔄", "Giá lên|Giá xuống|Tự cân bằng"],
      ["Cứ để thị trường tự vận hành, “bàn tay vô hình” sẽ điều chỉnh mọi thứ.", "big", "🖐️", "Bàn tay vô hình"],
    ],
    w: [
      "Chủ nghĩa trọng thương chủ trương nhà nước can thiệp để tích trữ vàng bạc.",
      "Trọng nông có nhắc tới trật tự tự nhiên, nhưng đáp án chuẩn của đề này là cổ điển Anh.",
      "Kinh tế chính trị cổ điển Anh là trường phái gắn liền với quan điểm này.",
      "Mác nhấn mạnh quy luật xã hội mang tính lịch sử, không bất biến như quy luật tự nhiên.",
    ],
    m: "Quy luật tự nhiên, bàn tay vô hình: nhớ người Anh!",
    me: "🖐️",
  },
  29: {
    t: "lt",
    h: "Học môn này để làm gì? Có bốn chức năng cần thuộc lòng. Cùng nhớ bằng hình ảnh!",
    k: [
      ["phương pháp luận", "🧰", "“Phương pháp luận” là gì?", "Là cách nghĩ, cách tiếp cận để các môn khoa học khác nghiên cứu vấn đề, như một hộp dụng cụ chung.", "Bốn chức năng cần thuộc: nhận thức, thực tiễn, tư tưởng, phương pháp luận."],
    ],
    x: [
      ["Nhận thức: giúp ta hiểu quy luật của nền kinh tế.", "big", "🔍", "Nhận thức"],
      ["Thực tiễn: dùng hiểu biết đó để chỉ đạo chính sách thực tế.", "big", "🛠️", "Thực tiễn"],
      ["Tư tưởng: hình thành quan điểm đúng đắn. Phương pháp luận: cung cấp cách nghĩ cho các khoa học khác.", "row", "💡 🧰", "Tư tưởng|Phương pháp luận"],
    ],
    w: [
      "Đưa chức năng khoa học vào bộ bốn, trong khi thiếu phương pháp luận. Sai.",
      "Có khoa học mà thiếu tư tưởng, nên không đủ.",
      "Thiếu chức năng nhận thức, và dự báo không thuộc bộ bốn chuẩn.",
      "Nhận thức, thực tiễn, tư tưởng, phương pháp luận. Đủ bốn chức năng.",
    ],
    m: "Nhận, Thực, Tư, Phương: bốn chữ đầu dễ nhớ!",
    me: "🧰",
  },
  30: {
    t: "lt",
    h: "Tên của môn học này có từ bao giờ và ai đặt? Một con số nhỏ nhưng rất dễ bị đánh lừa!",
    k: [
      ["thuật ngữ", "🏷️", "Ai là người đặt tên cho môn kinh tế chính trị?", "Năm một nghìn sáu trăm mười lăm, nhà kinh tế người Pháp Môn-crê-chiên lần đầu dùng cụm từ kinh tế chính trị.", "Vì sao có chữ chính trị? Vì ông muốn nói tới việc quản lý kinh tế của cả quốc gia, chứ không chỉ kinh tế của gia đình."],
    ],
    x: [
      ["Năm một nghìn sáu trăm mười lăm, ở nước Pháp.", "big", "📅", "1615"],
      ["Một nhà kinh tế viết sách, lần đầu gọi môn này là kinh tế chính trị.", "big", "📖", "Cuốn sách đầu tiên"],
      ["Từ đó môn học mang tên ấy cho tới tận bây giờ.", "flow", "📖 🏛️ 🎓", "Cuốn sách|Nhà nước|Môn học"],
    ],
    w: [
      "Một nghìn sáu trăm mười lăm, đúng năm.",
      "Một nghìn sáu trăm mười sáu chỉ lệch một năm thôi, nhưng sai là sai!",
      "Một nghìn sáu trăm mười bảy cũng không đúng.",
      "Một nghìn sáu trăm mười tám cũng không đúng.",
    ],
    m: "Một sáu một năm: nhớ là một sáu một năm!",
    me: "📅",
  },
};
