import type { QC } from "../types";

export const b05: Record<number, QC> = {
  41: {
    t: "cnh",
    h: "Kinh tế tri thức nghe rất hiện đại. Nhưng định nghĩa chuẩn của nó gồm những gì? Cùng mổ xẻ!",
    k: [
      ["quyết định nhất", "🎯", "“Giữ vai trò quyết định nhất” nghĩa là sao?", "Nghĩa là thiếu tri thức thì nền kinh tế không phát triển được, các yếu tố khác chỉ đứng sau.", "Vì sao các đáp án khác chưa đủ? Vì chúng chỉ nói một phần. Định nghĩa đầy đủ phải có ba việc: sản sinh, phổ cập và sử dụng tri thức."],
    ],
    x: [
      ["Sản sinh: các nhà khoa học nghiên cứu ra điều mới.", "big", "🔬", "Sản sinh"],
      ["Phổ cập: tri thức đó được truyền tới mọi người qua trường học và Internet.", "flow", "🔬 🌐 🎓", "Nghiên cứu|Internet|Trường học"],
      ["Sử dụng: doanh nghiệp biến tri thức thành sản phẩm, như chiếc điện thoại thông minh.", "flow", "💡 📱 💰", "Ý tưởng|Sản phẩm|Doanh thu"],
    ],
    w: [
      "Đầy đủ: sản sinh, phổ cập, sử dụng tri thức, và tri thức giữ vai trò quyết định nhất.",
      "Chỉ nói áp dụng kỹ thuật vào sản xuất, thiếu hẳn vai trò quyết định của tri thức.",
      "Nói về phát triển giáo dục, đó là nền tảng chứ chưa phải định nghĩa.",
      "Pha thêm chuyện du học, đã lạc đề khỏi định nghĩa.",
    ],
    m: "Ba chữ cần nhớ: sản sinh, phổ cập, sử dụng!",
    me: "💡",
  },
  42: {
    t: "dq",
    h: "Tư bản tài chính không rơi từ trên trời xuống. Nó sinh ra từ cuộc hôn nhân của hai thế lực khổng lồ. Hai thế lực nào?",
    k: [
      ["độc quyền trong công nghiệp và ngân hàng", "🧩", "Vì sao công nghiệp và ngân hàng lại cần nhau?", "Công nghiệp độc quyền cần vốn lớn nên phải vay ngân hàng. Ngân hàng độc quyền có nhiều tiền nên đầu tư vào công nghiệp.", "Hai bên ôm chặt lấy nhau, hợp nhất lại thành tư bản tài chính."],
    ],
    x: [
      ["Một tập đoàn thép khổng lồ cần một khoản vốn khổng lồ.", "big", "🏭", "Công nghiệp độc quyền"],
      ["Ngân hàng lớn cho vay, mua cổ phần, rồi cử người vào ban lãnh đạo.", "flow", "🏦 💵 🏭", "Ngân hàng|Cho vay|Nhà máy"],
      ["Hai bên hòa vào nhau thành tư bản tài chính.", "merge", "🏭 🏦 💰", "Công nghiệp|Ngân hàng|Tư bản tài chính"],
    ],
    w: [
      "Thương nghiệp không phải gốc của tư bản tài chính.",
      "Độc quyền trong công nghiệp và ngân hàng, đúng nguồn gốc.",
      "Công nghiệp và thương nghiệp, thiếu mất ngân hàng.",
      "Công, nông, thương trải quá rộng, thiếu vai trò ngân hàng.",
    ],
    m: "Tài chính bằng công nghiệp cộng ngân hàng!",
    me: "🏦",
  },
  43: {
    t: "cnh",
    h: "Lại câu chọn phương án sai. Bốn vai trò nghe na ná nhau, chỉ khác một hai chữ. Cẩn thận nhé!",
    k: [
      ["quan hệ sản xuất", "🤝", "Vì sao phương án B sai mà phương án C lại đúng?", "Cách mạng công nghiệp trước hết làm lực lượng sản xuất tiến lên. Quan hệ sản xuất phải điều chỉnh để hoàn thiện theo.", "Nói quan hệ sản xuất mới ra đời là quá tay. Cách mạng công nghiệp thúc đẩy hoàn thiện quan hệ hiện có, chứ không sinh ra cái hoàn toàn mới."],
    ],
    x: [
      ["Máy móc mới làm lực lượng sản xuất tăng tốc.", "big", "🚀", "Lực lượng sản xuất"],
      ["Cách làm việc, cách quản lý phải đổi theo cho kịp.", "flow", "🤖 📋 👥", "Máy móc|Quy trình|Con người"],
      ["Quan hệ sản xuất được hoàn thiện dần, chứ không phải thay hẳn toàn bộ.", "steps", "🔧 🔨 ✅", "Điều chỉnh|Sửa|Hoàn thiện"],
    ],
    w: [
      "Thúc đẩy lực lượng sản xuất, ý đúng nên loại.",
      "Nói thúc đẩy quan hệ sản xuất mới ra đời là chưa chuẩn. Đây chính là câu sai.",
      "Thúc đẩy hoàn thiện quan hệ sản xuất, ý đúng nên loại.",
      "Thúc đẩy đổi mới phương thức quản trị, ý đúng nên loại.",
    ],
    m: "Cách mạng công nghiệp thì hoàn thiện, đừng bảo là thay mới hoàn toàn!",
    me: "🔧",
  },
  44: {
    t: "tb",
    h: "Hai cách bóc lột khác nhau nhưng chung một mục tiêu. Điểm giống nhau đó là gì?",
    k: [
      ["tỷ suất giá trị thặng dư", "📊", "“Tỷ suất giá trị thặng dư tăng” nghĩa là gì?", "Là phần lãi so với tiền công tăng lên, tức nhà tư bản chiếm được nhiều hơn trên mỗi đồng tiền công.", "Cả hai phương pháp đều nhằm mục đích này, chỉ khác cách làm: một bên kéo dài ngày làm việc, một bên tăng năng suất."],
    ],
    x: [
      ["Tuyệt đối: kéo dài ngày làm việc, từ tám lên mười giờ.", "flow", "🕗 ➡️ 🕙", "8 giờ|Kéo dài|10 giờ"],
      ["Tương đối: giữ nguyên ngày làm việc, nhưng nhờ máy móc, hàng của công nhân rẻ đi nên thời gian lao động tất yếu ngắn lại.", "flow", "🤖 📉 ⏱️", "Máy móc|Hàng rẻ|Tất yếu ngắn"],
      ["Hai cách khác nhau nhưng cùng đích: tăng tỷ suất giá trị thặng dư.", "merge", "🕙 ⏱️ 📊", "Tuyệt đối|Tương đối|Tăng tỷ suất"],
    ],
    w: [
      "Cả hai đều làm tăng tỷ suất giá trị thặng dư. Đây là điểm giống nhau.",
      "Làm công nhân tốn sức hơn chỉ đúng với một vài trường hợp, không chung cho cả hai.",
      "Giảm giá trị sức lao động chỉ đúng với phương pháp tương đối.",
    ],
    m: "Hai con đường, một đích đến!",
    me: "🎯",
  },
  45: {
    t: "dq",
    h: "Có những ngành mà tư nhân tránh xa, nhưng xã hội lại cần. Vậy nhà nước nhảy vào những ngành nào?",
    k: [
      ["thu hồi vốn chậm", "🐌", "Vì sao tư nhân né những ngành này?", "Tư nhân muốn lời nhanh và nhiều. Ngành cần vốn lớn mà lâu mới thu hồi, lợi nhuận lại ít thì họ không dám làm.", "Nhưng xã hội vẫn cần điện, đường, cầu cảng. Nên nhà nước phải đứng ra làm thay."],
    ],
    x: [
      ["Xây một nhà máy điện cần hàng nghìn tỷ, hai mươi năm mới thu hồi vốn.", "big", "⚡", "Vốn lớn, thu hồi lâu"],
      ["Nhà tư bản thấy lời ít, chậm, nên lắc đầu.", "row", "🤔 ⏳ 💸", "Cân nhắc|Chậm|Lời ít"],
      ["Nhà nước nhảy vào đầu tư để nền kinh tế vẫn chạy.", "flow", "🏛️ 🏗️ ⚡", "Nhà nước|Xây dựng|Điện"],
    ],
    w: [
      "Thu hồi vốn nhanh thì tư nhân tự lo được.",
      "Lợi nhuận cao thì tư nhân tranh nhau làm.",
      "Vốn không lớn, thu hồi nhanh, lợi nhuận cao thì càng hấp dẫn tư nhân.",
      "Vốn lớn, thu hồi chậm, lợi nhuận ít. Tư nhân né nên nhà nước làm thay.",
    ],
    m: "Vốn lớn, chậm, lời ít: nhà nước gánh!",
    me: "🏛️",
  },
  46: {
    t: "tb",
    h: "Công thức tính khối lượng giá trị thặng dư. Chỉ cần nhớ đúng hai chữ cái, không cần học thuộc lòng!",
    k: [
      ["khối lượng giá trị thặng dư", "🧮", "Vì sao là m phẩy nhân V?", "m phẩy là tỷ suất giá trị thặng dư, V là tư bản khả biến, tức tổng tiền công. Mỗi đồng tiền công đẻ ra bao nhiêu lãi, nhân với tổng tiền công.", "Ví dụ mỗi đồng tiền công sinh ra một đồng rưỡi lãi, trả công hai trăm triệu thì lãi ba trăm triệu."],
    ],
    x: [
      ["Mỗi đồng tiền công đem lại một đồng rưỡi lãi.", "big", "💵", "m phẩy = 150%"],
      ["Tổng tiền công trả cho công nhân là hai trăm triệu.", "big", "👷", "V = 200 triệu"],
      ["Lãi là một phẩy năm nhân hai trăm triệu, bằng ba trăm triệu.", "row", "💵 ✖️ 👷 🟰 💰", "1,5|×|200 triệu|=|300 triệu"],
    ],
    w: [
      "p phẩy là tỷ suất lợi nhuận, không dùng trong công thức này.",
      "M bằng m phẩy nhân V. Đúng công thức.",
      "T là thời gian, nhân với thời gian thì sai đơn vị.",
    ],
    m: "Lớn M bằng m phẩy nhân lớn V!",
    me: "🧮",
  },
  47: {
    t: "hh",
    h: "Định nghĩa sản xuất hàng hóa nghe đơn giản, nhưng đề cố tình thêm những chữ gây rối. Cùng lọc ra nhé!",
    k: [
      ["để trao đổi mua bán", "🛍️", "Điểm mấu chốt của sản xuất hàng hóa là gì?", "Là sản phẩm làm ra để mang ra thị trường trao đổi, mua bán, chứ không phải để tự dùng.", "Các đáp án khác cố nhét thêm quy luật hay tuân thủ vào định nghĩa, nhưng định nghĩa chuẩn rất giản dị."],
    ],
    x: [
      ["Bà nông dân trồng rau để tự ăn: chưa phải sản xuất hàng hóa.", "big", "🥬", "Tự dùng"],
      ["Bà trồng rau đem ra chợ bán lấy tiền: đó là sản xuất hàng hóa.", "flow", "🥬 🛒 💵", "Rau|Chợ|Tiền"],
      ["Điểm mấu chốt: làm ra để trao đổi.", "swap", "🥬 💵", "Rau|Tiền"],
    ],
    w: [
      "Sản phẩm làm ra để trao đổi mua bán trên thị trường. Đúng định nghĩa.",
      "Tuân thủ quy luật thị trường là hệ quả, không phải định nghĩa.",
      "Nói do các quy luật quyết định là lẫn lộn nguyên nhân với hệ quả.",
    ],
    m: "Làm ra là để bán!",
    me: "🛍️",
  },
  48: {
    t: "dq",
    h: "Xuất khẩu tư bản là dấu hiệu nổi bật của một giai đoạn. Đó là giai đoạn nào, và vì sao?",
    k: [
      ["xuất khẩu tư bản", "🏗️", "Vì sao đến giai đoạn độc quyền mới xuất khẩu tư bản?", "Khi độc quyền thống trị, trong nước đã có “tư bản thừa”, đầu tư tiếp không còn lãi cao. Họ mang vốn ra nước ngoài, nơi đất rẻ, lao động rẻ, lợi nhuận cao.", "Vì vậy xuất khẩu tư bản là đặc điểm nổi bật của chủ nghĩa tư bản độc quyền."],
    ],
    x: [
      ["Trong nước, vốn dồi dào nhưng chỗ đầu tư lãi cao đã hết.", "big", "🏦", "Tư bản thừa"],
      ["Nước ngoài có đất rẻ, nhân công rẻ, lợi nhuận cao hơn nhiều.", "big", "🌏", "Lãi cao"],
      ["Thế là tư bản đi ra nước ngoài mở nhà máy.", "flow", "🏦 ✈️ 🏭", "Vốn|Ra nước ngoài|Nhà máy"],
    ],
    w: [
      "Phương thức sản xuất phong kiến không có xuất khẩu tư bản.",
      "Chủ nghĩa tư bản nói chung thì chưa đúng đặc trưng, cần đúng giai đoạn.",
      "Tự do cạnh tranh thì nổi bật là xuất khẩu hàng hóa.",
      "Giai đoạn độc quyền, đúng đặc điểm nổi bật.",
    ],
    m: "Độc quyền thì vốn đi xa!",
    me: "✈️",
  },
  49: {
    t: "lt",
    h: "Nghiên cứu kinh tế mà không có phòng thí nghiệm thì làm bằng cách nào? Câu trả lời hơi bất ngờ!",
    k: [
      ["trừu tượng hóa khoa học", "🔬", "“Trừu tượng hóa” là gì?", "Là gạt bỏ những chi tiết ngẫu nhiên, phụ, để nhìn ra bản chất và quy luật chung của hiện tượng kinh tế.", "Vì sao phù hợp nhất? Vì kinh tế không thể đặt vào ống nghiệm, nên phải dùng sức tư duy để tách cái cốt lõi ra."],
    ],
    x: [
      ["Mỗi chợ một giá rau, hôm nay nắng, mai mưa, giá lên xuống lung tung.", "row", "☀️ 🌧️ 🥬", "Nắng|Mưa|Rau"],
      ["Bỏ qua yếu tố ngẫu nhiên, ta thấy cái cốt lõi: giá xoay quanh giá trị.", "big", "🎯", "Cốt lõi"],
      ["Đó là trừu tượng hóa khoa học: lọc cái chung ra khỏi cái riêng.", "flow", "🥬 🔬 📐", "Hiện tượng|Lọc|Quy luật"],
    ],
    w: [
      "Trừu tượng hóa khoa học, phương pháp đặc thù và phù hợp nhất của kinh tế chính trị.",
      "Phân tích và tổng hợp là phương pháp chung, dùng cho mọi môn.",
      "Quy nạp và diễn dịch cũng là phương pháp chung chung.",
      "Khảo sát thực tiễn chỉ cung cấp dữ liệu, chưa tự rút ra quy luật.",
    ],
    m: "Kinh tế không có kính hiển vi, chỉ có trừu tượng hóa!",
    me: "🔬",
  },
  50: {
    t: "vn",
    h: "Tư duy của Đảng về kinh tế thị trường đã thay đổi lớn. Từ chỗ nghi ngờ trở thành sử dụng. Là thế nào?",
    k: [
      ["có thể và cần thiết", "✅", "“Có thể” và “cần thiết” khác nhau ở chỗ nào?", "Có thể nghĩa là làm được. Cần thiết nghĩa là nên làm vì phục vụ mục tiêu.", "Tư duy của Đảng: sử dụng được kinh tế thị trường, và nên sử dụng, để xây dựng chủ nghĩa xã hội."],
    ],
    x: [
      ["Ngày xưa nhiều người nghĩ thị trường là của riêng tư bản.", "big", "🤔", "Quan niệm cũ"],
      ["Đổi mới nhận ra thị trường là công cụ phát triển, ai dùng cũng được.", "big", "🛠️", "Công cụ"],
      ["Vậy ta dùng nó để dân giàu nước mạnh.", "flow", "🛒 ➡️ 🇻🇳", "Thị trường|Dùng|Việt Nam"],
    ],
    w: [
      "Có thể và cần thiết sử dụng kinh tế thị trường để xây dựng chủ nghĩa xã hội. Đúng tư duy của Đảng.",
      "Có thể mà không cần thiết thì thiếu ý.",
      "Nói không thể thì ngược hẳn quan điểm đổi mới.",
      "Cho rằng thị trường là của riêng tư bản là quan điểm cũ.",
    ],
    m: "Có thể và cần thiết: hai cái gật đầu!",
    me: "👍",
  },
};
