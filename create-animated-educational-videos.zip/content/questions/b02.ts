import type { QC } from "../types";

export const b02: Record<number, QC> = {
  11: {
    t: "cnh",
    h: "Cuộc cách mạng công nghiệp lần bốn sắp lấy đi của các nước đang phát triển một thứ mà họ vẫn tự hào. Đó là gì?",
    k: [
      ["lợi thế", "🏆", "“Lợi thế” là gì?", "Là điểm mạnh giúp bạn thắng khi so với người khác, ví dụ nhiều tài nguyên hoặc nhiều lao động lương thấp.", "Vậy vì sao lần bốn lại làm mất? Vì robot và trí tuệ nhân tạo làm việc rẻ hơn công nhân giá rẻ, nhà máy cũng không còn phụ thuộc vào tài nguyên thô."],
    ],
    x: [
      ["Trước đây, hãng giày đặt nhà máy ở nơi có nhân công rẻ.", "row", "👟 🏭 👷", "Giày|Nhà máy|Công nhân giá rẻ"],
      ["Nay, robot may giày suốt ngày đêm, không nghỉ, không đòi lương.", "big", "🤖", "Robot"],
      ["Lợi thế nhân công rẻ biến mất. Muốn thắng phải có công nghệ và lao động chất lượng cao.", "steps", "👷 🤖 🎓", "Công nhân giá rẻ|Robot|Lao động giỏi"],
    ],
    w: [
      "Tài nguyên thiên nhiên và công nhân giá rẻ là lợi thế truyền thống, và sẽ bị công nghệ thay thế.",
      "Khoáng sản và sức lao động nói chung vẫn còn cần. Cái mất đi là phần giá rẻ, nên chưa chính xác.",
      "Công nghệ và nhân công chất lượng cao là thứ cần có, không phải lợi thế sắp mất.",
    ],
    m: "Lần bốn: robot lên ngôi, chỉ rẻ thôi thì chưa đủ!",
    me: "🤖",
  },
  12: {
    t: "vn",
    h: "Đảng ta luôn nhấn mạnh xây dựng một nền kinh tế như thế nào? Đáp án nằm ở hai chữ rất quen thuộc.",
    k: [
      ["độc lập, tự chủ", "🛡️", "“Độc lập, tự chủ” nghĩa là gì?", "Là tự quyết con đường phát triển của mình, không bị phụ thuộc vào nước khác, dù vẫn mở cửa hợp tác.", "Vậy có mâu thuẫn với hội nhập không? Không. Hội nhập giúp mình mạnh hơn, còn độc lập tự chủ là nền móng để đứng vững."],
    ],
    x: [
      ["Hãy tưởng tượng một ngôi nhà. Phải có móng vững trước đã.", "big", "🏠", "Móng: độc lập, tự chủ"],
      ["Cửa mở rộng đón gió bốn phương, đó là hội nhập và hợp tác quốc tế.", "row", "🌍 🤝 🚪", "Thế giới|Hợp tác|Mở cửa"],
      ["Có móng chắc thì mở cửa bao nhiêu cũng không sợ đổ.", "flow", "🛡️ 🏠 🌍", "Độc lập|Nền kinh tế|Hội nhập"],
    ],
    w: [
      "Mở cửa là cách làm, chưa phải điều Đảng nhấn mạnh làm nền tảng.",
      "Độc lập, tự chủ là nền tảng, và đi cùng hội nhập quốc tế sâu rộng.",
      "Hội nhập là phương hướng quan trọng, nhưng nền tảng vẫn là độc lập, tự chủ.",
      "Tính cạnh tranh là yêu cầu cần có, nhưng không phải điều được nhấn mạnh trước tiên.",
    ],
    m: "Độc lập tự chủ là móng nhà, hội nhập là cánh cửa!",
    me: "🏠",
  },
  13: {
    t: "hh",
    h: "Tiền không tự nhiên rơi từ trên trời xuống. Nó ra đời vì một nhu cầu rất thực tế!",
    k: [
      ["nhu cầu", "🛎️", "Nhu cầu nào khiến tiền xuất hiện?", "Khi người ta sản xuất ngày càng nhiều hàng để trao đổi, đổi hàng lấy hàng trở nên rất bất tiện. Cần một thước đo chung.", "Vậy tiền sinh ra từ đâu? Từ chính quá trình sản xuất và trao đổi hàng hóa, chứ không phải ai đó nghĩ ra cho vui."],
    ],
    x: [
      ["Anh thợ giày muốn đổi giày lấy gạo, nhưng người bán gạo lại đang cần vải.", "row", "👞 ❓ 🌾 ❓ 🧵", "Giày|Không khớp|Gạo|Không khớp|Vải"],
      ["Vòng vo mệt quá! Thế là mọi người chọn một vật làm trung gian chung.", "big", "🪙", "Vật trung gian"],
      ["Vật đó dần trở thành tiền, và mọi hàng hóa đều quy ra được bằng nó.", "flow", "👞 🪙 🌾", "Giày|Tiền|Gạo"],
    ],
    w: [
      "Nhu cầu sản xuất và trao đổi hàng hóa chính là gốc rễ của tiền tệ.",
      "Lưu thông hàng hóa chỉ là một phần, chưa nói được nguồn gốc ra đời của tiền.",
      "Lưu thông tiền tệ là việc xảy ra sau khi đã có tiền rồi.",
      "Sản xuất giá trị không nói lên nhu cầu trao đổi.",
    ],
    m: "Có nhiều hàng để đổi, thì tiền mới ra đời!",
    me: "🪙",
  },
  14: {
    t: "dq",
    h: "Hai chữ ngang và dọc nghe đơn giản mà rất hay bị nhầm. Cùng phân biệt cho thật rõ!",
    k: [
      ["liên kết ngang", "↔️", "Liên kết ngang khác liên kết dọc ở chỗ nào?", "Ngang nghĩa là các doanh nghiệp cùng ngành, cùng làm một loại sản phẩm, ghép lại cho lớn mạnh.", "Còn liên kết dọc là các doanh nghiệp nối tiếp nhau trong một chuỗi, từ nguyên liệu đến sản phẩm cuối."],
    ],
    x: [
      ["Ba hãng xe máy cùng ngành sáp nhập thành một tập đoàn. Đó là liên kết ngang.", "merge", "🛵 🛵 🛵 🏢", "Hãng A|Hãng B|Hãng C|Tập đoàn"],
      ["Còn một tập đoàn nắm từ mỏ sắt, nhà máy thép đến xưởng ô tô, đó là liên kết dọc.", "flow", "⛏️ 🏭 🚗", "Mỏ sắt|Nhà máy thép|Xưởng ô tô"],
      ["Nhớ nhé: cùng hàng thì ngang, nối tầng thì dọc.", "vs", "↔️ ↕️", "Ngang|Dọc"],
    ],
    w: [
      "Liên kết dọc nối các khâu khác nhau của một chuỗi, không phải cùng ngành.",
      "Cùng một ngành thì gọi là liên kết ngang.",
      "Không thể cả hai, vì cùng ngành chỉ ứng với liên kết ngang.",
      "Đã có tên gọi chính xác là liên kết ngang rồi, không cần hình thức khác.",
    ],
    m: "Ngang là ngang hàng cùng ngành, dọc là dây chuyền nối tầng!",
    me: "↔️",
  },
  15: {
    t: "tb",
    h: "Nhà tư bản mua đúng giá, bán đúng giá, vậy tiền lời đến từ đâu? Đây là câu hỏi hóc búa nhất của Mác!",
    k: [
      ["hàng hóa sức lao động", "💪", "Vì sao đáp án lại là “mua được hàng hóa sức lao động”?", "Nhà tư bản mua đúng giá, không lừa ai. Nhưng khi dùng sức lao động, công nhân tạo ra giá trị nhiều hơn tiền công họ nhận.", "Sức lao động là món hàng đặc biệt: dùng nó thì sinh ra giá trị mới, lớn hơn giá trị của chính nó. Phần dôi ra là giá trị thặng dư."],
    ],
    x: [
      ["Chủ xưởng trả cho công nhân tiền công đủ sống một ngày, đúng giá thị trường.", "swap", "💵 🧑‍🏭", "Tiền công|Sức lao động"],
      ["Nhưng trong ngày, công nhân làm ra số hàng trị giá nhiều hơn tiền công.", "bars", "💵 📦", "Tiền công:50|Giá trị tạo ra:100"],
      ["Phần dôi ra đó chính là giá trị thặng dư, và nó có từ việc dùng sức lao động.", "big", "✨", "Giá trị thặng dư"],
    ],
    w: [
      "Mua rẻ hơn giá trị là mánh lừa, không phải nguồn gốc, vì trao đổi vẫn theo nguyên tắc ngang giá.",
      "Mua đắt hơn cũng vậy, lưu thông thuần túy không tạo ra giá trị mới.",
      "Mua bằng giá trị thật thì đúng nguyên tắc, nhưng chưa chỉ ra thặng dư đến từ đâu.",
      "Hàng hóa sức lao động là thứ duy nhất khi dùng sẽ tạo ra nhiều giá trị hơn chính nó.",
    ],
    m: "Bí mật nằm ở một món hàng đặc biệt: sức lao động!",
    me: "💪",
  },
  16: {
    t: "hh",
    h: "Tiền tệ không xuất hiện trong một ngày. Có một khoảnh khắc đánh dấu nó chính thức ra đời. Đó là lúc nào?",
    k: [
      ["vật ngang giá chung", "📏", "“Vật ngang giá chung” nghĩa là gì?", "Là món hàng mà mọi người đều chấp nhận dùng làm thước đo để đổi lấy mọi thứ khác.", "Khi vật ngang giá chung được cố định lại ở vàng và bạc thì hình thái tiền tệ xuất hiện."],
    ],
    x: [
      ["Ban đầu, thóc tình cờ đổi được một cái áo. Đó chỉ là trao đổi ngẫu nhiên.", "swap", "🌾 👕", "Thóc|Áo"],
      ["Sau đó, nhiều thứ cùng đổi qua một thứ chung, nhưng khi thì vỏ sò, khi thì muối, khi thì gia súc.", "row", "🐚 🧂 🐄", "Vỏ sò|Muối|Gia súc"],
      ["Cuối cùng, mọi người thống nhất dùng kim loại quý, vàng và bạc. Bền, dễ chia nhỏ. Tiền tệ ra đời!", "big", "🥇", "Vàng, bạc"],
    ],
    w: [
      "Sản xuất và trao đổi phát triển là điều kiện chung, chưa chỉ đúng thời điểm tiền xuất hiện.",
      "Vật ngang giá chung cố định ở vàng, bạc thì hình thái tiền tệ xuất hiện.",
      "Có một thứ hàng làm trung gian là hình thái giá trị chung, chưa phải tiền.",
      "Vượt ra ngoài phạm vi quốc gia là chuyện của tiền tệ thế giới về sau.",
    ],
    m: "Vàng bạc được cố định, tiền tệ xuất hiện!",
    me: "🥇",
  },
  17: {
    t: "vn",
    h: "Một câu trích dẫn nổi tiếng về khoa học công nghệ nhảy vọt. Nó nằm trong văn kiện của Đại hội nào?",
    k: [
      ["lực lượng sản xuất", "⚙️", "“Lực lượng sản xuất” là gì?", "Là người lao động cộng với công cụ, máy móc và tri thức. Kinh tế tri thức làm phần tri thức mạnh lên rất nhiều.", "Vì sao câu này thuộc Đại hội chín? Vì đó là năm hai nghìn không trăm lẻ một, mở đầu thập niên mới và nhấn mạnh khoa học công nghệ nhảy vọt."],
    ],
    x: [
      ["Hãy nhớ mốc: Đại hội chín, ngay đầu thế kỷ hai mươi mốt.", "big", "📅", "Đại hội IX, năm 2001"],
      ["Lúc đó thế giới bước vào kỷ nguyên Internet, tri thức thành lực lượng sản xuất hàng đầu.", "row", "🌐 🧠 ⚙️", "Internet|Tri thức|Sản xuất"],
      ["Đảng nhận định khoa học công nghệ sẽ nhảy vọt, kinh tế tri thức ngày càng nổi bật.", "steps", "🧪 🚀 🧠", "Khoa học|Nhảy vọt|Kinh tế tri thức"],
    ],
    w: [
      "Đại hội tám còn tập trung đẩy mạnh công nghiệp hóa, hiện đại hóa nói chung.",
      "Đại hội chín, năm hai nghìn không trăm lẻ một, đúng mốc.",
      "Đại hội mười đã sau đó và bổ sung thêm nhiều nội dung khác.",
      "Đại hội mười một nói về chiến lược khác, không phải câu trích này.",
    ],
    m: "Kinh tế tri thức nhảy vọt: Đại hội chín!",
    me: "🚀",
  },
  18: {
    t: "vn",
    h: "Câu này là câu bẫy: đề bảo chọn phương án SAI! Đọc kỹ đề, bạn sẽ không bị lừa.",
    k: [
      ["chọn phương án sai", "⚠️", "“Chọn phương án sai” khác gì chọn đúng?", "Ba đáp án kia đều là lý do ĐÚNG. Đáp án của chúng ta là lý do không hợp lý, kẻ lạc loài trong nhóm.", "Vậy vì sao phải hoàn thiện thể chế? Vì thể chế còn thiếu, kém hiệu lực, thiếu yếu tố thị trường. Còn sự lãnh đạo của Đảng không phải lý do để sửa, mà là nguyên tắc định hướng."],
    ],
    x: [
      ["Hãy tưởng tượng luật chơi của một trò chơi còn thiếu và chưa rõ ràng.", "row", "📜 ❓ ⚠️", "Luật chơi|Thiếu|Rủi ro"],
      ["Thế thì phải sửa luật cho đầy đủ, rõ ràng, người chơi mới làm đúng được.", "flow", "📜 ✏️ ✅", "Luật cũ|Sửa|Hoàn thiện"],
      ["Còn người định hướng cuộc chơi thì không phải lý do để sửa luật.", "big", "🧭", "Lãnh đạo: định hướng"],
    ],
    w: [
      "Thể chế chưa hoàn thiện là lý do đúng, nên loại.",
      "Hệ thống thể chế chưa đầy đủ cũng là lý do đúng, nên loại.",
      "Kém hiệu lực, thiếu yếu tố thị trường là lý do đúng, nên loại.",
      "Đảng lãnh đạo không phải lý do để hoàn thiện, mà là bản chất định hướng. Đây mới là câu sai.",
    ],
    m: "Gặp câu sai: ba đúng một sai, hãy tìm kẻ lạc loài!",
    me: "🔎",
  },
  19: {
    t: "cnh",
    h: "Liên Xô từng biến một nước nông nghiệp thành cường quốc công nghiệp chỉ trong vài kế hoạch năm năm. Bắt đầu từ lúc nào?",
    k: [
      ["công nghiệp hóa kiểu Liên Xô", "🏭", "Mô hình Liên Xô có gì đặc biệt?", "Nhà nước chỉ huy tập trung, ưu tiên công nghiệp nặng, xây rất nhanh bằng các kế hoạch năm năm.", "Mốc cần nhớ là đầu những năm một chín ba mươi."],
    ],
    x: [
      ["Nhà nước vẽ kế hoạch năm năm, ra lệnh xây nhà máy khắp nơi.", "row", "📋 🏗️ 🏭", "Kế hoạch|Xây dựng|Nhà máy"],
      ["Ưu tiên thép, máy móc, năng lượng trước, hàng tiêu dùng đến sau.", "bars", "⚙️ 👕", "Công nghiệp nặng:90|Hàng tiêu dùng:30"],
      ["Nhớ mốc: đầu những năm một chín ba mươi.", "big", "📅", "Đầu những năm 1930"],
    ],
    w: [
      "Những năm hai mươi là thời kỳ khôi phục kinh tế, chưa phải mô hình này.",
      "Đầu những năm ba mươi, đúng mốc.",
      "Những năm bốn mươi là thời kỳ chiến tranh vệ quốc.",
      "Sau năm một chín bốn lăm là thời kỳ khôi phục sau chiến tranh.",
    ],
    m: "Ba mươi: Liên Xô xây nhà máy mọc như nấm!",
    me: "🏭",
  },
  20: {
    t: "dq",
    h: "Xuất khẩu hàng hóa và xuất khẩu tư bản nghe giống nhau nhưng thuộc hai thời đại khác nhau. Đừng để bị nhầm nhé!",
    k: [
      ["xuất khẩu hàng hóa", "📦", "Xuất khẩu hàng hóa thuộc giai đoạn nào?", "Là mang hàng đi bán ở nước ngoài. Giai đoạn tự do cạnh tranh, các nước chủ yếu bán hàng ra thế giới.", "Còn xuất khẩu tư bản là mang tiền vốn ra nước ngoài đầu tư. Cái đó thuộc giai đoạn độc quyền, và đây là chỗ dễ nhầm nhất!"],
    ],
    x: [
      ["Thế kỷ mười chín, nước Anh làm ra vải rồi chở đi bán khắp thế giới.", "flow", "🧵 🚢 🌍", "Vải|Tàu|Thế giới"],
      ["Họ bán hàng, thu tiền về. Đó là xuất khẩu hàng hóa.", "swap", "📦 💰", "Hàng|Tiền"],
      ["Còn khi họ mang tiền ra xây nhà máy ở nước ngoài, đó là xuất khẩu tư bản, của giai đoạn sau.", "vs", "📦 🏭", "Xuất khẩu hàng hóa|Xuất khẩu tư bản"],
    ],
    w: [
      "Xuất khẩu hàng hóa là đặc điểm của giai đoạn tự do cạnh tranh.",
      "Giai đoạn độc quyền nổi bật là xuất khẩu tư bản, không phải hàng hóa.",
      "Độc quyền nhà nước có đặc trưng khác, là nhà nước can thiệp vào kinh tế.",
    ],
    m: "Hàng đi trước, vốn đi sau!",
    me: "🚢",
  },
};
