import type { QC } from "../types";

export const b04: Record<number, QC> = {
  31: {
    t: "tb",
    h: "Đây là công thức nổi tiếng nhất của Mác về tư bản. Chỉ cần nhìn một dấu phẩy là phân biệt được!",
    k: [
      ["T, H, T phẩy", "🔁", "Công thức T, H, T phẩy nghĩa là gì?", "T là tiền, H là hàng, T phẩy là số tiền nhiều hơn. Nhà tư bản bỏ tiền mua hàng, rồi bán để thu về nhiều tiền hơn.", "Còn H, T, H là bán hàng lấy tiền rồi mua hàng khác, mục đích là tiêu dùng chứ không phải kiếm lời."],
    ],
    x: [
      ["Bạn bán rau lấy tiền để mua gạo. Hàng, tiền, hàng. Chỉ để dùng.", "flow", "🥬 💵 🍚", "H|T|H"],
      ["Nhà tư bản thì ngược lại: bỏ tiền mua nguyên liệu, làm ra hàng, bán lấy nhiều tiền hơn.", "flow", "💵 📦 💰", "T|H|T phẩy"],
      ["Khác nhau ở mục đích: một bên để tiêu dùng, một bên để kiếm thêm tiền.", "loop", "💵 📦 💰", "Bỏ tiền|Làm hàng|Thu lời"],
    ],
    w: [
      "H, T, H là công thức lưu thông hàng hóa giản đơn.",
      "T, H, T là đổi tiền lấy tiền bằng nhau, nên vô nghĩa với nhà tư bản.",
      "T, H, T phẩy, tiền đẻ ra nhiều tiền hơn. Đây là công thức chung của tư bản.",
    ],
    m: "Có dấu phẩy là có lời!",
    me: "💰",
  },
  32: {
    t: "tb",
    h: "Tỷ suất giá trị thặng dư và tỷ suất lợi nhuận: ai lớn hơn ai? Một ví dụ số nhỏ sẽ giải quyết ngay!",
    k: [
      ["tỷ suất lợi nhuận", "➗", "Vì sao tỷ suất lợi nhuận luôn nhỏ hơn tỷ suất giá trị thặng dư?", "Tỷ suất giá trị thặng dư lấy lãi chia cho tiền công. Tỷ suất lợi nhuận lấy lãi chia cho toàn bộ vốn, gồm cả máy móc nguyên liệu.", "Tử số giống nhau, mẫu số của lợi nhuận lớn hơn, nên kết quả nhỏ hơn."],
    ],
    x: [
      ["Giả sử lãi một trăm, tiền công một trăm, máy móc và nguyên liệu ba trăm.", "row", "💰 👷 🏭", "Lãi 100|Tiền công 100|Máy móc 300"],
      ["Tỷ suất giá trị thặng dư: lãi chia tiền công, bằng một trăm phần trăm.", "big", "💯", "100%"],
      ["Tỷ suất lợi nhuận: lãi chia tổng vốn bốn trăm, chỉ còn hai mươi lăm phần trăm.", "bars", "💰 💰", "Thặng dư:100|Lợi nhuận:25"],
    ],
    w: [
      "Đáp án này so sánh một tỷ suất với một lượng giá trị, nên không cùng loại.",
      "Lớn hơn là ngược lại với thực tế.",
      "Bằng nhau chỉ xảy ra khi không có tư bản bất biến, điều này không thực tế.",
      "Tỷ suất lợi nhuận luôn nhỏ hơn tỷ suất giá trị thặng dư.",
    ],
    m: "Cùng tử số, mẫu số to hơn thì kết quả bé hơn!",
    me: "➗",
  },
  33: {
    t: "cnh",
    h: "Mác đã nhìn lại cuộc cách mạng công nghiệp lần một và vẽ ra ba chặng đường. Là ba chặng nào?",
    k: [
      ["đại công nghiệp", "🏭", "Ba giai đoạn của Mác là gì?", "Đi từ hợp tác giản đơn, rồi công trường thủ công, tới đại công nghiệp dùng máy móc.", "Điểm khác nhau: ban đầu con người là chính, cuối cùng máy móc là chính."],
    ],
    x: [
      ["Hợp tác giản đơn: nhiều người cùng làm một việc trong một xưởng.", "row", "👷 👷 👷", "Cùng làm|Cùng làm|Cùng làm"],
      ["Công trường thủ công: chia ra công đoạn, mỗi người một việc, vẫn làm bằng tay.", "flow", "✂️ 🧵 👕", "Cắt|May|Hoàn thiện"],
      ["Đại công nghiệp: máy móc làm chủ, con người đứng canh máy.", "big", "🏭", "Đại công nghiệp"],
    ],
    w: [
      "Lao động thủ công, lao động phức tạp là loại lao động, không phải các giai đoạn.",
      "Công nghiệp hóa là tên một quá trình, không phải tên giai đoạn do Mác nêu.",
      "Sản xuất thủ công và sản xuất hiện đại chỉ là cách nói chung chung, chưa đúng thuật ngữ.",
      "Hợp tác giản đơn, công trường thủ công, đại công nghiệp. Chính xác!",
    ],
    m: "Giản đơn, thủ công, đại công nghiệp: ba bậc lên thang!",
    me: "🪜",
  },
  34: {
    t: "vn",
    h: "Khi nào mô hình kinh tế thị trường định hướng xã hội chủ nghĩa chính thức có tên gọi này? Một mốc lịch sử quan trọng!",
    k: [
      ["định hướng", "🧭", "“Định hướng” khác gì “theo”?", "Định hướng là chọn hướng đi và đích đến. Vẫn dùng cơ chế thị trường, nhưng nhằm mục tiêu dân giàu, nước mạnh, dân chủ, công bằng, văn minh.", "Vì sao nói chính thức nêu ra ở Đại hội chín? Vì trước đó mới gọi là kinh tế hàng hóa nhiều thành phần, đến Đại hội chín mới gọi tên đầy đủ mô hình."],
    ],
    x: [
      ["Trước đổi mới: kế hoạch hóa tập trung, bao cấp.", "big", "📋", "Bao cấp"],
      ["Đại hội sáu mở đầu đổi mới: phát triển kinh tế hàng hóa nhiều thành phần.", "big", "🛒", "Hàng hóa nhiều thành phần"],
      ["Đại hội chín: chính thức gọi tên kinh tế thị trường định hướng xã hội chủ nghĩa.", "steps", "📋 🛒 🧭", "Bao cấp|Nhiều thành phần|Định hướng XHCN"],
    ],
    w: [
      "Đại hội sáu mở đầu đổi mới, nhưng chưa gọi tên mô hình này.",
      "Đại hội tám tiếp tục công nghiệp hóa, hiện đại hóa, chưa nêu chính thức.",
      "Đại hội chín chính thức nêu ra mô hình kinh tế thị trường định hướng xã hội chủ nghĩa.",
      "Đại hội mười tiếp tục hoàn thiện, nhưng không phải lần đầu nêu ra.",
    ],
    m: "Thấy chữ chính thức nêu ra thì nhớ Đại hội chín!",
    me: "🧭",
  },
  35: {
    t: "lt",
    h: "Lịch sử các trường phái kinh tế có nhiều tên dài. Ai là người đầu tiên đi vào nghiên cứu sản xuất tư bản chủ nghĩa?",
    k: [
      ["hệ thống lý luận đầu tiên", "🥇", "Vì sao không phải trọng thương hay trọng nông?", "Trọng thương chỉ nhìn vào lưu thông, vào việc tích trữ vàng bạc. Trọng nông mới nhìn vào nông nghiệp.", "Kinh tế chính trị cổ điển Anh là hệ thống đầu tiên đi vào sản xuất tư bản chủ nghĩa, với ý tưởng lao động tạo ra giá trị."],
    ],
    x: [
      ["Trọng thương chỉ chăm chăm đếm vàng bạc trong kho.", "big", "🪙", "Trọng thương"],
      ["Trọng nông cho rằng chỉ ruộng đất mới tạo ra của cải.", "big", "🌾", "Trọng nông"],
      ["Cổ điển Anh bước vào xưởng máy và hỏi: giá trị từ lao động mà ra.", "big", "⚙️", "Cổ điển Anh"],
    ],
    w: [
      "Trọng thương nghiên cứu lĩnh vực lưu thông, không phải sản xuất.",
      "Trọng nông nghiên cứu nông nghiệp, chưa phải sản xuất tư bản chủ nghĩa.",
      "Nói chung chung là cổ điển, chưa chính xác bằng cổ điển Anh.",
      "Kinh tế chính trị cổ điển Anh, đúng theo đáp án của bộ đề.",
    ],
    m: "Muốn tìm người nghiên cứu xưởng máy, hãy tìm người Anh!",
    me: "🇬🇧",
  },
  36: {
    t: "hh",
    h: "Giá trị không tự nhiên thành tiền. Nó phải đi qua bốn chặng. Bạn nhớ đủ không?",
    k: [
      ["hình thái giá trị", "🔄", "Có mấy hình thái và theo thứ tự nào?", "Bốn hình thái: ngẫu nhiên, mở rộng hay còn gọi là đầy đủ, chung, rồi tiền tệ.", "Qua mỗi bước, vật làm thước đo ngày càng ổn định hơn, cuối cùng cố định ở vàng và bạc."],
    ],
    x: [
      ["Ngẫu nhiên: hai thứ tình cờ đổi được cho nhau.", "swap", "🌾 👕", "Thóc|Áo"],
      ["Mở rộng: một thứ có thể đổi được cho rất nhiều thứ khác.", "split", "🌾 👕 🐔 🔪", "Thóc|Áo|Gà|Dao"],
      ["Chung: nhiều thứ cùng quy về một thứ. Tiền tệ: thứ đó chính là vàng bạc.", "merge", "👕 🐔 🔪 🥇", "Áo|Gà|Dao|Tiền"],
    ],
    w: [
      "Thiếu hình thái giá trị mở rộng, nên không đủ.",
      "Dùng cụm “thu hẹp” là sai tên, phải là mở rộng.",
      "Ngẫu nhiên, mở rộng, chung, tiền tệ. Đủ bốn bước, đúng thứ tự.",
      "Thiếu hình thái giá trị ngẫu nhiên ở đầu.",
    ],
    m: "Ngẫu, Mở, Chung, Tiền: mở rộng đứng thứ hai!",
    me: "🔄",
  },
  37: {
    t: "hh",
    h: "Tiền không chỉ để tiêu. Nó còn làm được rất nhiều việc. Đếm xem là mấy việc nhé!",
    k: [
      ["năm chức năng", "🖐️", "Năm chức năng của tiền là gì?", "Thước đo giá trị, phương tiện lưu thông, phương tiện cất trữ, phương tiện thanh toán, và tiền tệ thế giới.", "Mẹo là đếm trên năm ngón tay: đo, lưu thông, cất trữ, thanh toán, thế giới."],
    ],
    x: [
      ["Một: thước đo giá trị. Tiền cho biết món hàng đáng giá bao nhiêu.", "big", "📏", "Thước đo"],
      ["Hai: phương tiện lưu thông, dùng để mua bán. Ba: cất trữ, để dành.", "row", "🛒 🐷", "Lưu thông|Cất trữ"],
      ["Bốn: thanh toán, trả nợ, nộp thuế. Năm: tiền tệ thế giới, dùng giữa các quốc gia.", "row", "🧾 🌍", "Thanh toán|Thế giới"],
    ],
    w: [
      "Ba chức năng là còn thiếu.",
      "Đúng năm chức năng, như vừa đếm.",
      "Sáu chức năng là thừa.",
      "Bảy chức năng còn thừa hơn nữa.",
    ],
    m: "Năm ngón tay, năm chức năng!",
    me: "🖐️",
  },
  38: {
    t: "cnh",
    h: "Một câu hỏi mốc thời gian nữa. Chú ý chữ nửa đầu, nửa cuối vì chúng rất dễ làm bạn hoa mắt!",
    k: [
      ["nửa cuối thế kỷ mười chín", "⏰", "Đọc mốc thời gian thế nào cho không lẫn?", "Nửa cuối thế kỷ mười chín là khoảng từ năm một tám năm mươi tới một tám chín chín, rồi kéo sang đầu thế kỷ hai mươi.", "Các đáp án còn lại đảo chữ nửa đầu, nửa cuối nên rất dễ nhầm."],
    ],
    x: [
      ["Lần một dùng hơi nước, thuộc nửa đầu thế kỷ mười chín.", "big", "💨", "Lần 1: nửa đầu"],
      ["Lần hai bùng nổ ở nửa cuối thế kỷ mười chín với điện, thép và hóa chất.", "row", "⚡ 🔩 🧪", "Điện|Thép|Hóa chất"],
      ["Nó kéo dài sang đầu thế kỷ hai mươi, khi dây chuyền sản xuất ra đời.", "flow", "⚡ 🏭 🚗", "Điện|Dây chuyền|Ô tô"],
    ],
    w: [
      "Từ nửa cuối thế kỷ mười chín đến đầu thế kỷ hai mươi, đúng mốc.",
      "Nửa đầu thế kỷ mười chín là thời của lần một.",
      "Nửa đầu đến nửa cuối thế kỷ hai mươi lại trùng với lần ba.",
      "Nửa cuối mười chín đến nửa cuối hai mươi trộn lẫn cả hai cuộc cách mạng.",
    ],
    m: "Lần hai: cuối mười chín, sang đầu hai mươi!",
    me: "⚡",
  },
  39: {
    t: "cnh",
    h: "Cuộc cách mạng công nghiệp lần một làm thay đổi điều gì sâu sắc nhất? Câu này chỉ có ba đáp án.",
    k: [
      ["lao động máy móc", "⚙️", "Máy móc thay đổi điều gì?", "Trước đó con người dùng tay và công cụ đơn giản. Lần một, máy móc thay thế tay chân.", "Còn dùng điện hay động cơ điện là của lần hai."],
    ],
    x: [
      ["Trước đây, người thợ dệt ngồi dệt vải bằng tay, rất chậm.", "big", "🧶", "Thủ công"],
      ["Máy dệt chạy bằng hơi nước, một máy bằng sức của cả chục thợ.", "flow", "💨 ⚙️ 👕", "Hơi nước|Máy dệt|Vải"],
      ["Nội dung cốt lõi: chuyển từ tay sang máy.", "swap", "✋ ⚙️", "Tay|Máy"],
    ],
    w: [
      "Chuyển từ lao động thủ công sang lao động máy móc, đúng nội dung cốt lõi của lần một.",
      "Động cơ điện là của lần hai.",
      "Năng lượng điện và động cơ điện cũng là của lần hai.",
    ],
    m: "Lần một là máy, lần hai là điện!",
    me: "⚙️",
  },
  40: {
    t: "hh",
    h: "Một tờ giấy in chỉ tốn vài trăm đồng, vậy sao nó mua được bát phở? Bí mật nằm ở loại tiền nào?",
    k: [
      ["tiền quy ước", "📄", "Vì sao tờ giấy lại đáng giá hơn chi phí in nó?", "Tiền quy ước là loại tiền có giá trị hay sức mua vượt xa chi phí làm ra nó. Mọi người cùng tin và chấp nhận.", "Còn tiền vàng thì giá trị bằng chính lượng vàng trong nó, nên khác hẳn."],
    ],
    x: [
      ["Một tờ giấy bạc in ra chỉ tốn vài trăm đồng.", "big", "📄", "Chi phí rất thấp"],
      ["Nhưng nó mua được cả bát phở, vì mọi người cùng tin vào nó.", "swap", "📄 🍜", "Giấy|Phở"],
      ["Đó là tiền quy ước. Giá trị đến từ niềm tin và quy định của nhà nước.", "big", "🤝", "Niềm tin"],
    ],
    w: [
      "Tiền quy ước, đúng với mô tả: sức mua vượt xa chi phí sản xuất.",
      "Tiền tượng trưng là loại gần giống, nhưng đề mô tả đúng tiền quy ước.",
      "Tiền ghi nợ là số dư trong tài khoản ngân hàng, không khớp mô tả.",
      "Tiền vàng có giá trị đúng bằng lượng vàng chứa trong nó, nên không khớp mô tả.",
    ],
    m: "Quy ước nghĩa là cùng tin vào nhau!",
    me: "🤝",
  },
};
