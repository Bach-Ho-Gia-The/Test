import type { QC } from "../types";

export const b06: Record<number, QC> = {
  51: {
    t: "vn",
    h: "Một quan điểm rất đẹp: “dân là gốc”. Nhưng nó xuất hiện trong văn kiện của Đại hội nào?",
    k: [
      ["dân là gốc", "🌱", "“Dân là gốc” nghĩa là gì?", "Nghĩa là mọi chính sách đều phải vì lợi ích của nhân dân, dựa vào nhân dân và phát huy vai trò làm chủ của nhân dân.", "Cây muốn xanh tốt thì rễ phải chắc, và rễ chính là dân."],
    ],
    x: [
      ["Cây muốn tươi tốt phải có rễ chắc. Rễ chính là dân.", "big", "🌳", "Dân là gốc"],
      ["Chính sách tốt nhất là chính sách vì dân và dựa vào dân.", "flow", "🏛️ ❤️ 👨‍👩‍👧‍👦", "Nhà nước|Vì|Nhân dân"],
      ["Nhớ mốc: đáp án của bộ đề là Đại hội mười hai.", "big", "📅", "Đại hội XII"],
    ],
    w: [
      "Đại hội mười chưa nhấn mạnh quan điểm này như vậy.",
      "Đại hội mười một cũng không phải đáp án của câu này.",
      "Đại hội mười hai, đúng theo đáp án của bộ đề.",
      "Đại hội mười ba có tiếp nối, nhưng đáp án bộ đề là Đại hội mười hai.",
    ],
    m: "Dân là gốc, mười hai là mốc!",
    me: "🌱",
  },
  52: {
    t: "cnh",
    h: "Cuộc cách mạng công nghiệp lần bốn bắt đầu được nhắc tới từ đâu và khi nào? Một chút địa lý và lịch sử!",
    k: [
      ["Công nghiệp bốn chấm không", "🤖", "Vì sao lại là nước Đức?", "Nước Đức nổi tiếng về công nghiệp và máy móc. Năm hai nghìn không trăm mười một, tại hội chợ Han-nô-vơ, họ giới thiệu ý tưởng Công nghiệp bốn chấm không.", "Ý tưởng là nhà máy thông minh, máy móc nối Internet và tự động hóa sâu."],
    ],
    x: [
      ["Hội chợ công nghiệp Han-nô-vơ, nước Đức, năm hai nghìn không trăm mười một.", "big", "🇩🇪", "Đức, 2011"],
      ["Nhà máy thông minh, máy móc tự trò chuyện với nhau.", "row", "🏭 📡 🤖", "Nhà máy|Kết nối|Robot"],
      ["Sau đó ý tưởng lan ra khắp thế giới.", "flow", "🇩🇪 🌐 🌍", "Đức|Internet|Thế giới"],
    ],
    w: [
      "Tại Đức năm hai nghìn không trăm mười một. Đúng cả nơi lẫn năm.",
      "Pháp không phải nơi đề cập đầu tiên.",
      "Anh năm hai nghìn không trăm mười hai sai cả nơi lẫn năm.",
      "Mỹ không phải nơi khởi xướng ý tưởng này.",
    ],
    m: "Công nghiệp bốn chấm không: sinh ra ở Đức!",
    me: "🇩🇪",
  },
  53: {
    t: "vn",
    h: "Công cuộc đổi mới của Việt Nam bắt đầu từ một Đại hội lịch sử. Bạn nhớ đó là Đại hội mấy không?",
    k: [
      ["cơ chế quản lý kinh tế", "⚙️", "“Cơ chế quản lý kinh tế” là gì?", "Là cách nhà nước điều hành nền kinh tế. Trước đổi mới là cơ chế kế hoạch hóa tập trung, bao cấp.", "Đến Đại hội sáu, năm một chín tám sáu, Đảng nhận ra cơ chế cũ kém hiệu quả và quyết định đổi mới."],
    ],
    x: [
      ["Thời bao cấp: tem phiếu, xếp hàng, thiếu thốn.", "row", "🎫 🚶 🍚", "Tem phiếu|Xếp hàng|Gạo"],
      ["Năm một chín tám sáu, Đại hội sáu họp và nói: phải đổi mới!", "big", "🔔", "Đại hội VI, 1986"],
      ["Từ đó kinh tế khởi sắc dần.", "bars", "📉 📈", "Trước đổi mới:30|Sau đổi mới:80"],
    ],
    w: [
      "Đại hội năm chưa nhìn ra hết bất cập của cơ chế cũ.",
      "Đại hội sáu, mở đầu công cuộc đổi mới cơ chế quản lý kinh tế.",
      "Đại hội bảy tiếp tục con đường đã mở.",
      "Đại hội tám tiếp tục công nghiệp hóa, hiện đại hóa.",
    ],
    m: "Đổi mới là Đại hội sáu!",
    me: "🔔",
  },
  54: {
    t: "lt",
    h: "Câu này đặc biệt: chọn BA phương án đúng! Cùng giải mã bàn tay vô hình nổi tiếng của Xmít.",
    k: [
      ["bàn tay vô hình", "🖐️", "“Bàn tay vô hình” là bàn tay của ai?", "Không có bàn tay thật nào cả! Đó là cách nói ví von cho cơ chế thị trường tự điều tiết cung cầu và phân bổ nguồn lực.", "Mỗi người chỉ lo cho lợi ích của mình, nhưng kết quả chung lại tốt cho xã hội. Vì vậy ba ý đầu đúng."],
    ],
    x: [
      ["Người bán muốn lãi, người mua muốn rẻ. Ai cũng chỉ nghĩ cho mình.", "vs", "🧑‍🍳 🛒", "Người bán|Người mua"],
      ["Giá tự điều chỉnh: hàng dư thì giá giảm, hàng khan thì giá tăng.", "row", "📦 📉 📈", "Dư hàng|Giá giảm|Giá tăng"],
      ["Cuối cùng, nguồn lực chạy về nơi cần nhất mà không ai ra lệnh.", "flow", "💰 🖐️ 🏭", "Vốn|Bàn tay vô hình|Nơi cần"],
    ],
    w: [
      "Phân bổ nguồn lực đạt hiệu quả xã hội lớn nhất mà không cần chính phủ can thiệp. Đúng!",
      "Mô tả khả năng của thị trường trong việc điều chỉnh cung cầu. Đúng!",
      "Các cá nhân đều muốn tối đa hóa lợi nhuận cho mình. Đúng!",
      "Cách diễn đạt này chệch đi, vì kết quả cuối cùng là lợi ích chung cho xã hội, không chỉ cho riêng mình.",
    ],
    m: "Ba ý đúng: không cần chính phủ, điều cung cầu, tối đa lợi nhuận!",
    me: "🖐️",
  },
  55: {
    t: "hh",
    h: "Mọi nền kinh tế, giàu hay nghèo, đều phải trả lời đúng ba câu hỏi. Ba câu đó là gì?",
    k: [
      ["ba vấn đề kinh tế cơ bản", "🔺", "Ba câu hỏi đó là gì?", "Sản xuất cái gì, sản xuất như thế nào, và sản xuất cho ai.", "Thị trường trả lời ba câu này bằng giá cả và cạnh tranh, không cần ai ra lệnh."],
    ],
    x: [
      ["Cái gì: nông dân chọn trồng lúa hay trồng cà phê?", "vs", "🌾 ☕", "Lúa|Cà phê"],
      ["Như thế nào: làm bằng tay hay bằng máy?", "vs", "✋ 🤖", "Thủ công|Máy móc"],
      ["Cho ai: bán trong nước hay xuất khẩu?", "vs", "🏠 🚢", "Trong nước|Xuất khẩu"],
    ],
    w: [
      "Sản xuất cái gì, như thế nào, cho ai. Đúng ba vấn đề cơ bản.",
      "Ở đâu, bao lâu là chi tiết, không phải ba vấn đề cơ bản.",
      "Giá cả, hàng hóa, cung cầu là công cụ, không phải câu hỏi.",
      "Trộn lẫn câu hỏi ở đâu và giá thành, nên không chuẩn.",
    ],
    m: "Cái gì, thế nào, cho ai!",
    me: "🔺",
  },
  56: {
    t: "cnh",
    h: "Cuộc cách mạng công nghiệp lần hai. Đặc trưng là gì? Hãy nghĩ tới chiếc xe hơi đầu tiên chạy ra từ dây chuyền!",
    k: [
      ["dây chuyền chuyên môn hóa", "🏭", "“Dây chuyền chuyên môn hóa” là sao?", "Mỗi công nhân chỉ làm một bước nhỏ, sản phẩm chạy qua băng chuyền, và nhờ có điện nên chạy liên tục.", "Đó là cách Hen-ri Pho làm xe hơi hàng loạt, rẻ và nhanh."],
    ],
    x: [
      ["Mỗi người một bước: bắt ốc, lắp cửa, sơn xe.", "flow", "🔩 🚪 🎨", "Bắt ốc|Lắp cửa|Sơn"],
      ["Băng chuyền chạy bằng điện, xe lăn bánh liên tục.", "flow", "⚡ 🏭 🚗", "Điện|Dây chuyền|Xe"],
      ["Sản xuất hàng loạt, giá thành giảm mạnh.", "bars", "🚗 🚗", "Trước:100|Sau:30"],
    ],
    w: [
      "Điện và động cơ điện tạo dây chuyền chuyên môn hóa cao, đúng đặc trưng lần hai.",
      "Máy hơi nước là dấu hiệu của lần một.",
      "Hơi nước cơ khí hóa sản xuất cũng thuộc về lần một.",
      "Công nghệ thông tin và tự động hóa là của lần ba.",
    ],
    m: "Lần hai là điện cộng dây chuyền!",
    me: "⚡",
  },
  57: {
    t: "hh",
    h: "Muốn có hàng hóa thì cần những gì? Câu hỏi này chỉ cần một con số, nhưng phải hiểu vì sao đúng con số đó.",
    k: [
      ["hai điều kiện", "✌️", "Hai điều kiện đó là gì?", "Một là phân công lao động xã hội: mỗi người làm một nghề. Hai là sự tách biệt kinh tế giữa các chủ thể, nhờ quyền sở hữu riêng.", "Thiếu một trong hai thì không thể có sản xuất hàng hóa."],
    ],
    x: [
      ["Điều kiện một: người làm bánh, người trồng lúa, mỗi người một nghề.", "row", "🥖 🌾 🔨", "Thợ bánh|Nông dân|Thợ rèn"],
      ["Điều kiện hai: sản phẩm thuộc về mình, nên muốn lấy của người khác phải trao đổi.", "swap", "🥖 🌾", "Bánh|Gạo"],
      ["Đủ cả hai điều kiện, hàng hóa mới ra đời.", "merge", "👷 🔑 🛒", "Phân công|Sở hữu riêng|Hàng hóa"],
    ],
    w: [
      "Một điều kiện là còn thiếu.",
      "Đúng hai điều kiện: phân công lao động xã hội và tách biệt về kinh tế.",
      "Ba điều kiện là thừa.",
      "Bốn điều kiện còn thừa hơn.",
    ],
    m: "Hai điều kiện: phân công và tách biệt!",
    me: "✌️",
  },
  58: {
    t: "dq",
    h: "Xuất khẩu hàng hóa là bán hàng ra nước ngoài. Còn xuất khẩu tư bản thì khác hẳn. Khác thế nào?",
    k: [
      ["giá trị thặng dư tại nước sở tại", "🌍", "Khác xuất khẩu hàng hóa ở đâu?", "Xuất khẩu hàng hóa là bán hàng. Xuất khẩu tư bản là mang vốn ra nước ngoài mở nhà máy, thuê lao động địa phương.", "Mục đích sâu xa là sản xuất ra giá trị thặng dư ngay tại nước đó, để hưởng lợi nhuận cao."],
    ],
    x: [
      ["Một tập đoàn mang một nghìn tỷ ra nước ngoài.", "flow", "🏦 ✈️ 🌏", "Vốn|Bay đi|Nước ngoài"],
      ["Xây nhà máy ở đó, thuê công nhân địa phương.", "flow", "🏗️ 👷 📦", "Xây|Thuê|Sản xuất"],
      ["Lợi nhuận chuyển về công ty mẹ.", "flow", "📦 💰 🏦", "Sản phẩm|Lợi nhuận|Công ty mẹ"],
    ],
    w: [
      "Đó chỉ là nói về đặc điểm chung, chưa nói định nghĩa.",
      "Mang tư bản đầu tư ở nước ngoài để sản xuất giá trị thặng dư tại chỗ. Đúng định nghĩa.",
      "Mang hàng ra nước ngoài là xuất khẩu hàng hóa.",
      "Mang tiền ra nước ngoài chỉ để mua nguyên liệu thì chưa phải đầu tư sản xuất.",
    ],
    m: "Vốn đi ra, thặng dư sinh ngay tại chỗ!",
    me: "🌍",
  },
  59: {
    t: "lt",
    h: "Lợi nhuận là gì? Có người xem nó là phần thưởng cho sự dám chịu rủi ro. Ai là người đưa ra quan điểm đó?",
    k: [
      ["phần thưởng cho rủi ro và đổi mới", "🎲", "“Phần thưởng cho rủi ro” nghĩa là sao?", "Quan điểm này xem lợi nhuận là doanh thu trừ chi phí, và là phần thưởng cho người dám chịu rủi ro và đổi mới.", "Đề hỏi ai là người nêu quan điểm này. Đáp án của bộ đề là Pôn Xa-muên-xơn."],
    ],
    x: [
      ["Mở một quán mới, có thể lời, cũng có thể lỗ trắng tay.", "big", "🎲", "Rủi ro"],
      ["Người dám làm, dám đổi mới, nếu thắng sẽ có lợi nhuận.", "flow", "💡 🎲 💰", "Đổi mới|Rủi ro|Lợi nhuận"],
      ["Đó là phần thưởng cho rủi ro, theo Xa-muên-xơn.", "big", "🏆", "Samuelson"],
    ],
    w: [
      "Pôn Xa-muên-xơn, đúng theo đáp án của bộ đề.",
      "Đây không phải quan điểm gắn với tên ông trong bộ đề này.",
      "Cũng không phải ông. Đề gắn quan điểm này với Xa-muên-xơn.",
      "Cũng không đúng tác giả của quan điểm này.",
    ],
    m: "Rủi ro và đổi mới: nhớ Xa-muên-xơn!",
    me: "🏆",
  },
  60: {
    t: "dq",
    h: "Cạc-ten là một hình thức độc quyền rất quen thuộc ở châu Âu. Nhưng nó rộ lên vào thời điểm nào?",
    k: [
      ["cạc-ten", "🤝", "“Cạc-ten” là gì?", "Là liên minh các doanh nghiệp cùng ngành thỏa thuận về giá, sản lượng và thị trường, nhưng vẫn giữ độc lập về sản xuất và bán hàng.", "Hình thức này phổ biến ở châu Âu vào cuối thế kỷ mười chín, khi độc quyền nảy nở."],
    ],
    x: [
      ["Ba hãng thép ngồi lại: giá thép phải giữ ở mức này.", "row", "🏭 🤝 🏭", "Hãng A|Thỏa thuận|Hãng B"],
      ["Họ chia nhau thị trường, ai bán ở vùng nào đã định sẵn.", "split", "🗺️ 🏭 🏭 🏭", "Thị trường|Vùng 1|Vùng 2|Vùng 3"],
      ["Hình thức này rộ lên ở châu Âu vào cuối thế kỷ mười chín.", "big", "🇪🇺", "Cuối thế kỷ 19"],
    ],
    w: [
      "Đầu thế kỷ mười chín là thời tự do cạnh tranh, chưa có độc quyền phổ biến.",
      "Giữa thế kỷ mười chín độc quyền vẫn chưa phổ biến.",
      "Cuối thế kỷ mười chín, đúng mốc phổ biến của cạc-ten ở châu Âu.",
      "Đầu thế kỷ hai mươi đã có thêm nhiều hình thức độc quyền khác, mốc của cạc-ten là cuối mười chín.",
    ],
    m: "Cạc-ten: cuối mười chín!",
    me: "🤝",
  },
};
