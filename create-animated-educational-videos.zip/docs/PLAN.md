# KẾ HOẠCH & GHI NHỚ DỰ ÁN — "Video ôn thi MLN122 (Câu 1–100)"

> File này để tự nhắc (context memory). Cập nhật khi có thay đổi lớn.

## Nguồn đề
- Google Drive: `MLN122 Flashcards | Quizlet.pdf` (194 trang, 501 thẻ). Đã tải & trích text được (KHÔNG cần user gửi ảnh).
- Quy ước: câu 1–100 = 100 thẻ đầu tiên theo thứ tự PDF (đã tự đọc & đối chiếu thủ công vì parser tự động dính thẻ).
- Câu 54, 78, 96 là câu chọn NHIỀU đáp án (A,B,C / A,B,C / A,B,D). Câu 95 trùng nội dung câu 56 → ôn nhanh.
- PDF có lỗi chính tả OCR (đâu→đầu, tiên tệ…); dữ liệu trong `content/` đã sửa tay.

## Kiến trúc
- `content/questions/qNN-MM.ts`: dữ liệu 100 câu (đề, 4 đáp án, đáp án, kịch bản lời đọc + ví dụ minh họa).
- `scripts/gen-audio.mjs`: dựng kịch bản → các "beat" (mỗi beat = 1 câu phụ đề = 1 đoạn TTS) → ghép MP3 mỗi câu
  + chèn khoảng lặng → `public/audio/qNN.mp3` + `public/audio/manifest.json` (mốc thời gian từng beat). 
  => Phụ đề và hình ảnh bám theo `audio.currentTime` nên LUÔN khớp giọng đọc.
- Giọng đọc: Microsoft Edge neural `vi-VN-NamMinhNeural` (nam, tiếng Việt chuẩn), rate +6%.
- `scripts/copy-emoji.mjs`: copy Twemoji SVG (CC-BY 4.0) đúng những emoji đã dùng vào `public/emoji/`.
- Player (Next.js client): canvas ảo 1920×1080 scale vừa khung (không bao giờ đè/crop), font Be Vietnam Pro (@fontsource, bundle sẵn).
- SFX: WebAudio tổng hợp (pop, whoosh, ding đúng, buzz sai, tick đếm ngược, fanfare). Nhạc nền nhẹ tắt/bật được.
- Ảnh nền: Pexels (có ghi tác giả, trang `/credits`). Minh họa: Twemoji.

## Cấu trúc 1 câu (≈ 90–130 giây)
1. Intro (hook) → 2. Đọc đề + A/B/C/D → 3. "Bạn chọn gì?" đếm ngược 3s → 4. Giải phẫu từ khóa (tự đặt câu hỏi "X nghĩa là gì?")
→ 5. Ví dụ minh họa animation → 6. Soi từng đáp án (✅/❌ + vì sao) → 7. Chốt đáp án + mẹo nhớ.

## Tiến độ (tick khi xong)
- [x] Trích PDF, đọc 100 câu, kiểm đáp án
- [x] Tải ảnh Pexels, cài gói
- [x] Viết content 100 câu (content/questions/b01..b10.ts)
- [x] Script audio + chạy sinh audio (scripts/gen-audio.mjs, cache .cache/tts)
- [x] Player + UI + SFX (đã chụp ảnh QA bằng playwright: bố cục không đè/crop)
- [ ] Credits, typecheck, build, build_and_start

## Ghi chú QA đã làm
- Chụp ảnh thật bằng headless Chromium ở các cảnh: tiêu đề, đọc đề (câu 10 đáp án dài nhất), đếm ngược, từ khóa, ví dụ (swap/split/merge/bars/loop), soi đáp án, chốt đáp án.
- Đã sửa: tràn dọc ở câu đáp án dài, icon trang trí đè số câu, lớp blur đếm ngược bị lật chữ, cột quá thấp mất số.
- Câu 95 trùng câu 56 (ôn nhanh). Câu 54/78/96 chọn nhiều đáp án.
- Bộ đề (Quizlet) có vài đáp án gây tranh cãi (câu 35, 67, 81, 93...) → video nói rõ "theo đáp án bộ đề".
- Muốn xuất MP4: ghi màn hình trình phát ở chế độ toàn màn hình (hoặc dùng puppeteer + ffmpeg ghi theo manifest).
